from admin_login import name

user = name()


def show_profile():
    print(user)
    return user

