from logIn import user_email

user = user_email()

def show_profile():
    return user
