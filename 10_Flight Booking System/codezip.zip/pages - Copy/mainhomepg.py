from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from tkcalendar import DateEntry
from datetime import datetime
from login_signup import login_page
from flight_available import available_flight
import sqlite3
from tkinter import messagebox


def func():
    global end,retdate_var
    # capture all the input in variable.
    depdate_var = departing_cal.get_date()
    retdate_var = Returning_cal.get_date()
    radio = x.get()
    start = start_entry.get()
    end = destination_entry.get()
    adult = adult_clicked.get()
    child = children_clicked.get()
    infant = infant_clicked.get()
    combobox = type_combo.get()
    print(radio)
    def database():
        con = sqlite3.connect("flight.db")
        c = con.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS user_choice(
            username text,
            start text,
            end text,
            class text,
            adult int,
            child int,
            infant int,
            dep_date text,
            ret_date text
        )""")
            # use to solve problem where we can't use the variable of other file so we did this instead
            # And ROWID = (SELECT MAX(ROWID) FROM logsign) selects the last row of logsign.
        c.execute(""" SELECT * FROM logsign WHERE ROWID = (SELECT MAX(ROWID) FROM logsign) """)
        userf_db = c.fetchone()#this is tuple thats the reason for error in line 41.    
        c.execute("""INSERT INTO user_choice (username,start,end,class,adult,child,infant,dep_date,ret_date) VALUES (?,?,?,?,?,?,?,?,?)""",(userf_db[0],start,end,combobox,adult,child,infant,depdate_var,retdate_var))
        con.commit()
        con.close()
        available_flight()

    if start == "From" or radio ==0 or end == "To" or adult==0 or start ==""  or end == "":
        messagebox.showwarning(title="",message="Please fill required credential")
    elif start.isalpha() == False or end.isalpha() == False:
        messagebox.showwarning(title="invalid entry",message="Location should be in letters")
    elif radio == 1:
        retdate_var = None
        database()
    elif radio ==2:
        if depdate_var >= retdate_var:
            messagebox.showerror(title="",message="Return date should be atlest on day greater than departing date")
        else: 
            database()
    else:
        messagebox.showerror(title="",message="Please choose option from radio button.")


def on_radio_select():
    if x.get() == 1:
        # disable the Entry widget
        # disable the Calendar widget and change the background color
        Returning_cal.config(state="disabled", disabledbackground="gray")
    else:
        # retdate_var = Returning_cal.get_date()
        # end = destination_entry.get()
        destination_entry.config(state="normal")
        # enable the Calendar widget and change the background color
        Returning_cal.config(state="normal", disabledbackground="white")
        print(end)

def on_entry_click(event):
    """function that gets called whenever entry is clicked"""
    if start_entry.get() == "From" or destination_entry.get() == "To":
        start_entry.delete(0,"end")
        destination_entry.delete(0, "end") # delete all the text in the entry box
    
main_window = Tk()
main_window.state("zoomed")
main_window.config(bg="#0082FF")
main_window.title("Flight Booking System")

frame1_main = Frame(main_window,bg="#0082FF",width=1200,height=100)
frame1_main.pack_propagate(False)
frame1_main.pack()

frame2_main = Frame(main_window,bg="#1B1D20",width=1300,height=550)
frame2_main.pack_propagate(False)
frame2_main.pack()

login_signup_button = Button(frame1_main,text="Login/Signup",font=("comic sans",15),command=login_page)
login_signup_button.place(relx=0.85,rely=0.6)

# ---------------------------for frame2_main--------------------
#style the tabs heading
style = ttk.Style()
style.theme_create('optionbar_theme', parent='alt', settings={
    'TNotebook.Tab': {
        'configure': {
            'background': '#0082FF',
            'padding': [40, 15],
            'font': ('TkDefaultFont', 20),
            'foreground': 'white'
        },
        'map': {
            'background': [('selected', 'blue')]
        }
    }
})
style.theme_use('optionbar_theme')
#end

#tabs structure
tabs_table = ttk.Notebook(frame2_main)

tab1 = Frame(tabs_table,bg="#363A3F",width=900,height=350)
tab2 = Frame(tabs_table,bg='red',width=900,height=350)
tab3 = Frame(tabs_table,bg="blue",width=900,height=350)
tab4 = Frame(tabs_table,bg="green",width=900,height=350)

tabs_table.add(tab1,text="Search Flight")
tabs_table.add(tab2,text="                    ")
tabs_table.add(tab3,text="                 ")
tabs_table.add(tab4,text="                    ")

tabs_table.place(relx=0.5,rely=0.45,anchor="center")
#---------------------------------------------tab1-------------------------------------------

x = IntVar()
Oneway_radio_button = Radiobutton(tab1,font=("comic sans",20),bg="#363A3F",variable=x,text="One Way",value=1,command=on_radio_select)
Oneway_radio_button.place(x=50,y=50)
radio = x.get()
Roundtrip_radio_button = Radiobutton(tab1,font=("comic sans",20),bg="#363A3F",variable=x,text="Round Trip",value=2,command=on_radio_select)
Roundtrip_radio_button.place(x=250,y=50)
# -------------------------------entry box-------------------------------------------------------
start_entry = Entry(tab1,width=21,font=("comic sans",27))
start_entry.insert(0,"From")
start_entry.place(x=50,y=105)

destination_entry = Entry(tab1,width=21,font=("comic sans",27))
destination_entry.insert(0,"To")
destination_entry.place(x=480,y=105)

start_entry.bind('<FocusIn>', on_entry_click)
destination_entry.bind('<FocusIn>', on_entry_click)
# -----------------------------dropdown box--------------------------------------------
options1 = [0,1,2,3,4,5,6,7,8,9]
options2 = ["Economy","Business","First"]

class_label = Label(tab1,text="Class",font=("comic sans",22),bg="#363A3F",fg="white")
class_label.place(x=50,y=180)

adult_label = Label(tab1,text="Adult",font=("comic sans",22),bg="#363A3F",fg="white")
adult_label.place(x=440,y=180)

Children_label = Label(tab1,text="Children",font=("comic sans",22),bg="#363A3F",fg="white")
Children_label.place(x=580,y=180)

Infant_label = Label(tab1,text="Infant",font=("comic sans",22),bg="#363A3F",fg="white")
Infant_label.place(x=770,y=180)

adult_clicked = IntVar()
adult_clicked.set(options1[0])

children_clicked = IntVar()
children_clicked.set(options1[0])

infant_clicked = IntVar()
infant_clicked.set(options1[0])

adult_drop = OptionMenu(tab1,adult_clicked,*options1)
adult_drop.config(bg="#0082FF")
adult_drop.place(x=520,y=180)

children_drop = OptionMenu(tab1,children_clicked,*options1)
children_drop.config(bg="#0082FF")
children_drop.place(x=700,y=180)

infant_drop = OptionMenu(tab1,infant_clicked,*options1)
infant_drop.config(bg="#0082FF")
infant_drop.place(x=855,y=180)

# ---------------------------------combo box---------------------------------------------------
type_combo = ttk.Combobox(tab1,values=options2)
type_combo.current(0)
type_combo.bind("<<ComboboxSelected>>")
type_combo.config(width=15,height=30,font=("comic sans",22))
type_combo.place(x=150,y=180)
# --------------------------------calender-----------------------------------------------------
# https://youtu.be/X8gYlRMLO3c

departing_label = Label(tab1,text="Departing",font=("comic sans",22),bg="#363A3F",fg="white")
departing_label.place(x=50,y=230)

departing_cal = DateEntry(tab1,selectmode='day')
departing_cal.config(font=("comic sans",10))
departing_cal.place(x=200,y=240)

Returning_label = Label(tab1,text="Returning",font=("comic sans",22),bg="#363A3F",fg="white")
Returning_label.place(x=350,y=230)

Returning_cal = DateEntry(tab1,selectmode='day')
Returning_cal.config(font=("comic sans",10))
Returning_cal.place(x=500,y=240)

search_button = Button(tab1,text="Search",font=("comic sans",22),bg="#0082FF",fg="white",width=15,command=func)
search_button.place(x=650,y=230)

mainlogo = Image.open("img/mainlogo.png")
mainlogo = mainlogo.resize((200,104))
mainlogo2 = ImageTk.PhotoImage(mainlogo)
mainlogo_imagelabel = Label(frame1_main,image=mainlogo2)
mainlogo_imagelabel.place(relx=0.05,rely=0.01)
# -----------------------------------enf of tab1-----------------------------------------------
main_window.mainloop() 