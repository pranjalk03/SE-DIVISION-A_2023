from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from passengerdetail import passdetail
import sqlite3
import random

def available_flight():
    # use to  get selected value
    def on_tree_select():
        selected_item = tree.focus()
        values = tree.item(selected_item)['values']
        price_a = values[7]
        price_c = values[8]
        price_i = values[9]
        rand_num = random.randint(100, 999)
        conn = sqlite3.connect('flight.db')
        c = conn.cursor()
        c.execute("SELECT class,adult,child,infant FROM user_choice WHERE ROWID = (SELECT MAX(ROWID) FROM user_choice)")
        demo = c.fetchone()
        print(type(demo))
        price = float(values[7]) * float(demo[1]) + float(values[8]) * float(demo[2]) + float(values[9]) * float(demo[3])
        print(price)
        c.execute("INSERT INTO ticket (flight,ticketno,start,end,retdate,depdate,rettime,deptime,price,class,adult,child,infant)VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (values[0],rand_num,values[1], values[2], values[4], values[3], values[6], values[5],price,demo[0],demo[1],demo[2],demo[3]))
        conn.commit()
        conn.close()
        passdetail()

    
    available_flight_window = Tk()
    available_flight_window.state("zoomed")
    available_flight_window.config(bg="#0082FF")
    available_flight_window.title("Availble Flight")

    frame1_avai = Frame(available_flight_window,bg="#0082FF",width=1200,height=100)
    frame1_avai.pack_propagate(False)
    frame1_avai.pack()

    frame2_avai = Frame(available_flight_window,bg="#1B1D20",width=1300,height=550)
    frame2_avai.pack_propagate(False)
    frame2_avai.pack() 

    

    frame3_avai = Frame(frame2_avai, bg="#363A3F", width=1155, height=500)
    frame3_avai.place(relx=0.05, rely=0.05)
    

    temp_button = Button(frame3_avai,text="Submit",command=on_tree_select,font=("comic sans",15),width=10)
    temp_button.place(relx=0.8,rely=0.9)

    # Create a Treeview widget
    tree = ttk.Treeview(frame3_avai, columns=("flight_no", "source", "destination", "departure_date","return_date","dep_time","ret_time","price","price_c","price_i"), height=20)
    tree.heading("#0", text="Flight Details", anchor="w")
    # hides the extra blank column.
    tree.column("#0", width=0, stretch=NO)
    tree.heading("flight_no", text="Flight No.", anchor="w")
    tree.heading("source", text="Source", anchor="w")
    tree.heading("destination", text="Destination", anchor="w")
    tree.heading("departure_date", text="Departure Date", anchor="w")
    tree.heading("return_date",text="Return Date",anchor="w")
    tree.heading("dep_time",text="Departure Time",anchor="w")
    tree.heading("ret_time",text="Return Time",anchor="w")
    tree.heading("price",text="Price_adult",anchor="w")
    tree.heading("price_c",text="Price_child",anchor="w")
    tree.heading("price_i",text="Price_infant",anchor="w")

    # Add data to the Treeview
    con = sqlite3.connect("flight.db")
    c = con.cursor()
    c.execute(""" SELECT *
        FROM flight_detail_new
        WHERE start1 = (SELECT start FROM user_choice ORDER BY rowid DESC LIMIT 1)
        AND end1 = (SELECT end FROM user_choice ORDER BY rowid DESC LIMIT 1)
        ORDER BY rowid DESC
        LIMIT 1;
    """)
    for row in c.fetchall():
        tree.insert("", "end", values=row)

    # style = ttk.Style()
    # style.theme_use("default")
    # style.configure("Treeview",
    #                 background="#D3D3D3",
    #                 foreground="black",
    #                 rowheight=25,
    #                 fieldbackground="#D3D3D3")
    # style.map("Treeview", background=[('selected', '#347083')])

    # style.configure("Treeview.Heading",
    #                 background="#347083",
    #                 foreground="black",
    #                 font=("Helvetica", 20))

    tree.place(relx=0.1, rely=0.05, relwidth=0.8)

    # tree.bind("<<TreeviewSelect>>", on_tree_select)
    con.commit()
    con.close()

    