from tkinter import *
from tkinter import ttk
import sqlite3
import os
from datetime import datetime
from fpdf import FPDF
from tkinter import messagebox

def playmentdetail():
    def paymentstatus():
        upi = upi_entry.get()
        name = fname+lname
        if len(upi) != 10 or upi.isdigit() == False:
            messagebox.showerror(title="Invalid UPIno.",message="Type correct valid UPI number.",parent=pay_window)
        else :
            con = sqlite3.connect("flight.db")
            c = con.cursor()
            c.execute("""CREATE TABLE IF NOT EXISTS payment_info1(
             fullname TEXT, 
             upi INT 
            )""")

            c.execute("INSERT INTO payment_info1 (fullname, upi) VALUES (?,?)",(name,upi))
            con.commit()
            con.close()
            messagebox.showinfo(message="payment done successfully")


    def pdfmaker():
        con = sqlite3.connect("flight.db")
        c = con.cursor()
        upi = upi_entry.get()
        name = fname+lname
        if len(upi) != 10 or upi.isdigit() == False:
            messagebox.showerror(title="Invalid UPIno.",message="Type correct valid UPI number.",parent=pay_window)
        else :
            c.execute(""" SELECT upi FROM payment_info1 WHERE upi = ? """,(upi,))
            checkupi = c.fetchone()
            print(checkupi)
            if checkupi is None:
                messagebox.showerror(message="Please make your payment.",parent = pay_window)
            else:
                messagebox.showinfo(message="pdf collect.",parent = pay_window)
                mainpdf()
    
    def mainpdf():
        pdf = PDF()

    # Set up the document
        pdf.add_page()
        pdf.set_font('Arial', '', 12)

    # Add the invoice details
        pdf.cell(0, 10, 'Flight Ticket Invoice', 0, 1, 'C')
        pdf.cell(0, 10, 'Ticket #: {}'.format(ticket), 0, 1)
        pdf.cell(0, 10, 'Date: {}'.format(datetime.now().strftime("%d/%m/%Y")), 0, 1)
        pdf.cell(0, 10, 'Flight Number: {}'.format(flightno), 0, 1)
        pdf.cell(0, 10, 'Departure: {} ({})'.format(start, depd), 0, 1)
        pdf.cell(0, 10, 'Destination: {} ({})'.format(end, retd), 0, 1)
        pdf.cell(0, 10, 'Departure Time: {}'.format(dept), 0, 1)
        pdf.cell(0, 10, 'Return Time: {}'.format(rett), 0, 1)
        pdf.cell(0, 10, 'Customer Name: {}'.format(name), 0, 1)
        pdf.cell(0, 10, 'Class: {}'.format(cl), 0, 1)
        pdf.cell(0, 10, 'Price: {}'.format(price), 0, 1)
        pdf.cell(0, 10, 'Adults: {}'.format(adult), 0, 1)
        pdf.cell(0, 10, 'Children: {}'.format(child), 0, 1)
        pdf.cell(0, 10, 'Infants: {}'.format(infant), 0, 1)

        # Save the PDF file
        pdf.output('flight_ticket_invoice.pdf', 'F')
    
    class PDF(FPDF):
        def header(self):
            # Logo
            self.image('img/mainlogo.png', 10, 8, 33)
            # Arial bold 15
            self.set_font('Arial', 'B', 15)
            # Move to the right
            self.cell(80)
            # Title
            self.cell(30, 10, 'Flight Ticket Invoice', 1, 0, 'C')
            # Line break
            self.ln(20)

        # Page footer
        def footer(self):
            # Position at 1.5 cm from bottom
            self.set_y(-15)
            # Arial italic 8
            self.set_font('Arial', 'I', 8)
            # Page number
            self.cell(0, 10, 'Page ' + str(self.page_no()), 0, 0, 'C')
    pay_window = Tk()
    pay_window.state("zoomed")
    pay_window.config(bg="#0082FF")
    pay_window.title("Payment Portal")

    frame1_pay = Frame(pay_window, bg="#0082FF", width=1200, height=100)
    frame1_pay.pack_propagate(False)
    frame1_pay.pack()

    frame2_pay = Frame(pay_window, bg="#1B1D20", width=1300, height=550)
    frame2_pay.pack_propagate(False)
    frame2_pay.pack() 

    frame3_pay = Frame(frame2_pay,bg="#363A3F",width=1040,height=300)
    frame3_pay.place(relx=0.1,rely=0.05)

    frame4_pay = Frame(frame2_pay,bg="#363A3F",width=1040,height=190)
    frame4_pay.place(relx=0.1,rely=0.64)

    con = sqlite3.connect("flight.db")
    c = con.cursor()
    c.execute('SELECT * FROM ticket WHERE ROWID = (SELECT MAX(ROWID) FROM ticket)')
    result = c.fetchone()  # assuming c is a cursor object
    c.execute("SELECT f_name,l_name FROM personal_info WHERE ROWID = (SELECT MAX(ROWID) FROM personal_info)")
    res1 = c.fetchone()

    fname,lname = res1
    
    flightno,ticket,start,end,retd,depd,rett,dept,name,cl,price,adult,child,infant = result
    con.commit()
    con.close()

    ticket_detail_label = Label(frame3_pay,text="Ticket Detail",font=("comic sans",20,"bold"),bg="#363A3F",fg="white")
    ticket_detail_label.place(relx=0.5,rely=0.08,anchor="center")

    flight_No_label = Label(frame3_pay,text="Flight No: "+str(flightno),font=("comic sans",15),bg="#363A3F",fg="white")
    flight_No_label.place(relx=0.1,rely=0.2)

    depat_label = Label(frame3_pay,text="Depart At: "+str(start),font=("comic sans",15),bg="#363A3F",fg="white")
    depat_label.place(relx=0.1,rely=0.35)

    deptime_label = Label(frame3_pay,text="Dept. Time"+str(dept),font=("comic sans",15),bg="#363A3F",fg="white")
    deptime_label.place(relx=0.5,rely=0.35)

    passname_label = Label(frame3_pay,text="Passenger Name: "+str(fname)+" "+str(lname),font=("comic sans",15),bg="#363A3F",fg="white")
    passname_label.place(relx=0.5,rely=0.65)

    ticno_label = Label(frame3_pay,text="Ticket No: "+str(ticket),font=("comic sans",15),bg="#363A3F",fg="white")
    ticno_label.place(relx=0.5,rely=0.2)

    arrat_label = Label(frame3_pay,text="Arrival At: "+str(end),font=("comic sans",15),bg="#363A3F",fg="white")
    arrat_label.place(relx=0.1,rely=0.5)

    arriat_label = Label(frame3_pay,text="Arrival Time: "+str(rett),font=("comic sans",15),bg="#363A3F",fg="white")
    arriat_label.place(relx=0.5,rely=0.5)

    class_label = Label(frame3_pay,text="Class Travel: "+str(cl),font=("comic sans",15),bg="#363A3F",fg="white")
    class_label.place(relx=0.1,rely=0.65)

    ad_label = Label(frame3_pay,text="Adult: "+str(adult),font=("comic sans",15),bg="#363A3F",fg="white")
    ad_label.place(relx=0.1,rely=0.8)

    ch_label = Label(frame3_pay,text="Children: "+str(child),font=("comic sans",15),bg="#363A3F",fg="white")
    ch_label.place(relx=0.35,rely=0.8)

    in_label = Label(frame3_pay,text="Infant: "+str(infant),font=("comic sans",15),bg="#363A3F",fg="white")
    in_label.place(relx=0.65,rely=0.8)

    payment_label = Label(frame4_pay,text="Make Payment",font=("comic sans",20,"bold"),bg="#363A3F",fg="white")
    payment_label.place(relx=0.5,rely=0.14,anchor="center")
    
    pay_label = Label(frame4_pay,text="Total Payable Amount:"+str(price),font=("comic sans",15),bg="#363A3F",fg="white")
    pay_label.place(relx=0.37,rely=0.23)

    upi_label = Label(frame4_pay,text="UPI Id:",font=("comic sans",15),bg="#363A3F",fg="white")
    upi_label.place(relx=0.25,rely=0.45)

    upi_entry = Entry(frame4_pay,font=("comic sans",15),width=37)
    upi_entry.place(relx=0.325,rely=0.45)

    submit_button = Button(frame4_pay,font=("comic sans",15),text="Pay",width=20,command=paymentstatus)
    submit_button.place(relx=0.25,rely=0.7)

    print_button = Button(frame4_pay,font=("comic sans",15),text="Print",width=20,command=pdfmaker)
    print_button.place(relx=0.5,rely=0.7)
    pay_window.mainloop()
