from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from tkcalendar import DateEntry
from flight_available import available_flight
from tkinter import messagebox
import sqlite3

def login_page():
    def getinfo():
        username = username_entry.get()
        password = password_entry.get()
        # -------------------------here we create db,insert values and check user account.----------------
        con = sqlite3.connect('flight.db')
        c = con.cursor()

        createtable = c.execute(""" CREATE TABLE IF NOT EXISTS logsign(
        username text,
        password text           
        )
        """)
        
        c.execute(""" SELECT * FROM logsign WHERE username = ?""",(username,))
        check = c.fetchone()

        if check is not None:
            messagebox.showwarning(title="",message="You already have an account,please login",parent = login_page_window)
        elif username == "" or password == "":
            messagebox.showwarning(title="",message="please fill the credential.",parent=login_page_window)
        else:
            messagebox.showinfo(title="Signed Up",message="You have signed up")
            insertinto = c.execute(""" INSERT INTO logsign VALUES(?,?)""",(username,password))
            
        con.commit()
        con.close()
        # --------------------------------------------------------------------------------------------------
    
    def loginlogic():
        # -------------------------------here we check if user already have account or not.------------------
        username = username_entry.get()
        password = password_entry.get()
        con = sqlite3.connect("flight.db")
        c = con.cursor()
        createtable = c.execute(""" CREATE TABLE IF NOT EXISTS login(
        username text,
        password text           
        )
        """)
        c.execute(""" SELECT username FROM logsign WHERE username = ? """,(username,))
        checkusername = c.fetchone()
        c.execute("""SELECT password FROM logsign WHERE password = ?""",(password,))
        checkpassword = c.fetchone()
        # print(username,password,checkpassword,checkusername)
        if username == "" or password == "":
            messagebox.showwarning(title="",message="please fill the credential.",parent=login_page_window)
        elif checkusername is None:
            messagebox.showwarning(title="No Account",message="You don't have an account.\nPlease sign-up",parent=login_page_window)
        else:
            if checkpassword is None or checkpassword[0] != password :
                messagebox.showerror(title="Error",message="Incorrect password.",parent=login_page_window)
            else:    
                messagebox.showinfo(title="Logged In",message="You have logged in.")
                c.execute("""INSERT INTO login VALUES(?,?)""",(username,password))
        con.commit()
        con.close()
        #-----------------------------------------------------------------------------------------------

    login_page_window = Tk()
    login_page_window.state("zoomed")
    login_page_window.config(bg="#0082FF")
    login_page_window.title("Login/Signup")

    frame1_login = Frame(login_page_window,bg="#0082FF",width=1200,height=100)
    frame1_login.pack_propagate(False)
    frame1_login.pack()

    frame2_login = Frame(login_page_window,bg="#1B1D20",width=1300,height=550)
    frame2_login.pack_propagate(False)
    frame2_login.pack()

    frame3_login = Frame(frame2_login,bg="#363A3F",width=330,height=430)
    frame3_login.place(relx=0.5, rely=0.5, anchor="center")

# ------------------------Images---------------------

# ------------------------Widgets---------------------

# -----------------------inside frame3------------------
    login_label = Label(frame3_login,font=("comic sans",30),text="Login",width=30,pady=17,bg="#0082FF",fg="white")
    login_label.place(relx=0.5, rely=0.1, anchor="center")
# relx and rely are used from relative position where x and y value should be between (0<=x,y<=1)

    username_label = Label(frame3_login,font=("comic sans",17),text="Username:",bg="#363A3F",fg="white")
    username_label.place(relx=0.1,rely=0.3)
    
    username_entry = Entry(frame3_login,font=("comic sans",17))
    username_entry.place(relx=0.5, rely=0.4, anchor="center")

    password_label = Label(frame3_login,font=("comic sans",17),text="Password:",bg="#363A3F",fg="white")
    password_label.place(relx=0.1,rely=0.5)

    password_entry = Entry(frame3_login,font=("comic sans",17),show="*")
    password_entry.place(relx=0.5, rely=0.6, anchor="center")

    note_label = Label(frame3_login,text="fill the credentials and click on signup for new user.",font=("comic sans",8),bg="#363A3F",fg="white")
    note_label.place(relx=0.1,rely=0.65)

    login_button = Button(frame3_login,font=("comic sans",15),text="Login",width=11,bg="#0082FF",fg="white",command=loginlogic)
    login_button.place(relx=0.1,rely=0.75)

    signup_button = Button(frame3_login,font=("comic sans",15),text="Signup",width=11,bg="#0082FF",fg="white",command=getinfo)
    signup_button.place(relx=0.5,rely=0.75)

    
    login_page_window.mainloop()