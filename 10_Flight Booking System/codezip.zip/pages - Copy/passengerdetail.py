from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
import sqlite3
from tkinter import messagebox
from datetime import datetime
from paymentportal import playmentdetail
def passdetail():
    def constraint():
        f_name = fname_entry.get()
        l_name = lname_entry.get()
        p_no = pno_entry.get()
        email = email_entry.get()
        dob = dob_entry.get()
        print(f_name.isalpha())
        if f_name == "" or l_name == "" or p_no == "" or email == "" or dob == "":
            messagebox.showerror(title="Incomplete Credentials",message="Fill the required entries.",parent=pass_detail_window)
        elif f_name.isalpha() == False or l_name.isalpha() == False:
            
            messagebox.showwarning(title="invalid name",message="Name should be in letters",parent=pass_detail_window)
        elif email[-10:] != "@gmail.com":
            messagebox.showerror(title="Invalid email",message="Fill proper email format",parent=pass_detail_window)
        elif len(p_no) != 10 or p_no.isdigit() == False:
            messagebox.showerror(title="Invalid phone no.",message="Type correct valid phone number.",parent=pass_detail_window)
        else:
            try:
                d = datetime.strptime(dob, '%Y-%m-%d')
                print('Date is in the correct format')
                con = sqlite3.connect('flight.db')
                c = con.cursor()
                createtable = c.execute(""" CREATE TABLE IF NOT EXISTS personal_info(
                f_name text,
                l_name text,
                dob text,
                email text,
                phone int
                )
                """)
                c.execute("""INSERT INTO personal_info (f_name,l_name,dob,email,phone)VALUES (?,?,?,?,?)""",(f_name,l_name,dob,email,p_no))
                con.commit()
                con.close()  
                con = sqlite3.connect('flight.db')
                c = con.cursor()
                playmentdetail()
            except ValueError:
                print('Date is not in the correct format')
                messagebox.showwarning(title="invalid dob", message="Fill in proper format YYYY-MM-DD",parent=pass_detail_window)  

    pass_detail_window = Tk()
    pass_detail_window.state("zoomed")
    pass_detail_window.config(bg="#0082FF")
    pass_detail_window.title("Personal Detail")

    frame1_avai = Frame(pass_detail_window,bg="#0082FF",width=1200,height=100)
    frame1_avai.pack_propagate(False)
    frame1_avai.pack()

    frame2_avai = Frame(pass_detail_window,bg="#1B1D20",width=1300,height=550)
    frame2_avai.pack_propagate(False)
    frame2_avai.pack() 

    frame3_avai = Frame(frame2_avai,bg="#363A3F")
    frame3_avai.place_configure(width=550,height=500)
    frame3_avai.place(relx=0.5, rely=0.5, anchor="center")

    passdetail_label = Label(frame3_avai,text="Personal Detail",font=("comic sans",32),bg="#0082FF",fg="white",width=22,pady=20)
    passdetail_label.place(relx=0.0,rely=0.0)

    fname_label = Label(frame3_avai,text="First Name",font=("comic sans",17),bg="#363A3F",fg="white")
    fname_label.place(relx=0.1,rely=0.25)

    fname_entry = Entry(frame3_avai,font=("comic sans",17))
    fname_entry.place(relx=0.4,rely=0.25)

    lname_label = Label(frame3_avai,text="Last Name",font=("comic sans",17),bg="#363A3F",fg="white")
    lname_label.place(relx=0.1,rely=0.35)

    lname_entry = Entry(frame3_avai,font=("comic sans",17))
    lname_entry.place(relx=0.4,rely=0.35)

    dob_label = Label(frame3_avai,text="D.O.B",font=("comic sans",17),bg="#363A3F",fg="white")
    dob_label.place(relx=0.1,rely=0.45)

    dob_entry = Entry(frame3_avai,font=("comic sans",17))
    dob_entry.place(relx=0.4,rely=0.45)

    contact_label = Label(frame3_avai,text="--------------Contact Details-------------",font=("comic sans",20),bg="#363A3F",fg="white")
    contact_label.place(relx=0.1,rely=0.55)

    email_label = Label(frame3_avai,text="Email",font=("comic sans",17),bg="#363A3F",fg="white")
    email_label.place(relx=0.1,rely=0.65)

    email_entry = Entry(frame3_avai,font=("comic sans",17))
    email_entry.place(relx=0.4,rely=0.65)

    pno_label = Label(frame3_avai,text="Phone no.",font=("comic sans",17),bg="#363A3F",fg="white")
    pno_label.place(relx=0.1,rely=0.75)

    pno_entry = Entry(frame3_avai,font=("comic sans",17))
    pno_entry.place(relx=0.4,rely=0.75)

    submit_button = Button(frame3_avai,text="Submit",font=("comic sans",17),bg="#0082FF",fg="white",width=20,command=constraint)
    submit_button.place(relx=0.25,rely=0.85)
    
    