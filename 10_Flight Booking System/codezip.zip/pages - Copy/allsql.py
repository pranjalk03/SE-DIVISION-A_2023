import sqlite3
from login_signup import*

con = sqlite3.connect('logsign.db')
c = con.cursor()

createtable = c.execute(""" CREATE TABLE IF NOT EXISTS logsign(
       username text,
       password text           
)
""")

con.commit()
con.close()