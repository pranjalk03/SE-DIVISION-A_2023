from tkinter import*
from tkinter import ttk
import tkinter as tk
#from tkinter import _PhotoImageLike
from PIL import ImageTk,Image
from tkinter import messagebox

#def
def About():
    Home.destroy()

def con():
    Home.destroy()
def studentpg():
    Home.destroy()
    import login1

def adminpg():
    Home.destroy()
    import Signadmin

def log():
 def collapse_toggle_window():
  login_menu_fm.destroy()
  login_menu_fm.config(command=log)
  login.config(command=collapse_toggle_window)
 #login menu options
 login_menu_fm=tk.Frame(Home,bg='#FBEFEA')
 Admin_btn=tk.Button(login_menu_fm,text='Admin',font=('Bold',11),bd=1,bg='#FBEEE9',fg='black',
                        activebackground='#FBEFEA',activeforeground='black',command=adminpg)
 Admin_btn.place(x=0,y=2)

 student_btn=tk.Button(login_menu_fm,text='Student',font=('Bold',11),bd=1,bg='#FBEEE9',fg='black',
                        activebackground='#FBEFEA',activeforeground='black',command=studentpg)
 student_btn.place(x=0,y=32)
 login_menu_fm.place(x=941,y=51,height=58,width=75)

def rec1():
    Home1=Toplevel(Home)
    Home1.geometry('478x660')
    Home1.resizable(0,0)
    bgImage=ImageTk.PhotoImage(Image.open('image/frame3.jpg'))
    bgLabel=Label(Home1,image=bgImage)
    bgLabel.place(x=0,y=0)
    Home1.mainloop()

def rec2():
    frame1=Toplevel(Home)
    frame1.geometry('478x660')
    frame1.resizable(0,0)
    bgImage=PhotoImage(file='image/Frame 4.png')
    bgLabel=Label(frame1,image=bgImage)
    bgLabel.place(x=0,y=0)
    frame1.mainloop()

def rec3():
    frame2=Toplevel(Home)
    frame2.geometry('478x660')
    frame2.resizable(0,0)
    bgImage=PhotoImage(file='image/Frame 5.png')
    bgLabel=Label(frame2,image=bgImage)
    bgLabel.place(x=0,y=0)
    frame2.mainloop()  
def dark():
    Home.destroy()
    import Home2
#window
Home=Tk()
Home.geometry("1183x603")
Home.resizable(False,False)
Home.title("Bully Box")
bgImage=ImageTk.PhotoImage(Image.open('image/Homepg.jpg'))
bgLabel=Label(Home,image=bgImage)
bgLabel.place(x=0,y=0)

#Navbar 
Aboutus=PhotoImage(file="image/Aboutus.png")
Aboutusbutton=Button(Home,image=Aboutus,bd=0,background='#F4E8DB',cursor='hand2',command=About).place(x=669,y=20)

contact=PhotoImage(file="image/contact.png")
contactbutton=Button(Home,image=contact,bd=0,background='#F7EBE2',cursor='hand2',command=con).place(x=802,y=20)

login=PhotoImage(file="image/log.png")
loginbutton=Button(Home,image=login,bd=0,background='#F7EBE2',cursor='hand2',command=log).place(x=935,y=20)

moon=PhotoImage(file="image/moon.png")
moonbutton=Button(Home,image=moon,bd=0,background='#FDF5F4',cursor='hand2',command=dark).place(x=1116.96,y=15)

#rectangle button
rect1=PhotoImage(file="image/recta.png")
rect1button=Button(Home,image=rect1,bd=0,cursor='hand2',command=rec1).place(x=61,y=405,width=175,height=175)

rect2=PhotoImage(file="image/rectb.png")
rect2button=Button(Home,image=rect2,bd=0,cursor='hand2',command=rec2).place(x=401,y=407,width=175,height=175)

rect3=PhotoImage(file="image/rectc.png")
rect3button=Button(Home,image=rect3,bd=0,cursor='hand2',command=rec3).place(x=701,y=405,width=175,height=175)

Home.mainloop()

