from tkinter import *
from tkinter import messagebox
from PIL import ImageTk,Image
import mysql.connector

#function
def login_info():
    return username.get()
def login_user():
      if usernameEntry.get()=="" or passwordEntry.get=="":
        messagebox.showerror("Error","All fields are required")
      else:
           try: 
               con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
               cur=con.cursor()
               cur.execute('select * from admin where username=%s and pwd=%s',(username.get(),passwd.get()))
               row=cur.fetchone()
               if row==None:
                  messagebox.showerror('Error','Invalid Username And Password')
                  loginclear()
                  usernameEntry.focus()
               else:
                    admin.destroy()
                    import a_dashboard
                    con.close()
           except Exception as es:
                messagebox.showerror('Error',f'Error Due to : {str(es)}')       
def loginclear():
     usernameEntry.delete(0,END)
     passwordEntry.delete(0,END)
    
def hide():
    openeye.config(file='image/closeye.png')
    passwordEntry.config(show='*')
    eyebutton.config(command=show)

def show():
    openeye.config(file='image/openeye.png')
    passwordEntry.config(show='')
    eyebutton.config(command=hide)

def user_enter(event):
    if usernameEntry.get()=='Username':
        usernameEntry.delete(0,END)

def password_enter(event):
    if passwordEntry.get()=='Password':
        passwordEntry.delete(0,END)   
def forget_pass():
    def change_password():
        if user_entry.get()=='' or pass_entry.get()=='' or confirmpass_entry.get()=='':
            messagebox.showerror('Error','All Fileds Are Required',parent=fpass)
        elif pass_entry.get()!=confirmpass_entry.get():
            messagebox.showerror('Error','password and confirm password are not matching',parent=fpass)
        #else:

    fpass=Toplevel(admin)
    fpass.title('Change password')
    bgImage=ImageTk.PhotoImage(Image.open('image/background.jpg'))
    bgLabel=Label(fpass,image=bgImage)
    bgLabel.grid()

    heading=Label(fpass,text='RESET PASSWORD',font=('arial',19,'bold'),bg='white',fg='magenta2')
    heading.place(x=475,y=60)

    user_label=Label(fpass,text='Username',font=('Comic Sans MS',19,'bold'),bg='white',fg='orchid1')
    user_label.place(x=530,y=115)

    user_entry=Entry(fpass,width=25,fg='black',font=('arial',12,'bold'),bd=0)
    user_entry.place(x=470,y=150)

    Frame(fpass,width=250,height=2,bg='orchid1').place(x=470,y=180)

    passwordlabel=Label(fpass,text='New Password',font=('Comic Sans MS',19,'bold'),bg='white',fg='orchid1')
    passwordlabel.place(x=520,y=208)

    pass_entry=Entry(fpass,width=25,fg='black',font=('arial',12,'bold'),bd=0)
    pass_entry.place(x=470,y=250)

    Frame(fpass,width=250,height=2,bg='orchid1').place(x=470,y=270)

    confirmpasslabel=Label(fpass,text='Confirm Password',font=('Comic Sans MS',19,'bold'),bg='white',fg='orchid1')
    confirmpasslabel.place(x=490,y=300)

    confirmpass_entry=Entry(fpass,width=25,fg='black',font=('arial',12,'bold'),bd=0)
    confirmpass_entry.place(x=470,y=347)

    Frame(fpass,width=250,height=2,bg='orchid1').place(x=470,y=367)

    #Button-submit
    submitButton=Button(fpass,text='Submit',bd=0,bg='magenta2',fg='white',font=('Open Sans','16','bold'),
                    width=19,cursor='hand2',activebackground='magenta2',activeforeground='white',command=change_password)
    submitButton.place(x=477,y=410)
    fpass.mainloop()

def back():
    admin.destroy()
    import NEWH
#gui part
admin=Tk()
admin.geometry('990x660+50+50')
admin.resizable(0,0)
admin.title("Bully Box")
bgImage=ImageTk.PhotoImage(Image.open('image/bg.jpg'))

bgLabel=Label(admin,image=bgImage)
bgLabel.place(x=0,y=0)

heading=Label(admin,text='ADMIN LOGIN',font=('Comic Sans MS',22,'bold'),bg='white',fg='red')
heading.place(x=605,y=120)

#-----------
username = StringVar()
passwd = StringVar()
#username entry
usernameEntry=Entry(admin,width=25,font=('Microsoft YaHei UI Light',11,'bold'),bd=0,fg='red',textvariable=username)

usernameEntry.place(x=580,y=200)
usernameEntry.insert(0,'Username')

usernameEntry.bind('<FocusIn>',user_enter)

#line under username
frame1=Frame(admin,width=255,height=2,bg='red').place(x=580,y=224)

#password
passwordEntry=  Entry(admin,width=25,font=('Microsoft YaHei UI Light',11,'bold'),bd=0,fg='red',textvariable=passwd)
passwordEntry.place(x=580,y=260)
passwordEntry.insert(0,'Password')
passwordEntry.config(show='*')
passwordEntry.bind('<FocusIn>',password_enter)
#line under password
frame2=Frame(admin,width=255,height=2,bg='red').place(x=580,y=284)


#eye button
openeye=PhotoImage(file='image/closeye.png')
eyebutton=Button(admin,image=openeye,bd=0,bg='white',activebackground='white',cursor='hand2',command=show)
eyebutton.place(x=800,y=255)
#foget button
forgetbutton=Button(admin,text='Forgot Password?',bd=0,bg='white',activebackground='white',cursor='hand2',font=('Microsoft Yahei UI Light',9,'bold'),fg='red',command=forget_pass)
forgetbutton.place(x=715,y=295)

#loinButton
loginButton=Button(admin,text='Login',font=('Open Sans',16,'bold'),fg='white',bg='red',activeforeground='white',activebackground='red',cursor='hand2',bd=0,width=19,command=login_user)
loginButton.place(x=580,y=352)

#Back Button
loginButton=Button(admin,text='Back',font=('Open Sans',16,'bold'),fg='white',bg='red',activeforeground='white',activebackground='red',cursor='hand2',bd=0,width=19,command=back)
loginButton.place(x=580,y=420)

#orLabel
# orLabel=Label(admin,text='-------------- OR -------------',font=('Open Sans',16),fg='red',bg='white')
# orLabel.place(x=583,y=420)

#register new
# accountLabel=Label(admin,text='Dont have an account?',font=('Open Sans',10,'bold'),fg='red',bg='white')
# accountLabel.place(x=578,y=500)

#newaccount
# newaccountButton=Button(admin,text='Create new one',font=('Open Sans',9,'bold underline'),fg='blue',bg='white',activeforeground='blue',activebackground='white',cursor='hand2',bd=0,command=signup_page)
# newaccountButton.place(x=727,y=500)


admin.mainloop()
