from tkinter import*
from tkinter import ttk
from tkinter import messagebox
import mysql.connector

user = Tk()
user.title('Bully Box')
user.geometry('700x520')
user.config(bg='white')

frame_1 = Frame(user,bg='green').place(x=0,y=0,width=700,height=45)
# l1 = Label(frame_1,text='User Data',font=('Times New Roman',22,'bold'),bg='green',fg='white')
# l1.place(x=270,y=5)

scrollbarx = Scrollbar(user,orient='horizontal')
scrollbary = Scrollbar(user,orient='vertical')

scrollbarx.place(x=20,y=480,width=640,height=20)
scrollbary.place(x=660,y=60,width=20,height=440)

def fetch_data():
    con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
    my_cursor = con.cursor()
    my_cursor.execute('select username,name,email_id,phone_no,address,city from students')
    rows = my_cursor.fetchall()
    # if len(rows)!=0:
    #     my_tree.delete(* my_tree.get_children())
    for items in rows:
            my_tree.insert('',END,values=items)
    con.commit()
    con.close()

my_tree = ttk.Treeview(user)
my_tree.place(x=20,y=60,width=640,height=420)
my_tree.configure(
    columns= ('username','name', 'email' ,'phn','add','city')
)
my_tree.configure(yscrollcommand=scrollbary.set,xscrollcommand=scrollbarx.set)
my_tree.configure(selectmode="extended")

scrollbarx.configure(command=my_tree.xview)
scrollbary.configure(command=my_tree.yview)

my_tree.heading('username',text='Username',anchor=W)
my_tree.heading('name',text='Name',anchor=W)
my_tree.heading('email',text='Email Id',anchor=W)
my_tree.heading('phn',text='Phone no',anchor=W)
my_tree.heading('add',text='Address',anchor=W)
my_tree.heading('city',text='City',anchor=W)

my_tree.column('#1',minwidth=25,width=100)
my_tree.column('#2',minwidth=25,width=200)
my_tree.column('#3',minwidth=25,width=200)
my_tree.column('#4',minwidth=25,width=125)
my_tree.column('#5',minwidth=25,width=200)
my_tree.column('#6',minwidth=25,width=125)
my_tree['show']='headings'
fetch_data()

user.mainloop()