from tkinter  import*
from tkinter import messagebox
from PIL import ImageTk,Image
import mysql.connector

root = Tk()
root.title("Bully Box")
root.geometry("1350x800")

def login():
     return username.get()

def login_function():
      if username.get()=="" or passwd.get=="":
        messagebox.showerror("Error","All fields are required")
      else:
           try: 
               con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
               cur=con.cursor()
               cur.execute('select * from students where username=%s and pwd=%s',(username.get(),passwd.get()))
               row=cur.fetchone()
               if row==None:
                  messagebox.showerror('Error','Invalid Username And Password')
                  loginclear()
                  txtuser.focus()
               else:
                    root.destroy()
                    import dashboard
                    con.close()
           except Exception as es:
                messagebox.showerror('Error',f'Error Due to : {str(es)}')       
def loginclear():
     txtuser.delete(0,END)
     txtpass.delete(0,END)
def back():
      root.destroy()
      import NEWH      

def show():
     openeye.config(file="image/o3.png")
     txtpass.config(show='')
     eyebutton.config(command=hide)
def hide():
     openeye.config(file="image/c2.png")
     txtpass.config(show='*')
     eyebutton.config(command=show)
#--------Images-------
bg_icon=ImageTk.PhotoImage(Image.open("image/img2.jpg"))
user_icon=PhotoImage(file="image/man3.png")
pass_icon=PhotoImage(file="image/download3.png")
logo_icon=PhotoImage(file="image/user1.png")
openeye = PhotoImage(file="image/c2.png")


bg_lbl=Label(root,image=bg_icon).pack()

Login_Frame=Frame(root,bg="white")
Login_Frame.place(x=450,y=120,height=380)
logolbl=Label(Login_Frame,image=logo_icon,bd=1).grid(row=0,columnspan=3,pady=20)
#-----------Textvariable----------
username = StringVar()
passwd = StringVar()

lbluser=Label(Login_Frame,text="Username",image=user_icon,compound=LEFT,font=("times new roman",20,"bold"),bg="white",fg="blue").grid(row=1,column=0,padx=20,pady=10)
txtuser=Entry(Login_Frame,bd=5,relief=GROOVE,font=("",15),textvariable=username)
txtuser.grid(row=1,column=1,padx=20)
lblpass=Label(Login_Frame,text= "Password",image=pass_icon,compound=LEFT,font=("times new roman",20,"bold"),bg="white",fg="blue").grid(row=2,column=0,padx=20,pady=10)
txtpass=Entry(Login_Frame,bd=5,relief=GROOVE,font=("",15),textvariable=passwd)
txtpass.grid(row=2,column=1,padx=20)
txtpass.config(show='*')
eyebutton=Button(Login_Frame,image=openeye,bd=0,bg='white',activebackground='white',cursor='hand2',command=show)
eyebutton.place(x=410,y=239)
forgetbutton=Button(Login_Frame,text='Forgot Password?',bd=0,bg='white',activebackground='white',cursor='hand2',font=("times new roman",15,"bold"),fg='blue')
forgetbutton.place(x=290,y=270)
btn_log=Button(Login_Frame,command=login_function,text="Login",width=15,height=1,font=("times new roman",14,"bold"),bg="#E9967A",activebackground="#E9967A",activeforeground="blue",cursor="hand2",fg="blue").place(x=250,y=310)
btn_back=Button(Login_Frame,command=back,text="Back",width=15,height=1,font=("times new roman",14,"bold"),bg="#E9967A",activebackground="#E9967A",activeforeground="blue",cursor="hand2",fg="blue").place(x=40,y=310)
root.mainloop()
