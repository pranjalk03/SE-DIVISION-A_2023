from tkinter import*
import tkinter as tk
from PIL import ImageTk,Image
from tkinter import messagebox
import mysql.connector
from login_data import login_d
user = login_d()

def fetch_data():
    con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
    my_cursor = con.cursor()
    value = (user,)
    my_cursor.execute(('select * from students where username = %s'),value)
    rows = my_cursor.fetchall()
    for row in rows:
         name.set(row[1])
         email.set(row[2])
         phone.set(row[3])
         address.set(row[4])
         city.set(row[5])
    con.commit()
    con.close()

def update():
    if Name_entry.get()=='' or Email_entry.get()=='' or phone_entry.get()=='' or Address_entry.get()=='' or city_entry.get()=='':
            messagebox.showerror('Error','All Fileds Are Required',parent=profile)
    else:
         con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
         my_cursor = con.cursor()
         my_cursor.execute('Update students set name = %s,email_id = %s, phone_no = %s,address = %s, city = %s where username = %s',(name.get(),email.get(),phone.get(),address.get(),city.get(),user))
         con.commit()
         fetch_data()
         con.close()
         messagebox.showinfo("Success","Record has been updated")
             
profile=tk.Tk()
profile.geometry("990x660+50+50")
profile.title("Bully Box")
bgImage=ImageTk.PhotoImage(Image.open('image/Frame 8.jpg'))
bgLabel=Label(profile,image=bgImage)
bgLabel.place(x=0,y=0)

frame = Frame(profile,bg='#ECECEC',height=555,width=405).place(x=505,y=53)

#-----------Variables-------
name = StringVar()
email = StringVar()
phone = IntVar()
address = StringVar()
city = StringVar()

Name_label=Label(profile,text='Name :',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
Name_label.place(x=510,y=83)

Name_entry=Entry(profile,fg='black',font=('arial',15,'bold'),bg='#ECECEC',bd=0,textvariable=name)
Name_entry.place(x=600,y=90,width=310)

Frame(profile,width=300,height=2,bg='orchid1',bd=1).place(x=600,y=115)

Email_label=Label(profile,text='Email :',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
Email_label.place(x=510,y=180)

Email_entry=Entry(profile,width=34,fg='black',font=('arial',15,'bold'),bg='#ECECEC',bd=0,textvariable=email)
Email_entry.place(x=600,y=187,width=310)

Frame(profile,width=300,height=2,bg='orchid1',bd=1).place(x=600,y=211)

phone_label=Label(profile,text='Phone No.:',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
phone_label.place(x=510,y=277)

phone_entry=Entry(profile,width=29,fg='black',font=('arial',15,'bold'),bg='#ECECEC',bd=0,textvariable=phone)
phone_entry.place(x=649,y=284,width=251)

Frame(profile,width=251,height=2,bg='orchid1',bd=1).place(x=649,y=310)

Address_label=Label(profile,text='Address:',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
Address_label.place(x=510,y=374)

Address_entry=Entry(profile,width=29,fg='black',font=('arial',15,'bold'),bg='#ECECEC',bd=0,textvariable=address)
Address_entry.place(x=625,y=381,width=274)

Frame(profile,width=274,height=2,bg='orchid1',bd=1).place(x=625,y=405)

city_label=Label(profile,text='city/town:',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
city_label.place(x=510,y=471)

city_entry=Entry(profile,width=29,fg='black',font=('arial',15,'bold'),bg='#ECECEC',bd=0,textvariable=city)
city_entry.place(x=630,y=478,width=270)

Frame(profile,width=270,height=2,bg='orchid1',bd=1).place(x=630,y=501)

#button
Button(profile,text="UPDATE",cursor='hand2',activebackground='#dfbbfb',activeforeground='white',bg="#dfbbfb",fg='white',font="20",command=update).place(x=750,y=530)
Button(profile,text="UPDATE",cursor='hand2',activebackground='#dfbbfb',activeforeground='white',bg="#dfbbfb",fg='white',font="20",command=update).place(x=750,y=530)
fetch_data()
profile.mainloop()
