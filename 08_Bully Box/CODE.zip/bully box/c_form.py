from tkinter import*
import tkinter as tk
from tkinter import ttk
from PIL import ImageTk
import mysql.connector
from tkinter import messagebox
from login_data import login_d

root=tk.Tk()
root.geometry("1040x603")
root.title('Bully Box')

username = login_d()
def clear_data():
   name_entry.delete(0,END)
   last_entry.delete(0,END)
   mail_entry.delete(0,END)
   phone_entry.delete(0,END)
   Problem.delete(0,END)
   Detail_entry.delete(0,END)

def send():
   if name_entry=='' or last_entry=='' or mail_entry=='' or phone_entry=='' or Problem=='' or Detail_entry=='':
      messagebox.showerror('Error','All Fileds Are Required')
   else:
      try:
         con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
         my_cursor = con.cursor()
         value = (username,)
         my_cursor.execute(('select * from students where username = %s'),value)
         rows = my_cursor.fetchall()
         for row in rows:
            name = row[1]
            email = row[2]
            phone = row[3]
         con.close()
         if username != username_info.get():
            messagebox.showerror('Error','Invalid Username. Please enter your Username.')
         elif name != name_info.get():
            messagebox.showerror('Error','Invalid Name. Please enter your Name.')
         elif email != Email_info.get():
            messagebox.showerror('Error','Invalid Email Id. Please enter your Email Id.')
         elif phone != phone_info.get():
            messagebox.showerror('Error','Invalid Phone no. Please enter your Phone.')
         else:
            con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
            my_cursor = con.cursor()
            my_cursor.execute('Insert into appointment values(%s,%s,%s,%s,%s,%s)',(name_entry.get(),last_entry.get(),mail_entry.get(),phone_entry.get(),Problem.get(),Detail_entry.get(1.0, "end-1c")))
            con.commit() 
            messagebox.showinfo("Success","Record has been submitted")
            clear_data()
            name_entry.focus()
            con.close()     
      except Exception as es:
         messagebox.showerror('Error',f'Error Due to : {str(es)}') 

#label
Label(root,text="Counselling Appointment Form",font="ariel 20 bold",bg="#55185D",fg='white').pack(fill="both")
Label(root,text="Username",font=("Comic Sans MS",20)).place(x=40,y=75)
Label(root,text="Name",font=("Comic Sans MS",20)).place(x=600,y=75)
# Label(root,text="UserId",font=("Comic Sans MS",20)).place(x=40,y=150)
# Label(root,text="Password",font=("Comic Sans MS",20)).place(x=600,y=150)
Label(root,text="Email Id",font=("Comic Sans MS",20)).place(x=40,y=150)
Label(root,text="Phone No.",font=("Comic Sans MS",20)).place(x=600,y=150)
Label(root,text="Problem",font=("Comic Sans MS",20)).place(x=40,y=225)
Label(root,text="Detail",font=("Comic Sans MS",20)).place(x=40,y=300)
#drop down menu
Problems=['Anxiety','Depression','Loneliness','Aggressive Behavior','Other']
Problem=ttk.Combobox(root,values=Problems,font="10")
Problem.place(x=220,y=235)

#Entry
username_info=StringVar()
name_info=StringVar()
Email_info=StringVar()
phone_info=IntVar()
# Detail_info=StringVar()

name_entry=Entry(root,font=('Canva Sans',13),bd=2,textvariable=username_info,relief=GROOVE)
name_entry.place(x=220,y=86,width=200,height=25)
last_entry=Entry(root,font=('Canva Sans',13),bd=2,textvariable=name_info,relief=GROOVE)
last_entry.place(x=770,y=86,width=200,height=25)
mail_entry=Entry(root,font=('Canva Sans',13),bd=2,textvariable=Email_info,relief=GROOVE)
mail_entry.place(x=220,y=162,width=200,height=25)
phone_entry=Entry(root,font=('Canva Sans',13),bd=2,textvariable=phone_info,relief=GROOVE)
phone_entry.place(x=770,y=162,width=200,height=25)
Detail_entry=Text(root,font=('Canva Sans',13),bd=2,relief=GROOVE)
Detail_entry.place(x=220,y=305,width=700,height=100)

#Button
Button(root,text="SEND",bd=1,bg="#55185D",fg='white',font="20",cursor='hand2',command=send).place(x=550,y=450)
root.mainloop()