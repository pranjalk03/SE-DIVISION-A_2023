from tkinter import*
from tkinter import ttk
from tkinter import messagebox
import mysql.connector
from login_data import login_d

username = login_d()
user = username

def disp():
    def submit():
        f1.destroy()
        b1.destroy()
    def gets(event=''):
        global cid
        cid = sel.get()
        con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
        my_cursor = con.cursor()    
        my_cursor.execute('Select * from cstatus where c_id = %s',(cid,))
        info = my_cursor.fetchall()
        for row in info:
            c = row[2]
            if row[1] == 'Received':
                s = 'Received'
            elif row[1] == 'Assigned':
                s = 'Assigned'
            elif row[1] == 'Under Investigation':
                s = 'Under Investigation'
            elif row[1] == 'Resolved':
                s = 'Resolved' 
            elif row[1] == 'Rejected':
                s = 'Rejected'
        t2.insert(END,s)
        t1.insert(END,c)
    l1.config(text='')      
    f1 = Frame(root1,bg='white',height=450,width=500)
    f1.place(x=0,y=120)
    Label(f1,text='Status:',font=('Times New Roman',15,'bold'),bg='white',fg='black').place(x=80,y=20)
    Label(f1,text='Comment:',font=('Times New Roman',15,'bold'),bg='white',fg='black').place(x=50,y=90)
    t1 = Text(f1,font=('Canva Sans',12),fg='black',bg='white',bd=0,relief=GROOVE)
    t1.place(x=150,y=95,height=200,width=300)
    t2 = Text(f1,font=('Canva Sans',12),fg='black',bg='white',bd=0,relief=GROOVE)
    t2.place(x=150,y=25,height=25,width=200)
    e = Entry(f1)
    e.place(x=50,y=520,height=10,width=10)
    e.focus()
    id.bind("<FocusOut>",gets)
    b1 =Button(root1,text='OKAY',font=('Times New Roman',13),bg='#E6E6FA',fg='black',relief='groove',activeforeground='black',activebackground='#E6E6FA',cursor='hand2',command=submit)
    b1.place(x=225,y=400)    

def upd(*args):
    my_list = []
    values =(user,"%" + id.get() + "%",)
    con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
    my_cursor = con.cursor()
    my_cursor.execute('select c_id from inbox where from_1 = %s and c_id like %s',values)
    data = my_cursor.fetchall()
    for row in data:
        my_list.append(row[0])
    con.commit()
    con.close()
    id['values']=[]
    id['values']= my_list
    l1.config(text='Result:'+str(len(data)))

root1=Tk()
root1.title("Bully Box")
root1.geometry('500x500+0+0')
root1.config(bg='white')
root1.resizable()

frame = Frame(root1,bg='#C2E5D3',height=45,width=500)
frame.place(x=0,y=0)
Label(frame,text='Complaint Tracker',font=('Times New Roman',20,'bold'),bg='#C2E5D3',fg='black').place(x=140,y=4)

my_list=[]
con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
my_cursor = con.cursor()
my_cursor.execute('select c_id from inbox where from_1 = %s ',(user,))
data = my_cursor.fetchall()
for row in data:
    my_list.append(row[0])
con.commit()
con.close()

id_label = Label(root1,text='Complaint Id',font=('Times New Roman',15,'bold'),bg='white',fg='black')
id_label.place(x=50,y=70)
sel = StringVar()
id = ttk.Combobox(root1,values=my_list,width=25,height=30,textvariable=sel)
id.place(x=180,y=72)
sel.trace("w", upd)
l1 = Label(root1,text='',font=('Times New Roman',13,'bold'),bg='white',fg='black')
l1.place(x=390,y=70)

b1 =Button(root1,text='Submit',font=('Times New Roman',13),bg='#E6E6FA',fg='black',relief='groove',activeforeground='black',activebackground='#E6E6FA',cursor='hand2',command=disp)
b1.place(x=225,y=120)

root1.mainloop()