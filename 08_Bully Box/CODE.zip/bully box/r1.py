from tkinter import *
from tkinter import messagebox
from PIL import ImageTk,Image
import mysql.connector

def clear_data():
   userEntry.delete(0,END)
   NameEntry.delete(0,END)
   GmailEntry.delete(0,END)
   passwordEntry.delete(0,END)
def reg():
    if userEntry=='' or NameEntry=='' or GmailEntry=='' or passwordEntry=='':
      messagebox.showerror('Error','All Fileds Are Required')
    else:
        try:
            con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
            my_cursor = con.cursor()
            value = (userEntry.get(),)
            my_cursor.execute(('select * from students where username = %s'),value)
            row=my_cursor.fetchone()
            if row == 1:
                messagebox.showerror('Error','This username exists')
            else:
                my_cursor.execute('Insert into students(username,name,email_id,pwd) values(%s,%s,%s,%s)',(userEntry.get(),NameEntry.get(),GmailEntry.get(),passwordEntry.get()))
            con.commit()
            messagebox.showinfo("Success","Record has been submitted")
            clear_data()
            userEntry.focus()
            con.close()
        except Exception as es:
            con.rollback()
            messagebox.showerror('Error',f'Error Due to : {str(es)}')

fpass=Tk()
fpass.title('Bully Box')
bgImage=ImageTk.PhotoImage(Image.open('image/background.jpg'))
bgLabel=Label(fpass,image=bgImage)
bgLabel.grid()

frame=Frame(fpass,bg='white')
frame.place(x=440,y=39,width=315,height=440)

heading=Label(frame,text='Registration',font=('Comic Sans MS',20,'bold'),bg='white',fg='red')
heading.grid(row=0,column=0,padx=10,pady=10)
#--------- text variables----
user = IntVar()
name = StringVar()
mail = StringVar()
pwd = StringVar()

#Username craete
userLabel=Label(frame,text='Username',font=('Microsoft YaHei UI Light',12,'bold'),fg='red',bg='white')
userLabel.grid(row=1,column=0,sticky='w',padx=25,pady=(10,0))

userEntry=Entry(frame,width=30,font=('Microsoft YaHei UI Light',10,'bold'),fg='red',bd=0,highlightbackground='red',highlightthickness=1)
userEntry.grid(row=2,column=0,sticky='w',padx=25)

# Frame(frame,width=225,height=2,bg='red').place(x=25,y=123)

#gmail
NameLabel=Label(frame,text='Student Name',font=('Microsoft YaHei UI Light',12,'bold'),fg='red',bg='white')
NameLabel.grid(row=3,column=0,sticky='w',padx=25,pady=(10,0))

NameEntry=Entry(frame,width=30,font=('Microsoft YaHei UI Light',10,'bold'),fg='red',bd=0,highlightbackground='red',highlightthickness=1)
NameEntry.grid(row=4,column=0,sticky='w',padx=25)

#password
GmailLabel=Label(frame,text='Gmail',font=('Microsoft YaHei UI Light',12,'bold'),fg='red',bg='white')
GmailLabel.grid(row=5,column=0,sticky='w',padx=25,pady=(10,0))

GmailEntry=Entry(frame,width=30,font=('Microsoft YaHei UI Light',10,'bold'),fg='red',bd=0,highlightbackground='red',highlightthickness=1)
GmailEntry.grid(row=6,column=0,sticky='w',padx=25)

#confirm
passwordLabel=Label(frame,text='Password',font=('Microsoft YaHei UI Light',12,'bold'),fg='red',bg='white')
passwordLabel.grid(row=7,column=0,sticky='w',padx=25,pady=(10,0))

passwordEntry=Entry(frame,width=30,font=('Microsoft YaHei UI Light',10,'bold'),fg='red',bd=0,highlightbackground='red',highlightthickness=1)
passwordEntry.grid(row=8,column=0,sticky='w',padx=25)


#signup button
signupButton=Button(frame,text='Signup',font=('Microsoft Yahei UI Light',17,'bold'),bd=0,bg='firebrick1',fg='white',activebackground='white',cursor='hand2',activeforeground='firebrick1',command=reg)
signupButton.place(x=50,y=350,width=200,height=50)

fpass.mainloop()