from tkinter import*
from tkinter import ttk
from tkinter import messagebox
import mysql.connector

def disp():
    l1.config(text='')
    def submit():
        if var.get() == 1:
            s = 'Received'
        elif var.get() == 2:
            s = 'Assigned'
        elif var.get() == 3:
            s = 'Under Investigation' 
        elif var.get() == 4:
            s = 'Resolved'
        elif var.get() == 5:
            s = 'Rejected'           
        con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
        my_cursor = con.cursor()
        my_cursor.execute('Update cstatus set status = %s , comment = %s where c_id = %s',(s,t1.get(1.0, "end-1c"),cid,))
        i = 'Your complaint is '+s+'\n'+t1.get(1.0, "end-1c")
        sub = 'Complaint Status'
        my_cursor.execute('Insert into inbox(to_1,from_1,subject,details) values(%s,%s,%s,%s)',(username,'HOD',sub,i))
        con.commit()
        con.close()
        messagebox.showinfo("Success","Status has been updated")
        b1.destroy()   
        f1.destroy()
    def gets(event=''):
        global cid
        cid = sel.get()
        con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
        my_cursor = con.cursor()    
        my_cursor.execute('Select * from cstatus where c_id = %s',(cid,))
        info = my_cursor.fetchall()
        for row in info:
            c = row[2]
            if row[1] == 'Received':
                var.set(value=1)
            elif row[1] == 'Assigned':
                var.set(value=2)
            elif row[1] == 'Under Investigation':
                var.set(value=3)
            elif row[1] == 'Resolved':
                var.set(value=4) 
            elif row[1] == 'Rejected':
                var.set(value=5)
        t1.insert(END,c)
        my_cursor.execute('Select * from inbox where c_id = %s',(cid,))
        in_fo = my_cursor.fetchall()
        for row in in_fo:
            global username
            username = row[1]
        con.commit()
        con.close()       
    f1 = Frame(root1,bg='white',height=450,width=500)
    f1.place(x=0,y=120)
    Label(f1,text='Status',font=('Times New Roman',15,'bold'),bg='white',fg='black').place(x=70,y=10)
    var = IntVar()
    r1 = Radiobutton(f1,text='Received',variable=var,value=1,font=('Times New Roman',14),bg='white',fg='black')
    r1.place(x=180,y=10)
    r2 = Radiobutton(f1,text='Assigned',variable=var,value=2,font=('Times New Roman',14),bg='white',fg='black')
    r2.place(x=180,y=40)   
    r3 = Radiobutton(f1,text='Under Investigation',variable=var,value=3,font=('Times New Roman',14),bg='white',fg='black')
    r3.place(x=180,y=70)
    r4 = Radiobutton(f1,text='Resolved',variable=var,value=4,font=('Times New Roman',14),bg='white',fg='black')
    r4.place(x=180,y=100)
    r5 = Radiobutton(f1,text='Rejected',variable=var,value=5,font=('Times New Roman',14),bg='white',fg='black')
    r5.place(x=180,y=130)
    Label(f1,text='Comment',font=('Times New Roman',15,'bold'),bg='white',fg='black').place(x=50,y=180)
    t1 = Text(f1,font=('Canva Sans',11),fg='black',bg='white',bd=2,relief=GROOVE)
    t1.place(x=180,y=180,height=200,width=300)
    e = Entry(f1)
    e.place(x=50,y=520,height=10,width=10)
    e.focus()
    id.bind("<FocusOut>",gets)
    b1 =Button(root1,text='Update Status',font=('Times New Roman',13),bg='#E6E6FA',fg='black',relief='groove',activeforeground='black',activebackground='#E6E6FA',cursor='hand2',command=submit)
    b1.place(x=50,y=520)

def upd(*args):
    my_list = []
    values =("%" + id.get() + "%",)
    con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
    my_cursor = con.cursor()
    my_cursor.execute('select c_id from inbox where c_id like %s',values)
    data = my_cursor.fetchall()
    for row in data:
        my_list.append(row[0])
    con.commit()
    con.close()
    id['values']=[]
    id['values']= my_list
    l1.config(text='Result:'+str(len(data)))

root1 = Tk()
root1.title("Bully Box")
root1.geometry('500x570+0+0')
root1.config(bg='white')
root1.resizable()

my_list=[]
con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
my_cursor = con.cursor()
my_cursor.execute('select c_id from inbox where c_id is NOT NULL ')
data = my_cursor.fetchall()
for row in data:
    my_list.append(row[0])
con.commit()
con.close()

frame = Frame(root1,bg='#C2E5D3',height=45,width=500)
frame.place(x=0,y=0)
Label(frame,text='Complaint Status',font=('Times New Roman',20,'bold'),bg='#C2E5D3',fg='black').place(x=140,y=4)

id_label = Label(root1,text='Complaint Id',font=('Times New Roman',15,'bold'),bg='white',fg='black')
id_label.place(x=50,y=70)
sel = StringVar()
id = ttk.Combobox(root1,values=my_list,width=25,height=30,textvariable=sel)
id.place(x=180,y=72)
sel.trace("w", upd)
l1 = Label(root1,text='',font=('Times New Roman',13,'bold'),bg='white',fg='black')
l1.place(x=390,y=70)

b1 =Button(root1,text='Submit',font=('Times New Roman',13),bg='#E6E6FA',fg='black',relief='groove',activeforeground='black',activebackground='#E6E6FA',cursor='hand2',command=disp)
b1.place(x=225,y=120)
root1.mainloop()