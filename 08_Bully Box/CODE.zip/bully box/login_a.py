from Signadmin import login_info

user = login_info()

def login_d():
    return user