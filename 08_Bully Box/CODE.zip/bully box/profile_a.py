from tkinter import*
import tkinter as tk
from tkinter import ttk
from PIL import ImageTk,Image
from tkinter import messagebox

def update():
    if Name_entry.get()=='' or Email_entry.get()=='' or phone_entry.get()=='' or Address_entry.get()=='' or city_entry.get()=='':
            messagebox.showerror('Error','All Fileds Are Required',parent=root)
    #else
    
root=tk.Tk()
root.geometry("990x660+50+50")
root.title("Bully Box")
bgImage=ImageTk.PhotoImage(Image.open('image/Frame 8.jpg'))

bgLabel=Label(root,image=bgImage)
bgLabel.place(x=0,y=0)

Name_label=Label(root,text='Name :',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
Name_label.place(x=510,y=83)

Name_entry=Entry(root,width=34,fg='black',font=('arial',12,'bold'),bg='#ECECEC',bd=0)
Name_entry.place(x=600,y=90)

Frame(root,width=310,height=2,bg='orchid1',bd=1).place(x=600,y=115)

Email_label=Label(root,text='Email :',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
Email_label.place(x=510,y=180)

Email_entry=Entry(root,width=34,fg='black',font=('arial',12,'bold'),bg='#ECECEC',bd=0)
Email_entry.place(x=600,y=190)

Frame(root,width=310,height=2,bg='orchid1',bd=1).place(x=600,y=215)

phone_label=Label(root,text='Phone No.:',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
phone_label.place(x=510,y=277)

phone_entry=Entry(root,width=29,fg='black',font=('arial',12,'bold'),bg='#ECECEC',bd=0)
phone_entry.place(x=645,y=290)

Frame(root,width=265,height=2,bg='orchid1',bd=1).place(x=645,y=310)

Address_label=Label(root,text='Address:',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
Address_label.place(x=510,y=374)

Address_entry=Entry(root,width=29,fg='black',font=('arial',12,'bold'),bg='#ECECEC',bd=0)
Address_entry.place(x=645,y=380)

Frame(root,width=265,height=2,bg='orchid1',bd=1).place(x=644,y=405)

city_label=Label(root,text='city/town:',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
city_label.place(x=510,y=471)

city_entry=Entry(root,width=29,fg='black',font=('arial',12,'bold'),bg='#ECECEC',bd=0)
city_entry.place(x=645,y=475)

Frame(root,width=265,height=2,bg='orchid1',bd=1).place(x=644,y=497)

#button
Button(root,text="UPDATE",cursor='hand2',activebackground='#dfbbfb',activeforeground='white',bg="#dfbbfb",fg='white',font="20",command=update).place(x=650,y=530)


root.mainloop()
