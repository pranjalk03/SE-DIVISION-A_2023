from tkinter import *
from PIL import Image,ImageTk
from tkinter import ttk
from login_a import login_d
import mysql.connector
from tkinter import messagebox
import random

root=Tk()
root.title("Bully Box")
root.state('zoomed')
root.config(bg='#F6F8F9')
root.resizable()

username = login_d()
user = username
def view(event=''):
    global from_1
    global sub
    def clear():
        from_entry.delete(0,END)
        sub_entry.delete(1.0, "end-1c")
        det_entry.delete(1.0, "end-1c")
    cursor_row = inbox_table.focus()
    data = inbox_table.item(cursor_row)
    row = data['values']
    from_1 = row[0]
    sub = row[1]
    con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
    my_cursor = con.cursor()
    my_cursor.execute('Select * from draft where to_1 = %s AND subject= %s',(from_1,sub))
    rows = my_cursor.fetchall()
    for row in rows:
        clear()
        from_view.set(from_1)
        sub_entry.insert(END,row[2])
        det_entry.insert(END,row[3])
    fetch_all()
    fetch()
    con.commit()
    con.close()

def dt():    
    def clear():
        from_entry.delete(0,END)
        sub_entry.delete(1.0, "end-1c")
        det_entry.delete(1.0, "end-1c")
    con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
    my_cursor = con.cursor()
    my_cursor.execute('Select * from draft where to_1 = %s AND subject= %s AND username = %s',(from_1,sub,user))
    rows = my_cursor.fetchall()
    for row in rows:
        to = row[0]
        subject = row[2]
        detail = row[3]
    con.commit()
    con.close()
    if to == from_view.get() and subject == sub_entry.get(1.0, "end-1c") and detail == det_entry.get(1.0, "end-1c"):
        fetch()
        fetch_all()        
        clear()
    else:
        if user =='10036810':
            frm = 'HOD'
        else:
            frm = 'Staff'
        con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
        my_cursor = con.cursor()
        my_cursor.execute('Delete from draft where to_1 = %s AND subject= %s AND details= %s AND username = %s',(to,subject,detail,username,))        
        my_cursor.execute('Insert into draft values(%s,%s,%s,%s,%s)',(from_view.get(),frm,sub_entry.get(1.0, "end-1c"),det_entry.get(1.0, "end-1c"),username,))
        fetch_all()
        fetch()        
        clear()
        con.commit()
        con.close()
        messagebox.showinfo("Success","Complaint has been saved in draft.")

def reg():
        def clear():
            from_entry.delete(0,END)
            sub_entry.delete(1.0, "end-1c")
            det_entry.delete(1.0, "end-1c")
        con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
        my_cursor = con.cursor()
        my_cursor.execute('Select * from draft where to_1 = %s AND subject= %s AND username = %s',(from_1,sub,user))
        rows = my_cursor.fetchall()
        for row in rows:
            to = row[0]
            subject = row[2]
            detail = row[3]
        con.commit()
        con.close()
        user_1 = from_view.get()
        con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
        cur=con.cursor()
        cur.execute('select * from students where username=%s',(user_1,))
        row=cur.fetchone()
        if user == '10036810':
            if row == None:
                cur.execute('select * from admin where username=%s',(user_1,))
                row=cur.fetchone()
                if row == None:
                    s = 0
                else:
                    s = 1
            else:
                s = 1
        else:
            cur.execute('select * from admin where username=%s',(user_1,))
            row=cur.fetchone()
            if row == None:
                    s = 0
            else:
                    s = 1           
        con.commit()
        con.close()
        if from_view.get()=='' or sub_entry.get(1.0, "end-1c")=='' or det_entry.get(1.0, "end-1c")=='':
            messagebox.showerror('Error','All Fileds Are Required')
        elif s == 1:
            try:
                con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
                my_cursor = con.cursor()
                if user=='10036810':
                    frm = 'HOD'
                else:
                    frm = 'Staff'
                my_cursor.execute('Insert into inbox(to_1,from_1,subject,details) values(%s,%s,%s,%s)',(from_view.get(),frm,sub_entry.get(1.0, "end-1c"),det_entry.get(1.0, "end-1c")))
                my_cursor.execute('Delete from draft where to_1 = %s AND subject= %s AND details= %s AND username = %s',(to,subject,detail,user,))
                con.commit()
                con.close()
                fetch()
                fetch_all()  
                clear()
                messagebox.showinfo("Success","Message has been sent")
            except Exception as es:
                con.rollback()
                messagebox.showerror('Error',f'Error Due to : {str(es)}')
        else:
            messagebox.showerror('Error','Invalid Username of the receiver. Please enter correct Username.')
def fetch():
    con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
    my_cursor = con.cursor()
    my_cursor.execute('select to_1,subject from draft where username = %s',(username,))
    rows = my_cursor.fetchall()
    if len(rows)!=0:
        inbox_table.delete(* inbox_table.get_children())
        for items in rows:
            inbox_table.insert('',END,values=items)
        con.commit()
    con.close()
def fetch_all():
    con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
    my_cursor = con.cursor()
    my_cursor.execute('select c_id from inbox where c_id IS NOT NULL')
    rows = my_cursor.fetchall()
    if len(rows)!=0:
        table.delete(* table.get_children())
        for items in rows:
                table.insert('',END,values=items)
        con.commit()
    con.close()
def dd():
    root.destroy()
    import a_dashboard
def ix():
    f1.destroy()
def ur():
    def clear_data():
        userEntry.delete(0,END)
        NameEntry.delete(0,END)
        GmailEntry.delete(0,END)
        passwordEntry.delete(0,END)
    def reg():
        if userEntry=='' or NameEntry=='' or GmailEntry=='' or passwordEntry=='':
            messagebox.showerror('Error','All Fileds Are Required')
        else:
            try:
                con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
                my_cursor = con.cursor()
                value = (userEntry.get(),)
                my_cursor.execute(('select * from students where username = %s'),value)
                row=my_cursor.fetchone()
                if row == 1:
                    messagebox.showerror('Error','This username exists')
                else:
                    my_cursor.execute('Insert into students(username,name,email_id,pwd) values(%s,%s,%s,%s)',(userEntry.get(),NameEntry.get(),GmailEntry.get(),passwordEntry.get()))
                con.commit()
                messagebox.showinfo("Success","Record has been submitted")
                clear_data()
                userEntry.focus()
                con.close()
            except Exception as es:
                con.rollback()
                messagebox.showerror('Error',f'Error Due to : {str(es)}')

    fpass=Toplevel(root)
    fpass.title('Bully Box')
    bgImage=ImageTk.PhotoImage(Image.open('image/background.jpg'))
    bgLabel=Label(fpass,image=bgImage)
    bgLabel.grid()

    frame=Frame(fpass,bg='white')
    frame.place(x=440,y=39,width=315,height=440)

    heading=Label(frame,text='Registration',font=('Comic Sans MS',20,'bold'),bg='white',fg='red')
    heading.grid(row=0,column=0,padx=10,pady=10)

    #Username craete
    userLabel=Label(frame,text='Username',font=('Microsoft YaHei UI Light',12,'bold'),fg='red',bg='white')
    userLabel.grid(row=1,column=0,sticky='w',padx=25,pady=(10,0))

    userEntry=Entry(frame,width=30,font=('Microsoft YaHei UI Light',10,'bold'),fg='red',bd=0,highlightbackground='red',highlightthickness=1)
    userEntry.grid(row=2,column=0,sticky='w',padx=25)

    # Frame(frame,width=225,height=2,bg='red').place(x=25,y=123)

    #gmail
    NameLabel=Label(frame,text='Student Name',font=('Microsoft YaHei UI Light',12,'bold'),fg='red',bg='white')
    NameLabel.grid(row=3,column=0,sticky='w',padx=25,pady=(10,0))
    
    NameEntry=Entry(frame,width=30,font=('Microsoft YaHei UI Light',10,'bold'),fg='red',bd=0,highlightbackground='red',highlightthickness=1)
    NameEntry.grid(row=4,column=0,sticky='w',padx=25)

    #password
    GmailLabel=Label(frame,text='Gmail',font=('Microsoft YaHei UI Light',12,'bold'),fg='red',bg='white')
    GmailLabel.grid(row=5,column=0,sticky='w',padx=25,pady=(10,0))
    
    GmailEntry=Entry(frame,width=30,font=('Microsoft YaHei UI Light',10,'bold'),fg='red',bd=0,highlightbackground='red',highlightthickness=1)
    GmailEntry.grid(row=6,column=0,sticky='w',padx=25)

    #confirm
    passwordLabel=Label(frame,text='Password',font=('Microsoft YaHei UI Light',12,'bold'),fg='red',bg='white')
    passwordLabel.grid(row=7,column=0,sticky='w',padx=25,pady=(10,0))
    
    passwordEntry=Entry(frame,width=30,font=('Microsoft YaHei UI Light',10,'bold'),fg='red',bd=0,highlightbackground='red',highlightthickness=1)
    passwordEntry.grid(row=8,column=0,sticky='w',padx=25)

    #signup button
    signupButton=Button(frame,text='Signup',font=('Microsoft Yahei UI Light',17,'bold'),bd=0,bg='firebrick1',fg='white',activebackground='white',cursor='hand2',activeforeground='firebrick1',command=reg)
    signupButton.place(x=50,y=350,width=200,height=50)

    fpass.mainloop()
def cs():
    def disp():
        l1.config(text='')
        def submit():
            if var.get() == 1:
                s = 'Received'
            elif var.get() == 2:
                s = 'Assigned'
            elif var.get() == 3:
                s = 'Under Investigation' 
            elif var.get() == 4:
                s = 'Resolved'
            elif var.get() == 5:
                s = 'Rejected'           
            con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
            my_cursor = con.cursor()
            my_cursor.execute('Update cstatus set status = %s , comment = %s where c_id = %s',(s,t1.get(1.0, "end-1c"),cid,))
            i = 'Your complaint is '+s+'\n'+t1.get(1.0, "end-1c")
            sub = 'Complaint Status'
            my_cursor.execute('Insert into inbox(to_1,from_1,subject,details) values(%s,%s,%s,%s)',(username,'HOD',sub,i))
            con.commit()
            con.close()
            messagebox.showinfo("Success","Status has been updated")
            b1.destroy()   
            f1.destroy()
        def gets(event=''):
            global cid
            cid = sel.get()
            con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
            my_cursor = con.cursor()    
            my_cursor.execute('Select * from cstatus where c_id = %s',(cid,))
            info = my_cursor.fetchall()
            for row in info:
                c = row[2]
                if row[1] == 'Received':
                    var.set(value=1)
                elif row[1] == 'Assigned':
                    var.set(value=2)
                elif row[1] == 'Under Investigation':
                    var.set(value=3)
                elif row[1] == 'Resolved':
                    var.set(value=4) 
                elif row[1] == 'Rejected':
                    var.set(value=5)
            t1.insert(END,c)
            my_cursor.execute('Select * from inbox where c_id = %s',(cid,))
            in_fo = my_cursor.fetchall()
            for row in in_fo:
                global username
                username = row[1]
            con.commit()
            con.close()       
        f1 = Frame(root1,bg='white',height=450,width=500)
        f1.place(x=0,y=120)
        Label(f1,text='Status',font=('Times New Roman',15,'bold'),bg='white',fg='black').place(x=70,y=10)
        var = IntVar()
        r1 = Radiobutton(f1,text='Received',variable=var,value=1,font=('Times New Roman',14),bg='white',fg='black')
        r1.place(x=180,y=10)
        r2 = Radiobutton(f1,text='Assigned',variable=var,value=2,font=('Times New Roman',14),bg='white',fg='black')
        r2.place(x=180,y=40)   
        r3 = Radiobutton(f1,text='Under Investigation',variable=var,value=3,font=('Times New Roman',14),bg='white',fg='black')
        r3.place(x=180,y=70)
        r4 = Radiobutton(f1,text='Resolved',variable=var,value=4,font=('Times New Roman',14),bg='white',fg='black')
        r4.place(x=180,y=100)
        r5 = Radiobutton(f1,text='Rejected',variable=var,value=5,font=('Times New Roman',14),bg='white',fg='black')
        r5.place(x=180,y=130)
        Label(f1,text='Comment',font=('Times New Roman',15,'bold'),bg='white',fg='black').place(x=50,y=180)
        t1 = Text(f1,font=('Canva Sans',11),fg='black',bg='white',bd=2,relief=GROOVE)
        t1.place(x=180,y=180,height=200,width=300)
        e = Entry(f1)
        e.place(x=50,y=520,height=10,width=10)
        e.focus()
        id.bind("<FocusOut>",gets)
        b1 =Button(root1,text='Update Status',font=('Times New Roman',13),bg='#E6E6FA',fg='black',relief='groove',activeforeground='black',activebackground='#E6E6FA',cursor='hand2',command=submit)
        b1.place(x=50,y=520)

    def upd(*args):
        my_list = []
        values =("%" + id.get() + "%",)
        con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
        my_cursor = con.cursor()
        my_cursor.execute('select c_id from inbox where c_id like %s',values)
        data = my_cursor.fetchall()
        for row in data:
            my_list.append(row[0])
        con.commit()
        con.close()
        id['values']=[]
        id['values']= my_list
        l1.config(text='Result:'+str(len(data)))

    root1 = Toplevel(root)
    root1.title("Bully Box")
    root1.geometry('500x570+0+0')
    root1.config(bg='white')
    root1.resizable()

    my_list=[]
    con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
    my_cursor = con.cursor()
    my_cursor.execute('select c_id from inbox where c_id is NOT NULL ')
    data = my_cursor.fetchall()
    for row in data:
        my_list.append(row[0])
    con.commit()
    con.close()

    frame = Frame(root1,bg='#C2E5D3',height=45,width=500)
    frame.place(x=0,y=0)
    Label(frame,text='Complaint Status',font=('Times New Roman',20,'bold'),bg='#C2E5D3',fg='black').place(x=140,y=4)

    id_label = Label(root1,text='Complaint Id',font=('Times New Roman',15,'bold'),bg='white',fg='black')
    id_label.place(x=50,y=70)
    sel = StringVar()
    id = ttk.Combobox(root1,values=my_list,width=25,height=30,textvariable=sel)
    id.place(x=180,y=72)
    sel.trace("w", upd)
    l1 = Label(root1,text='',font=('Times New Roman',13,'bold'),bg='white',fg='black')
    l1.place(x=390,y=70)

    b1 =Button(root1,text='Submit',font=('Times New Roman',13),bg='#E6E6FA',fg='black',relief='groove',activeforeground='black',activebackground='#E6E6FA',cursor='hand2',command=disp)
    b1.place(x=225,y=120)
    root1.mainloop()
    
def ud():
    import userdata
def m():
        global f1
        f1= Frame(root,width=250,height=255,bg='#FFFFFF',highlightbackground='black',highlightthickness=1)
        f1.place(x=0,y=65)    
        def bttn(x,y,text,bcolor,fcolor,cmd):
            def on_entera(e):
                myButton1['background'] = bcolor 
                myButton1['foreground']= '#262626'  

            def on_leavea(e):
                myButton1['background'] = fcolor
                myButton1['foreground']= '#262626'

            myButton1 = Button(f1,text=text,
                       fg='#262626',
                       border=0,
                       font=('Canva Sans',15),
                       bg=fcolor,
                       activeforeground='#262626',
                       activebackground=bcolor,
                       cursor='hand2',           
                        command=cmd)
                      
            myButton1.bind("<Enter>", on_entera)
            myButton1.bind("<Leave>", on_leavea)

            myButton1.place(x=x,y=y,width=248,height=50)

        bttn(0,0,'Dashboard','#F6F8F9','#FFFFFF',dd)
        bttn(0,50,'Inbox','#F6F8F9','#FFFFFF',ix)
        bttn(0,100,'User registration','#F6F8F9','#FFFFFF',ur)
        bttn(0,150,'Complaint Status','#F6F8F9','#FFFFFF',cs)
        bttn(0,200,'User Data','#F6F8F9','#FFFFFF',ud)
        
        def delete():
            f1.destroy()
            menu_button= Button(navbar, image = menu_img,bg='white', cursor="hand2",borderwidth=0,command=m)
            menu_button.place(x=10,y=10,width=50,height=50)
        Button(navbar, image = menu_img,bg='#F6F8F9', cursor="hand2",borderwidth=0,activebackground='#FFFFFF',command=delete).place(x=10,y=10,width=50,height=50)
def ep():
    def fetch_data():
        try:
            con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
            my_cursor = con.cursor()
            value = (username,)
            my_cursor.execute(('select * from admin where username = %s'),value)
            rows = my_cursor.fetchall()
            for row in rows:
                name.set(row[1])
                email.set(row[3])
                phone.set(row[4])
                address.set(row[5])
                city.set(row[6])
            con.commit()
            con.close()
        except Exception as es:
                messagebox.showerror('Error',f'Error Due to : {str(es)}') 

    def update():
        if Name_entry.get()=='' or Email_entry.get()=='' or phone_entry.get()=='' or Address_entry.get()=='' or city_entry.get()=='':
            messagebox.showerror('Error','All Fileds Are Required',parent=profile)
        else:
         con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
         my_cursor = con.cursor()
         my_cursor.execute('Update admin set name = %s,email_id = %s, phone_no = %s,address = %s, city = %s where username = %s',(name.get(),email.get(),phone.get(),address.get(),city.get(),username))
         con.commit()
         fetch_data()
         con.close()
         messagebox.showinfo("Success","Record has been updated")
    profile=Toplevel()
    profile.geometry("990x660+50+50")
    profile.title('Profile')
    bgImage=ImageTk.PhotoImage(Image.open('image/Frame 8.jpg'))
    bgLabel=Label(profile,image=bgImage)
    bgLabel.place(x=0,y=0)
     
    frame = Frame(profile,bg='#ECECEC',height=555,width=405)
    frame.place(x=505,y=53)
    
    #-----------Variables-------
    name = StringVar()
    email = StringVar()
    phone = IntVar()
    address = StringVar()
    city = StringVar()
    
    Name_label=Label(profile,text='Name :',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
    Name_label.place(x=510,y=83)
    
    Name_entry=Entry(profile,fg='black',font=('arial',15,'bold'),bg='#ECECEC',bd=0,textvariable=name)
    Name_entry.place(x=600,y=90,width=310)
    
    Frame(profile,width=300,height=2,bg='orchid1',bd=1).place(x=600,y=115)
    
    Email_label=Label(profile,text='Email :',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
    Email_label.place(x=510,y=180)
    
    Email_entry=Entry(profile,width=34,fg='black',font=('arial',15,'bold'),bg='#ECECEC',bd=0,textvariable=email)
    Email_entry.place(x=600,y=187,width=310)
    
    Frame(profile,width=300,height=2,bg='orchid1',bd=1).place(x=600,y=211)
    phone_label=Label(profile,text='Phone No.:',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
    phone_label.place(x=510,y=277)
    
    phone_entry=Entry(profile,width=29,fg='black',font=('arial',15,'bold'),bg='#ECECEC',bd=0,textvariable=phone)
    phone_entry.place(x=649,y=284,width=251)
    
    Frame(profile,width=251,height=2,bg='orchid1',bd=1).place(x=649,y=310)
    
    Address_label=Label(profile,text='Address:',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
    Address_label.place(x=510,y=374)
    
    Address_entry=Entry(profile,width=29,fg='black',font=('arial',15,'bold'),bg='#ECECEC',bd=0,textvariable=address)
    Address_entry.place(x=625,y=381,width=274)
    
    Frame(profile,width=274,height=2,bg='orchid1',bd=1).place(x=625,y=405)
    
    city_label=Label(profile,text='city/town:',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
    city_label.place(x=510,y=471)
    
    city_entry=Entry(profile,width=29,fg='black',font=('arial',15,'bold'),bg='#ECECEC',bd=0,textvariable=city)
    city_entry.place(x=630,y=478,width=270)
    
    Frame(profile,width=270,height=2,bg='orchid1',bd=1).place(x=630,y=501)
    
    #button
    Button(profile,text="UPDATE",cursor='hand2',activebackground='#dfbbfb',activeforeground='white',bg="#dfbbfb",fg='white',font="20",command=update).place(x=650,y=530)
    
    fetch_data()
    profile.mainloop()
def cp():
    def loginclear():
        user_entry.delete(0,END)
        Currentpass_entry.delete(0,END)
        pass_entry.delete(0,END)
        confirmpass_entry.delete(0,END)

    def change_password():
        if user_entry.get()=='' or Currentpass_entry.get()=='' or pass_entry.get()=='' or confirmpass_entry.get()=='':
            messagebox.showerror('Error','All Fileds Are Required',parent=fpass)
        elif pass_entry.get()!=confirmpass_entry.get():
            messagebox.showerror('Error','Password and Confirm Password are not matching',parent=fpass)
        else:
           try: 
               con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
               cur=con.cursor()
               cur.execute('select * from admin where username=%s and pwd=%s',(username_info.get(),Currentpass_info.get()))
               row=cur.fetchone()
               if row==None:
                  messagebox.showerror('Error','Invalid Username And Password')
                  loginclear()
                  user_entry.focus()
               else:
                    cur.execute('update admin set pwd = %s where username = %s',(NewPass_info.get(),username))
                    messagebox.showinfo("Success","Password has been updated")
                    loginclear()
                    con.commit()
                    user_entry.focus()
                    con.close()
           except Exception as es:
                messagebox.showerror('Error',f'Error Due to : {str(es)}')
        
    fpass=Toplevel()
    fpass.title('Change password')
    bgImage=ImageTk.PhotoImage(file='image/background.jpg')
    bgLabel=Label(fpass,image=bgImage)
    bgLabel.grid()

    heading=Label(fpass,text='RESET PASSWORD',font=('arial',19,'bold'),bg='white',fg='magenta2')
    heading.place(x=475,y=60)

    username_info=StringVar()
    Currentpass_info=StringVar()
    NewPass_info=StringVar()
    ConfirmPass_info=StringVar()

    user_label=Label(fpass,text='Username',font=('Comic Sans MS',15,'bold'),bg='white',fg='orchid1')
    user_label.place(x=543,y=100)

    user_entry=Entry(fpass,width=25,fg='black',font=('arial',12,'bold'),bd=0,textvariable=username_info)
    user_entry.place(x=470,y=135)

    Frame(fpass,width=250,height=2,bg='orchid1').place(x=470,y=155)

    Currentpassdlabel=Label(fpass,text='Current Password',font=('Comic Sans MS',15,'bold'),bg='white',fg='orchid1')
    Currentpassdlabel.place(x=520,y=175)

    Currentpass_entry=Entry(fpass,width=25,fg='black',font=('arial',12,'bold'),bd=0,textvariable=Currentpass_info)
    Currentpass_entry.place(x=470,y=215)

    Frame(fpass,width=250,height=2,bg='orchid1').place(x=470,y=234)

    passwordlabel=Label(fpass,text='New Password',font=('Comic Sans MS',15,'bold'),bg='white',fg='orchid1')
    passwordlabel.place(x=530,y=245)

    pass_entry=Entry(fpass,width=25,fg='black',font=('arial',12,'bold'),bd=0,textvariable=NewPass_info)
    pass_entry.place(x=470,y=285)

    Frame(fpass,width=250,height=2,bg='orchid1').place(x=470,y=305)

    Confirmpasslabel=Label(fpass,text='Confirm Password',font=('Comic Sans MS',15,'bold'),bg='white',fg='orchid1')
    Confirmpasslabel.place(x=516,y=320)

    confirmpass_entry=Entry(fpass,width=25,fg='black',font=('arial',12,'bold'),bd=0,textvariable=ConfirmPass_info)
    confirmpass_entry.place(x=470,y=360)

    Frame(fpass,width=250,height=2,bg='orchid1').place(x=470,y=379)

    #Button-submit
    submitButton=Button(fpass,text='Submit',bd=0,bg='magenta2',fg='white',font=('Open Sans','16','bold'),
                    width=19,cursor='hand2',activebackground='magenta2',activeforeground='white',command=change_password)
    submitButton.place(x=477,y=410)
    fpass.mainloop()
def l():
    root.destroy()
    import NEWH    
def p():
        global f2
        f2= Frame(root,width=250,height=155,bg='#FFFFFF',highlightbackground='black',highlightthickness=1)
        f2.place(x=1286,y=65)    
        def bttn(x,y,text,bcolor,fcolor,cmd):
            def on_entera(e):
                myButton1['background'] = bcolor 
                myButton1['foreground']= '#262626'  

            def on_leavea(e):
                myButton1['background'] = fcolor
                myButton1['foreground']= '#262626'

            myButton1 = Button(f2,text=text,
                       fg='#262626',
                       border=0,
                       font=('Canva Sans',15),
                       bg=fcolor,
                       activeforeground='#262626',
                       activebackground=bcolor,
                       cursor='hand2',           
                        command=cmd)
                      
            myButton1.bind("<Enter>", on_entera)
            myButton1.bind("<Leave>", on_leavea)

            myButton1.place(x=x,y=y,width=248,height=50)

        bttn(0,0,'Edit Profile','#F6F8F9','#FFFFFF',ep)
        bttn(0,50,'Change Password','#F6F8F9','#FFFFFF',cp)
        bttn(0,100,'Logout','#F6F8F9','#FFFFFF',l)
        def delet():
            f2.destroy()
            s_button = Button(navbar,text=username,font=('Canva Sans',15),image=p_img,bg='white',compound=RIGHT,activebackground='#FFFFFF', cursor="hand2",borderwidth=0,command=p)
            s_button.place(x=1276,y=7,width=250,height=50)
        Button(navbar, text=username,font=('Canva Sans',15),image=p_img,bg='#F6F8F9', cursor="hand2",compound=RIGHT,borderwidth=0,activebackground='#FFFFFF',command=delet).place(x=1276,y=7,width=250,height=50)
           
    
def rc():
    def dt():
        to = drop1.get(1.0, "end-1c") 
        frm = clicked.get()
        sub = e1.get(1.0, "end-1c")
        det = e2.get(1.0, "end-1c")
        con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
        my_cursor = con.cursor()
        my_cursor.execute('Insert into draft values(%s,%s,%s,%s,%s)',(to,frm,sub,det,user))
        con.commit()
        con.close()
        messagebox.showinfo("Success","Complaint has been saved in draft.")

    def reg():
        user_1 = drop1.get(1.0, "end-1c")
        con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
        cur=con.cursor()
        cur.execute('select * from students where username=%s',(user_1,))
        row=cur.fetchone()
        if user == '10036810':
            if row == None:
                cur.execute('select * from admin where username=%s',(user_1,))
                row=cur.fetchone()
                if row == None:
                    s = 0
                else:
                    s = 1
            else:
                s = 1
        else:
            cur.execute('select * from admin where username=%s',(user_1,))
            row=cur.fetchone()
            if row == None:
                    s = 0
            else:
                    s = 1            
        con.commit()
        con.close()
        if clicked.get()=='' or drop1.get(1.0, "end-1c")=='' or e1.get(1.0, "end-1c")=='' or e2.get(1.0, "end-1c")=='':
            messagebox.showerror('Error','All Fileds Are Required')
        elif s == 1:
            try:
                con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
                my_cursor = con.cursor()
                my_cursor.execute('Insert into inbox(to_1,from_1,subject,details) values(%s,%s,%s,%s)',(drop1.get(1.0, "end-1c"),clicked.get(),e1.get(1.0, "end-1c"),e2.get(1.0, "end-1c")))
                con.commit()
                con.close()  
                root1.destroy()
                messagebox.showinfo("Success","Message has been sent")
            except Exception as es:
                con.rollback()
                messagebox.showerror('Error',f'Error Due to : {str(es)}')
        else:
            messagebox.showerror('Error','Invalid Username of the receiver. Please enter correct Username.')
    
    root1 = Toplevel(root)
    root1.title('Register')
    root1.geometry('500x500')
    root1.config(bg='#F6F8F9')

    #------------Label-----------------
    username = Label(root1,text='From',font=('Canva Sans',15),fg='black',bg='#F6F8F9')
    username.place(x=10,y=10)
    toname = Label(root1,text='To',font=('Canva Sans',15),fg='black',bg='#F6F8F9')
    toname.place(x=10,y=50)
    subject = Label(root1,text='Subject',font=('Canva Sans',15),fg='black',bg='#F6F8F9')
    subject.place(x=10,y=90)
    info = Label(root1,text='Details',font=('Canva Sans',15),fg='black',bg='#F6F8F9')
    info.place(x=10,y=150)

    #TextVariable for Every Entry Field
    clicked = StringVar()

    # Entry field for all Labels
    if user=='10036810':
            frm = 'HOD'
    else:
            frm = 'Staff'
    drop = OptionMenu(root1,clicked,frm)
    drop.place(x=90,y=10,width=200,height=30)
    drop1 = Text(root1,bd=2,relief=GROOVE,font=('Canva Sans',13))
    drop1.place(x=90,y=50,width=200,height=25)
    e1 = Text(root1,bd=2,relief=GROOVE,font=('Canva Sans',13))
    e1.place(x=90,y=90,width=400,height=50)
    e2 = Text(root1,bd=2,relief=GROOVE,font=('Canva Sans',13))
    e2.place(x=10,y=180,width=480,height=250)

    #------------Button----------
    b1= Button(root1,text="Send",bd=1,bg="#55185D",fg='white',font="20",cursor='hand2',command=reg)
    b1.place(x=370,y=440,width=100,height=25)
    b2= Button(root1,text="Draft",bd=1,bg="#55185D",fg='white',font="20",cursor='hand2',command=dt)
    b2.place(x=250,y=440,width=100,height=25)
    root1.mainloop()
    
def i():
    root.destroy()
    import a_inbox

def s():
    root.destroy()
    import a_sent

def d():
    root.destroy()
    import a_draft

def t():
    root.destroy()
    import c_sub

#------------Images-----------
menu_img = ImageTk.PhotoImage(Image.open("image/m5.png"))
register_img = ImageTk.PhotoImage(Image.open("image/m1.png"))
close_img = ImageTk.PhotoImage(Image.open("image/c3.png"))
p_img = ImageTk.PhotoImage(Image.open("image/p1.png"))

#-----------Frames-------------
navbar = Frame(root, bg='white',highlightbackground='black',highlightthickness=1).place(x=0,y=0,width=1536,height=65)
#sidebar = Frame(root,bg='#F6F8F9').place(x=0,y=200,width=300,height=725)
r_bar = Frame(root,bg='white').place(x=1260,y=80,width=250,height=700)
search = Frame(root,bg='green').place(x=300,y=80,width=936,height=60)
inbox = Frame(root,bg='white')
inbox.place(x=300,y=120,width=936,height=338)
txt_frame = Frame(root,bg='white',highlightbackground='black',highlightthickness=1)
txt_frame.place(x=300,y=470,width=936,height=300)
#-------------Label-------------
box = Label(search,text='Draft',font=('Canva Sans',20),bg='green',fg='white').place(x=310,y=80)
from_label = Label(txt_frame,text="To:",font=('Canva Sans',13),bg='white',fg='black').place(x=7,y=7)
from_view = StringVar()
from_entry = Entry(txt_frame,font=('Canva Sans',13),fg='black',bg='white',bd=0,textvariable=from_view)
from_entry.place(x=60,y=9,width=600,height=20)

sub_label = Label(txt_frame,text="Subject:",font=('Canva Sans',13),bg='white',fg='black').place(x=7,y=33)
sub_entry = Text(txt_frame,font=('Canva Sans',13),fg='black',bg='white',bd=0)
sub_entry.place(x=75,y=35,width=850,height=70)

det_label = Label(txt_frame,text="Detail:",font=('Canva Sans',13),bg='white',fg='black').place(x=7,y=110)
det_entry = Text(txt_frame,font=('Canva Sans',13),fg='black',bg='white',bd=0)
det_entry.place(x=10,y=133,width=910,height=155)

b1= Button(txt_frame,text="Send",bd=1,bg="#55185D",fg='white',font="20",cursor='hand2',command=reg)
b1.place(x=800,y=260,width=100,height=25)
b2= Button(txt_frame,text="Draft",bd=1,bg="#55185D",fg='white',font="20",cursor='hand2',command=dt)
b2.place(x=690,y=260,width=100,height=25)
#-----------Buttons------------
menu_button = Button(navbar,image = menu_img,bg='white', cursor="hand2",borderwidth=0,command=m).place(x=10,y=10,width=50,height=50)
register_complaint = Button(root,image=register_img,borderwidth=0,cursor="hand2",command=rc).place(x=50,y=90,width=200,height=41)
inbox_button = Button(root,text="Inbox",bg='blue',fg='white',cursor="hand2",borderwidth=0,activebackground='blue',activeforeground='white',font=('Canva Sans',15),command=i).place(x=25,y=200,width=250,height=40)
sent_button = Button(root,text="Sent",bg='white',fg='black',cursor="hand2",borderwidth=0,activebackground='white',activeforeground='black',font=('Canva Sans',15),command=s).place(x=25,y=241,width=250,height=40)
draft_button = Button(root,text="Draft",bg='white',fg='black',cursor="hand2",borderwidth=0,activebackground='white',activeforeground='black',font=('Canva Sans',15),command=d).place(x=25,y=282,width=250,height=40)
trash_button = Button(root,text="Counselling Form",bg='white',fg='black',cursor="hand2",borderwidth=0,activebackground='white',activeforeground='black',font=('Canva Sans',15),command=t).place(x=25,y=323,width=250,height=40)
#ct_button = Button(root,text="Complaint Tracker",bg='white',fg='black',cursor="hand2",borderwidth=0,activebackground='white',activeforeground='black',font=('Canva Sans',15)).place(x=25,y=500,width=250,height=40)
s_button = Button(navbar,text=username,font=('Canva Sans',15),image=p_img,bg='white',compound=RIGHT, cursor="hand2",borderwidth=0,command=p).place(x=1276,y=7,width=250,height=50)
#------------Complaint Register Number / Complaint Id--------------
table = ttk.Treeview(r_bar,columns=('c_id'))
table.place(x=1260,y=80,width=250,height=700)
table.heading('c_id',text='Complaint ID')
table['show']='headings'
s = ttk.Style(r_bar)
s.theme_use("clam")
s.configure(".", font=('Helvetica', 11))
s.configure("Treeview.Heading", foreground='red',font=('Helvetica',15,"bold"))

#---------Scrollbar---------
scroll = Scrollbar(inbox)
scroll.pack(side=RIGHT,fill=Y)

#--------Inbox------------
inbox_table = ttk.Treeview(inbox,yscrollcommand=scroll.set)
scroll.config(command=inbox_table.yview)
inbox_table['columns']=('from1','sub1')
inbox_table.column('from1',width=318)
inbox_table.column('sub1',width=618)
inbox_table['show']=''
inbox_table.pack(fill=BOTH,expand=1)
inbox_table.bind('<ButtonRelease-1>',view)

fetch_all()
fetch()



root.mainloop()