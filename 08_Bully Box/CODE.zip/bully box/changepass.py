from tkinter import*
import tkinter as tk
from tkinter import ttk
from PIL import ImageTk
from tkinter import messagebox
import mysql.connector
root=tk.Tk()
root.geometry("600x598")
root.title('Bully Box')
#bgImage=ImageTk.PhotoImage(file='img.jpg')
#bgLabel=Label(root,image=bgImage)
#bgLabel.place(x=0,y=0)


def send():
   if username_entry.get()=='' or CurrentPass_entry.get()=='' or NewPass_entry.get()=='' or ConfirmPass_entry.get()=='':
            messagebox.showerror('Error','All Fileds Are Required')
   elif NewPass_entry.get()!=ConfirmPass_entry.get():
            messagebox.showerror('Error','Password and Confirm Password are not matching')
   else:
           try: 
               con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
               my_cursor=con.cursor()
               my_cursor.execute('select * from students where username=%s and pwd=%s',(username_info.get(),Currentpass_info.get()))
               row=my_cursor.fetchone()
               if row==None:
                  messagebox.showerror('Error','Invalid Username And Password')
                  
               else:
                my_cursor.execute('update students set pwd = %s where username = %s',(ConfirmPass_entry.get(),21104067))
                messagebox.showinfo("Success","Password has been updated")
                con.close()
           except Exception as es:
                messagebox.showerror('Error',f'Error Due to : {str(es)}')
    
   


#label
Label(root,text="Change Password",font="ariel 22 bold",bg="#55185D",fg='white').pack(fill="both")
Label(root,text="UserName",font=("Comic Sans MS",20)).place(x=40,y=80)
Label(root,text="Current Password",font=("Comic Sans MS",20)).place(x=40,y=160)
Label(root,text="New Password",font=("Comic Sans MS",20)).place(x=40,y=240)
Label(root,text="Confirm Password",font=("Comic Sans MS",20)).place(x=40,y=320)





#Entry
username_info=StringVar()
Currentpass_info=StringVar()
NewPass_info=StringVar()
ConfirmPass_info=StringVar()



username_entry=Entry(root,font="10",bd=2,textvariable=username_info)
username_entry.place(x=300,y=88)

CurrentPass_entry=Entry(root,font="10",bd=2,textvariable=Currentpass_info)
CurrentPass_entry.place(x=300,y=172)

NewPass_entry=Entry(root,font="10",bd=2,textvariable=NewPass_info)
NewPass_entry.place(x=300,y=254)

ConfirmPass_entry=Entry(root,font="10",bd=2,textvariable=ConfirmPass_info)
ConfirmPass_entry.place(x=300,y=332)



#Button
Button(root,text="UPDATE",bd=1,bg="#55185D",activebackground='#55185D',fg='white',font="20",command=send).place(x=445,y=400)


root.mainloop()
