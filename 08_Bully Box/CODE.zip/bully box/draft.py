from tkinter import *
from PIL import Image,ImageTk
from tkinter import ttk
from login_data import login_d
from tkinter import messagebox
import mysql.connector
import random

root=Tk()
root.title("Bully Box")
root.state('zoomed')
root.config(bg='#F6F8F9')
root.resizable()

username = login_d()
user = username
def fetch():
    con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
    my_cursor = con.cursor()
    my_cursor.execute('select to_1,subject from draft where username = %s',(user,))
    rows = my_cursor.fetchall()
    if len(rows)!=0:
        inbox_table.delete(* inbox_table.get_children())
        for items in rows:
            inbox_table.insert('',END,values=items)
        con.commit()
    con.close()
def fetch_all():
    con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
    my_cursor = con.cursor()
    my_cursor.execute('select c_id from inbox where from_1 = %s',(user,))
    rows = my_cursor.fetchall()
    if len(rows)!=0:
        table.delete(* table.get_children())
        for items in rows:
            table.insert('',END,values=items)
        con.commit()
    con.close()
    
def view(event=''):
    global from_1
    global sub
    def clear():
        from_entry.delete(0,END)
        sub_entry.delete(1.0, "end-1c")
        det_entry.delete(1.0, "end-1c")
    cursor_row = inbox_table.focus()
    data = inbox_table.item(cursor_row)
    row = data['values']
    from_1 = row[0]
    sub = row[1]
    con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
    my_cursor = con.cursor()
    my_cursor.execute('Select * from draft where to_1 = %s AND subject= %s',(from_1,sub))
    rows = my_cursor.fetchall()
    for row in rows:
        clear()
        from_view.set(from_1)
        sub_entry.insert(END,row[2])
        det_entry.insert(END,row[3])
    fetch_all()
    fetch()
    con.commit()
    con.close()

def dt():    
    def clear():
        from_entry.delete(0,END)
        sub_entry.delete(1.0, "end-1c")
        det_entry.delete(1.0, "end-1c")
    con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
    my_cursor = con.cursor()
    my_cursor.execute('Select * from draft where to_1 = %s AND subject= %s',(from_1,sub))
    rows = my_cursor.fetchall()
    for row in rows:
        to = row[0]
        subject = row[2]
        detail = row[3]
    con.commit()
    con.close()
    if to == from_view.get() and subject == sub_entry.get(1.0, "end-1c") and detail == det_entry.get(1.0, "end-1c"):
        clear()
        fetch()
        fetch_all()
    else:
        con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
        my_cursor = con.cursor()
        my_cursor.execute('Delete from draft where to_1 = %s AND subject= %s AND details= %s AND username = %s',(to,subject,detail,user,))        
        my_cursor.execute('Insert into draft values(%s,%s,%s,%s,%s)',(from_view.get(),user,sub_entry.get(1.0, "end-1c"),det_entry.get(1.0, "end-1c"),user,))
        b1.grid_forget()
        b2.grid_forget()
        clear()
        fetch_all()
        fetch()
        con.commit()
        con.close()
        messagebox.showinfo("Success","Complaint has been saved in draft.")

def reg():
    def clear():
            from_entry.delete(0,END)
            sub_entry.delete(1.0, "end-1c")
            det_entry.delete(1.0, "end-1c")    
    con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
    my_cursor = con.cursor()
    my_cursor.execute('Select * from draft where to_1 = %s AND subject= %s',(from_1,sub))
    rows = my_cursor.fetchall()
    for row in rows:
        to = row[0]
        subject = row[2]
        detail = row[3]
    con.commit()
    con.close()                
    characters = "123456789"
    password = ""
    j = 0
    try:
        con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
        my_cursor = con.cursor()
        while(j==0):
            for i in range(8):
                        password += random.choice(characters)
                        c_id=int(password)
            my_cursor.execute('select * from inbox where c_id = %s',(c_id,))
            row=my_cursor.fetchone()
            if row == 1:
                        j = 0
            else:
                        j = 1
        con.commit()
        con.close()              
        con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
        my_cursor = con.cursor()
        my_cursor.execute('Insert into inbox values(%s,%s,%s,%s,%s)',(from_view.get(),user,sub_entry.get(1.0, "end-1c"),det_entry.get(1.0, "end-1c"),c_id))
        to = 'HOD'
        sub2='Complaint ID'  
        detail = 'Thank you for putting your faith in us and informing us of your difficulties. We assure you that we will do all in our power to assist you in the best way possible.The complaint ID for your complaint is:'+password
        my_cursor.execute('Insert into inbox(to_1,from_1,subject,details) values(%s,%s,%s,%s)',(user,to,sub2,detail))
        status = 'Received'
        my_cursor.execute('Insert into cstatus(c_id,status) values(%s,%s)',(c_id,status,))
        my_cursor.execute('Delete from draft where to_1 = %s AND subject= %s AND details= %s AND username = %s',(to,subject,detail,user,))
        clear()
        fetch()
        fetch_all()
        messagebox.showinfo("Success","Complaint has been recorded.")
    except Exception as es:
            con.rollback()
            messagebox.showerror('Error',f'Error Due to : {str(es)}') 
def dd():
    root.destroy()
    import dashboard
def cr():
    f1.destroy()
def ct():
    def disp():
        def submit():
            f1.destroy()
            b1.destroy()
        def gets(event=''):
            global cid
            cid = sel.get()
            con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
            my_cursor = con.cursor()    
            my_cursor.execute('Select * from cstatus where c_id = %s',(cid,))
            info = my_cursor.fetchall()
            for row in info:
                c = row[2]
                if row[1] == 'Received':
                    s = 'Received'
                elif row[1] == 'Assigned':
                    s = 'Assigned'
                elif row[1] == 'Under Investigation':
                    s = 'Under Investigation'
                elif row[1] == 'Resolved':
                    s = 'Resolved' 
                elif row[1] == 'Rejected':
                    s = 'Rejected'
            t2.insert(END,s)
            t1.insert(END,c)
        l1.config(text='')      
        f1 = Frame(root1,bg='white',height=450,width=500)
        f1.place(x=0,y=120)
        Label(f1,text='Status:',font=('Times New Roman',15,'bold'),bg='white',fg='black').place(x=80,y=20)
        Label(f1,text='Comment:',font=('Times New Roman',15,'bold'),bg='white',fg='black').place(x=50,y=90)
        t1 = Text(f1,font=('Canva Sans',12),fg='black',bg='white',bd=0,relief=GROOVE)
        t1.place(x=150,y=95,height=200,width=300)
        t2 = Text(f1,font=('Canva Sans',12),fg='black',bg='white',bd=0,relief=GROOVE)
        t2.place(x=150,y=25,height=25,width=200)
        e = Entry(f1)
        e.place(x=50,y=520,height=10,width=10)
        e.focus()
        id.bind("<FocusOut>",gets)
        b1 =Button(root1,text='OKAY',font=('Times New Roman',13),bg='#E6E6FA',fg='black',relief='groove',activeforeground='black',activebackground='#E6E6FA',cursor='hand2',command=submit)
        b1.place(x=225,y=400)    

    def upd(*args):
        my_list = []
        values =(user,"%" + id.get() + "%",)
        con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
        my_cursor = con.cursor()
        my_cursor.execute('select c_id from inbox where from_1 = %s and c_id like %s',values)
        data = my_cursor.fetchall()
        for row in data:
            my_list.append(row[0])
        con.commit()
        con.close()
        id['values']=[]
        id['values']= my_list
        l1.config(text='Result:'+str(len(data)))

    root1=Toplevel(root)
    root1.title("Bully Box")
    root1.geometry('500x500+0+0')
    root1.config(bg='white')
    root1.resizable()

    frame = Frame(root1,bg='#C2E5D3',height=45,width=500)
    frame.place(x=0,y=0)
    Label(frame,text='Complaint Tracker',font=('Times New Roman',20,'bold'),bg='#C2E5D3',fg='black').place(x=140,y=4)

    my_list=[]
    con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
    my_cursor = con.cursor()
    my_cursor.execute('select c_id from inbox where from_1 = %s ',(user,))
    data = my_cursor.fetchall()
    for row in data:
        my_list.append(row[0])
    con.commit()
    con.close()

    id_label = Label(root1,text='Complaint Id',font=('Times New Roman',15,'bold'),bg='white',fg='black')
    id_label.place(x=50,y=70)
    sel = StringVar()
    id = ttk.Combobox(root1,values=my_list,width=25,height=30,textvariable=sel)
    id.place(x=180,y=72)
    sel.trace("w", upd)
    l1 = Label(root1,text='',font=('Times New Roman',13,'bold'),bg='white',fg='black')
    l1.place(x=390,y=70)

    b1 =Button(root1,text='Submit',font=('Times New Roman',13),bg='#E6E6FA',fg='black',relief='groove',activeforeground='black',activebackground='#E6E6FA',cursor='hand2',command=disp)
    b1.place(x=225,y=120)
    root1.mainloop()
def ca():
    import c_form
def m():
        global f1
        f1= Frame(root,width=250,height=205,bg='#FFFFFF',highlightbackground='black',highlightthickness=1)
        f1.place(x=0,y=65)    
        def bttn(x,y,text,bcolor,fcolor,cmd):
            def on_entera(e):
                myButton1['background'] = bcolor 
                myButton1['foreground']= '#262626'  

            def on_leavea(e):
                myButton1['background'] = fcolor
                myButton1['foreground']= '#262626'

            myButton1 = Button(f1,text=text,
                       fg='#262626',
                       border=0,
                       font=('Canva Sans',15),
                       bg=fcolor,
                       activeforeground='#262626',
                       activebackground=bcolor,
                       cursor='hand2',           
                        command=cmd)
                      
            myButton1.bind("<Enter>", on_entera)
            myButton1.bind("<Leave>", on_leavea)

            myButton1.place(x=x,y=y,width=248,height=50)

        bttn(0,0,'Dashboard','#F6F8F9','#FFFFFF',dd)
        bttn(0,50,'Complaint Register','#F6F8F9','#FFFFFF',cr)
        bttn(0,100,'Complaint Tracker','#F6F8F9','#FFFFFF',ct)
        bttn(0,150,'Counseling Appointment','#F6F8F9','#FFFFFF',ca)
        
        def delete():
            f1.destroy()
            menu_img= Button(navbar, image = menu_img,bg='white', cursor="hand2",borderwidth=0,command=m)
            menu_img.place(x=10,y=10,width=50,height=50)
        Button(navbar, image = menu_img,bg='#F6F8F9', cursor="hand2",borderwidth=0,activebackground='#FFFFFF',command=delete).place(x=10,y=10,width=50,height=50)
def ep():
    root.destroy()
    import profile_1
def cp():
    root.destroy()
    import changepass
def l():
    root.destroy()
    import NEWH 
def p():
        f2= Frame(root,width=250,height=155,bg='#FFFFFF',highlightbackground='black',highlightthickness=1)
        f2.place(x=1286,y=65)    
        def bttn(x,y,text,bcolor,fcolor,cmd):
            def on_entera(e):
                myButton1['background'] = bcolor 
                myButton1['foreground']= '#262626'  

            def on_leavea(e):
                myButton1['background'] = fcolor
                myButton1['foreground']= '#262626'

            myButton1 = Button(f2,text=text,
                       fg='#262626',
                       border=0,
                       font=('Canva Sans',15),
                       bg=fcolor,
                       activeforeground='#262626',
                       activebackground=bcolor,
                       cursor='hand2',           
                        command=cmd)
                      
            myButton1.bind("<Enter>", on_entera)
            myButton1.bind("<Leave>", on_leavea)

            myButton1.place(x=x,y=y,width=248,height=50)

        bttn(0,0,'Edit Profile','#F6F8F9','#FFFFFF',ep)
        bttn(0,50,'Change Password','#F6F8F9','#FFFFFF',cp)
        bttn(0,100,'Logout','#F6F8F9','#FFFFFF',l)
        def delet():
            f2.destroy()
            s_button = Button(navbar,text=user,font=('Canva Sans',15),image=p_img,bg='white',compound=RIGHT, cursor="hand2",borderwidth=0,command=p)
            s_button.place(x=1276,y=7,width=250,height=50)
        Button(navbar,text=user,font=('Canva Sans',15),image=p_img,bg='#F6F8F9',compound=RIGHT,cursor="hand2",borderwidth=0,activebackground='#FFFFFF',command=delet).place(x=1276,y=7,width=250,height=50)
            
def rc():
    def dt():
        con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
        my_cursor = con.cursor()
        my_cursor.execute('Insert into draft values(%s,%s,%s,%s,%s)',(clicked1.get(),clicked.get(),e1.get(1.0, "end-1c"),e2.get(1.0, "end-1c"),user))
        con.commit()
        con.close()
    def reg():
        sub1 = e1.get(1.0, "end-1c")
        characters = "123456789"
        password = ""
        j = 0
        user_1 = clicked.get()
        if drop=='' or drop1=='' or e1=='' or e2=='':
            messagebox.showerror('Error','All Fileds Are Required')
        elif user == user_1:
            try:
                con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
                my_cursor = con.cursor()
                while(j==0):
                    for i in range(8):
                        password += random.choice(characters)
                        c_id=int(password)
                    my_cursor.execute('select * from inbox where c_id = %s',(c_id,))
                    row=my_cursor.fetchone()
                    if row == 1:
                        j = 0
                    else:
                        j = 1
                con.commit()
                con.close()
                con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
                my_cursor = con.cursor()
                my_cursor.execute('Insert into inbox values(%s,%s,%s,%s,%s)',(clicked1.get(),clicked.get(),e1.get(1.0, "end-1c"),e2.get(1.0, "end-1c"),c_id))
                to = 'HOD'
                sub2='Complaint ID'  
                detail = 'Thank you for putting your faith in us and informing us of your difficulties. We assure you that we will do all in our power to assist you in the best way possible.The complaint ID for your complaint is:'+password
                my_cursor.execute('Insert into inbox(to_1,from_1,subject,details) values(%s,%s,%s,%s)',(clicked.get(),to,sub2,detail))
                status = 'Received'
                my_cursor.execute('Insert into cstatus(c_id,status) values(%s,%s)',(c_id,status,))
                con.commit()
                con.close()  
                root1.destroy()
                fetch_all()
                fetch()
                messagebox.showinfo("Success","Record has been submitted")
            except Exception as es:
                con.rollback()
                messagebox.showerror('Error',f'Error Due to : {str(es)}') 
        else:
            messagebox.showerror('Error','Invalid Username. Please enter your Username.')        

    root1 = Toplevel(root)
    root1.title('Register')
    root1.geometry('500x480')
    root1.config(bg='white')
    
    #------------Label----------------
    username = Label(root1,text='From',font=('Canva Sans',15),fg='black',bg='white')
    username.place(x=10,y=10)
    toname = Label(root1,text='To',font=('Canva Sans',15),fg='black',bg='white')
    toname.place(x=10,y=50)
    subject = Label(root1,text='Subject',font=('Canva Sans',15),fg='black',bg='white')
    subject.place(x=10,y=90)
    info = Label(root1,text='Details',font=('Canva Sans',15),fg='black',bg='white')
    info.place(x=10,y=150)

    #TextVariable for Every Entry Field
    clicked = StringVar()
    clicked1 = StringVar()
    # Entry field for all Labels
    drop = Entry(root1,textvariable=clicked,bd=2,relief=GROOVE,font=('Canva Sans',13))
    drop.place(x=90,y=10,width=200,height=25)
    drop1 = OptionMenu(root1,clicked1,"HOD")
    drop1.place(x=90,y=50,width=200,height=30)
    e1 = Text(root1,bd=2,font=('Canva Sans',13),relief=GROOVE)
    e1.place(x=90,y=90,width=400,height=50)
    e2 = Text(root1,bd=2,font=('Canva Sans',13),relief=GROOVE)
    e2.place(x=10,y=180,width=480,height=250)

    #------------Button----------
    b1= Button(root1,text="Send",bd=1,bg="#55185D",fg='white',font="20",cursor='hand2',command=reg)
    b1.place(x=370,y=440,width=100,height=25)
    b2= Button(root1,text="Draft",bd=1,bg="#55185D",fg='white',font="20",cursor='hand2',command=dt)
    b2.place(x=250,y=440,width=100,height=25)
    root1.mainloop()
    
def i():
    root.destroy()
    import inbox

def s():
    root.destroy()
    import sent

def d():
    root.destroy()
    import draft

# def t():
#     root.destroy()
#     import trash

#------------Images-----------
menu_img = ImageTk.PhotoImage(Image.open("image/m5.png"))
register_img = ImageTk.PhotoImage(Image.open("image/r3.png"))
close_img = ImageTk.PhotoImage(Image.open("image/c3.png"))
p_img = ImageTk.PhotoImage(Image.open("image/p1.png"))

#-----------Frames-------------
navbar = Frame(root, bg='white',highlightbackground='black',highlightthickness=1).place(x=0,y=0,width=1536,height=65)
#sidebar = Frame(root,bg='#F6F8F9').place(x=0,y=200,width=300,height=725)
r_bar = Frame(root,bg='white').place(x=1260,y=80,width=250,height=700)
search = Frame(root,bg='green').place(x=300,y=80,width=936,height=60)
inbox = Frame(root,bg='white')
inbox.place(x=300,y=120,width=936,height=338)
txt_frame = Frame(root,bg='white',highlightbackground='black',highlightthickness=1)
txt_frame.place(x=300,y=470,width=936,height=300)
#-------------Label-------------
box = Label(search,text='Draft',font=('Canva Sans',20),bg='green',fg='white').place(x=310,y=80)
from_label = Label(txt_frame,text="To:",font=('Canva Sans',13),bg='white',fg='black').place(x=7,y=7)
from_view = StringVar()
from_entry = Entry(txt_frame,font=('Canva Sans',13),fg='black',bg='white',bd=0,textvariable=from_view)
from_entry.place(x=60,y=9,width=600,height=20)

sub_label = Label(txt_frame,text="Subject:",font=('Canva Sans',13),bg='white',fg='black').place(x=7,y=33)
sub_entry = Text(txt_frame,font=('Canva Sans',13),fg='black',bg='white',bd=0)
sub_entry.place(x=75,y=35,width=850,height=70)

det_label = Label(txt_frame,text="Detail:",font=('Canva Sans',13),bg='white',fg='black').place(x=7,y=110)
det_entry = Text(txt_frame,font=('Canva Sans',13),fg='black',bg='white',bd=0)
det_entry.place(x=10,y=133,width=910,height=130)

b1= Button(txt_frame,text="Send",bd=1,bg="#55185D",fg='white',font="20",cursor='hand2',command=reg)
b1.place(x=800,y=260,width=100,height=25)
b2= Button(txt_frame,text="Draft",bd=1,bg="#55185D",fg='white',font="20",cursor='hand2',command=dt)
b2.place(x=690,y=260,width=100,height=25)

#-----------Buttons------------
menu_button = Button(navbar,image = menu_img,bg='white', cursor="hand2",borderwidth=0,command=m).place(x=10,y=10,width=50,height=50)
register_complaint = Button(root,image=register_img,borderwidth=0,cursor="hand2",command=rc).place(x=50,y=90,width=200,height=41)
inbox_button = Button(root,text="Inbox",bg='blue',fg='white',cursor="hand2",borderwidth=0,activebackground='blue',activeforeground='white',font=('Canva Sans',15),command=i).place(x=25,y=200,width=250,height=40)
sent_button = Button(root,text="Complaints",bg='white',fg='black',cursor="hand2",borderwidth=0,activebackground='white',activeforeground='black',font=('Canva Sans',15),command=s).place(x=25,y=241,width=250,height=40)
draft_button = Button(root,text="Draft",bg='white',fg='black',cursor="hand2",borderwidth=0,activebackground='white',activeforeground='black',font=('Canva Sans',15),command=d).place(x=25,y=282,width=250,height=40)
# trash_button = Button(root,text="Trash",bg='white',fg='black',cursor="hand2",borderwidth=0,activebackground='white',activeforeground='black',font=('Canva Sans',15),command=t).place(x=25,y=323,width=250,height=40)
#ct_button = Button(root,text="Complaint Tracker",bg='white',fg='black',cursor="hand2",borderwidth=0,activebackground='white',activeforeground='black',font=('Canva Sans',15)).place(x=25,y=500,width=250,height=40)
s_button = Button(navbar,text=user,font=('Canva Sans',15),image=p_img,bg='white',compound=RIGHT, cursor="hand2",borderwidth=0,command=p).place(x=1276,y=7,width=250,height=50)
#------------Complaint Register Number / Complaint Id--------------
table = ttk.Treeview(r_bar,columns=('c_id'))
table.place(x=1260,y=80,width=250,height=700)
table.heading('c_id',text='Complaint ID')
table['show']='headings'
s = ttk.Style(r_bar)
s.theme_use("clam")
s.configure(".", font=('Helvetica', 11))
s.configure("Treeview.Heading", foreground='red',font=('Helvetica',15,"bold"))

#---------Scrollbar---------
scroll = Scrollbar(inbox)
scroll.pack(side=RIGHT,fill=Y)

#--------Inbox------------
inbox_table = ttk.Treeview(inbox,yscrollcommand=scroll.set)
scroll.config(command=inbox_table.yview)
inbox_table['columns']=('from1','sub1')
inbox_table.column('from1',width=318)
inbox_table.column('sub1',width=618)
inbox_table['show']=''
inbox_table.pack(fill=BOTH,expand=1)
inbox_table.bind('<ButtonRelease-1>',view)

fetch_all()
fetch()

root.mainloop()