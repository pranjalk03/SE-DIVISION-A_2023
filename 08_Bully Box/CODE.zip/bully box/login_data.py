from login1 import login

user = login()

def login_d():
    return user