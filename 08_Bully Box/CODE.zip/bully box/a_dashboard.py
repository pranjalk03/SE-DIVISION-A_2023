from tkinter import *
from tkinter import PhotoImage
import tkinter as tk
from PIL import ImageTk,Image
import mysql.connector
from tkinter import messagebox
from login_a import login_d
from tkinter import ttk

#color
co0="#ffffff"
co1="#000000"
co2="#ca4fff"
co3="#ECB602"
co4="#FEDA14"
co5="#fe6694"

#setting root window
root = tk.Tk()
root.title("Bully Box")
root.config(bg=co0)
root.geometry("1183x700+10+0")


# setting switch state:
btnState = False

# loading navbar icon image:
navIcon = PhotoImage(file="image/sidebar.png")
profileIcon = PhotoImage(file="image/profile2 (2).png")
closeIcon = PhotoImage(file="image/close6.png")
dashboardIcon = PhotoImage(file="image/dashboard (2).png")
complainInboxIcon= PhotoImage(file="image/complaintInbox (2).png")
trackingIcon = PhotoImage(file="image/tracking (2).png")
counsellorIcon = PhotoImage(file="image/r5.png")
graphIcon= PhotoImage(file="image/Figure_1 (6).png")
graphIcon1=PhotoImage(file="image/Figure_3.png")
udIcon=PhotoImage(file="image/d2.png")

username = login_d()

def ep():
    def fetch_data():
        try:
            con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
            my_cursor = con.cursor()
            value = (username,)
            my_cursor.execute(('select * from admin where username = %s'),value)
            rows = my_cursor.fetchall()
            for row in rows:
                name.set(row[1])
                email.set(row[3])
                phone.set(row[4])
                address.set(row[5])
                city.set(row[6])
            con.commit()
            con.close()
        except Exception as es:
                messagebox.showerror('Error',f'Error Due to : {str(es)}') 

    def update():
        if Name_entry.get()=='' or Email_entry.get()=='' or phone_entry.get()=='' or Address_entry.get()=='' or city_entry.get()=='':
            messagebox.showerror('Error','All Fileds Are Required',parent=profile)
        else:
         con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
         my_cursor = con.cursor()
         my_cursor.execute('Update admin set name = %s,email_id = %s, phone_no = %s,address = %s, city = %s where username = %s',(name.get(),email.get(),phone.get(),address.get(),city.get(),username))
         con.commit()
         fetch_data()
         con.close()
         messagebox.showinfo("Success","Record has been updated")
    profile=Toplevel()
    profile.geometry("990x660+50+50")
    profile.title('Profile')
    bgImage=ImageTk.PhotoImage(Image.open('image/Frame 8.jpg'))
    bgLabel=Label(profile,image=bgImage)
    bgLabel.place(x=0,y=0)
     
    frame = Frame(profile,bg='#ECECEC',height=555,width=405)
    frame.place(x=505,y=53)
    
    #-----------Variables-------
    name = StringVar()
    email = StringVar()
    phone = IntVar()
    address = StringVar()
    city = StringVar()
    
    Name_label=Label(profile,text='Name :',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
    Name_label.place(x=510,y=83)
    
    Name_entry=Entry(profile,fg='black',font=('arial',15,'bold'),bg='#ECECEC',bd=0,textvariable=name)
    Name_entry.place(x=600,y=90,width=310)
    
    Frame(profile,width=300,height=2,bg='orchid1',bd=1).place(x=600,y=115)
    
    Email_label=Label(profile,text='Email :',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
    Email_label.place(x=510,y=180)
    
    Email_entry=Entry(profile,width=34,fg='black',font=('arial',15,'bold'),bg='#ECECEC',bd=0,textvariable=email)
    Email_entry.place(x=600,y=187,width=310)
    
    Frame(profile,width=300,height=2,bg='orchid1',bd=1).place(x=600,y=211)
    phone_label=Label(profile,text='Phone No.:',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
    phone_label.place(x=510,y=277)
    
    phone_entry=Entry(profile,width=29,fg='black',font=('arial',15,'bold'),bg='#ECECEC',bd=0,textvariable=phone)
    phone_entry.place(x=649,y=284,width=251)
    
    Frame(profile,width=251,height=2,bg='orchid1',bd=1).place(x=649,y=310)
    
    Address_label=Label(profile,text='Address:',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
    Address_label.place(x=510,y=374)
    
    Address_entry=Entry(profile,width=29,fg='black',font=('arial',15,'bold'),bg='#ECECEC',bd=0,textvariable=address)
    Address_entry.place(x=625,y=381,width=274)
    
    Frame(profile,width=274,height=2,bg='orchid1',bd=1).place(x=625,y=405)
    
    city_label=Label(profile,text='city/town:',font=('arial',19,'bold'),bg='#ECECEC',fg='black')
    city_label.place(x=510,y=471)
    
    city_entry=Entry(profile,width=29,fg='black',font=('arial',15,'bold'),bg='#ECECEC',bd=0,textvariable=city)
    city_entry.place(x=630,y=478,width=270)
    
    Frame(profile,width=270,height=2,bg='orchid1',bd=1).place(x=630,y=501)
    
    #button
    Button(profile,text="UPDATE",cursor='hand2',activebackground='#dfbbfb',activeforeground='white',bg="#dfbbfb",fg='white',font="20",command=update).place(x=650,y=530)
    
    fetch_data()
    profile.mainloop()

def cp():
    def loginclear():
        user_entry.delete(0,END)
        Currentpass_entry.delete(0,END)
        pass_entry.delete(0,END)
        confirmpass_entry.delete(0,END)

    def change_password():
        if user_entry.get()=='' or Currentpass_entry.get()=='' or pass_entry.get()=='' or confirmpass_entry.get()=='':
            messagebox.showerror('Error','All Fileds Are Required',parent=fpass)
        elif pass_entry.get()!=confirmpass_entry.get():
            messagebox.showerror('Error','Password and Confirm Password are not matching',parent=fpass)
        else:
           try: 
               con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
               cur=con.cursor()
               cur.execute('select * from admin where username=%s and pwd=%s',(username_info.get(),Currentpass_info.get()))
               row=cur.fetchone()
               if row==None:
                  messagebox.showerror('Error','Invalid Username And Password')
                  loginclear()
                  user_entry.focus()
               else:
                    cur.execute('update admin set pwd = %s where username = %s',(NewPass_info.get(),username))
                    messagebox.showinfo("Success","Password has been updated")
                    loginclear()
                    con.commit()
                    user_entry.focus()
                    con.close()
           except Exception as es:
                messagebox.showerror('Error',f'Error Due to : {str(es)}')
        
    fpass=Toplevel()
    fpass.title('Change password')
    bgImage=ImageTk.PhotoImage(file='image/background.jpg')
    bgLabel=Label(fpass,image=bgImage)
    bgLabel.grid()

    heading=Label(fpass,text='RESET PASSWORD',font=('arial',19,'bold'),bg='white',fg='magenta2')
    heading.place(x=475,y=60)

    username_info=StringVar()
    Currentpass_info=StringVar()
    NewPass_info=StringVar()
    ConfirmPass_info=StringVar()

    user_label=Label(fpass,text='Username',font=('Comic Sans MS',15,'bold'),bg='white',fg='orchid1')
    user_label.place(x=543,y=100)

    user_entry=Entry(fpass,width=25,fg='black',font=('arial',12,'bold'),bd=0,textvariable=username_info)
    user_entry.place(x=470,y=135)

    Frame(fpass,width=250,height=2,bg='orchid1').place(x=470,y=155)

    Currentpassdlabel=Label(fpass,text='Current Password',font=('Comic Sans MS',15,'bold'),bg='white',fg='orchid1')
    Currentpassdlabel.place(x=520,y=175)

    Currentpass_entry=Entry(fpass,width=25,fg='black',font=('arial',12,'bold'),bd=0,textvariable=Currentpass_info)
    Currentpass_entry.place(x=470,y=215)

    Frame(fpass,width=250,height=2,bg='orchid1').place(x=470,y=234)

    passwordlabel=Label(fpass,text='New Password',font=('Comic Sans MS',15,'bold'),bg='white',fg='orchid1')
    passwordlabel.place(x=530,y=245)

    pass_entry=Entry(fpass,width=25,fg='black',font=('arial',12,'bold'),bd=0,textvariable=NewPass_info)
    pass_entry.place(x=470,y=285)

    Frame(fpass,width=250,height=2,bg='orchid1').place(x=470,y=305)

    Confirmpasslabel=Label(fpass,text='Confirm Password',font=('Comic Sans MS',15,'bold'),bg='white',fg='orchid1')
    Confirmpasslabel.place(x=516,y=320)

    confirmpass_entry=Entry(fpass,width=25,fg='black',font=('arial',12,'bold'),bd=0,textvariable=ConfirmPass_info)
    confirmpass_entry.place(x=470,y=360)

    Frame(fpass,width=250,height=2,bg='orchid1').place(x=470,y=379)

    #Button-submit
    submitButton=Button(fpass,text='Submit',bd=0,bg='magenta2',fg='white',font=('Open Sans','16','bold'),
                    width=19,cursor='hand2',activebackground='magenta2',activeforeground='white',command=change_password)
    submitButton.place(x=477,y=410)
    fpass.mainloop()

def l():
    root.destroy()
    import NEWH   
def p():
        global f2
        f2= tk.Frame(root,width=250,height=155,bg=co2)
        f2.place(x=934,y=54)    
        def bttn(x,y,text,bcolor,fcolor,cmd):
            def on_entera(e):
                myButton1['background'] = bcolor 
                myButton1['foreground']= '#262626'  

            def on_leavea(e):
                myButton1['background'] = fcolor
                myButton1['foreground']= '#262626'

            myButton1 = tk.Button(f2,text=text,
                       fg='#262626',
                       border=0,
                       font=('Canva Sans',15),
                       bg=fcolor,
                       activeforeground='#262626',
                       activebackground=bcolor,
                       cursor='hand2',           
                        command=cmd)
                      
            myButton1.bind("<Enter>", on_entera)
            myButton1.bind("<Leave>", on_leavea)

            myButton1.place(x=x,y=y,width=248,height=50)

        bttn(0,0,'Edit Profile','#CC7DFF',co2,ep)
        bttn(0,50,'Change Password','#CC7DFF',co2,cp)
        bttn(0,100,'Logout','#CC7DFF',co2,l)
        def delet():
            f2.destroy()
            profileBtn = tk.Button(topFrame,image=profileIcon,cursor='hand2',bg=co2,activebackground=co2 ,bd=0,padx=20,command=p)
            profileBtn.place(x=1125,y=3)
        tk.Button(topFrame,image=profileIcon,bg=co2,activebackground=co2,cursor='hand2' ,bd=0,padx=20,command=delet).place(x=1125,y=3)
           
# setting switch function:
def switch():
    global btnState
    if btnState is True:
        # create animated navbar closing:
        for x in range(303):
            navRoot.place(x=-x,y=0)
            topFrame.update()

        # resetting widget colors:
        brandLabel.config(bg=co0,fg="blue")
        homeLabel.config(bg=co2,fg=co1)
        topFrame.config(bg=co2)
        root.config(bg=co0)

        #turning Button OFF:
        btnState = False
    else:
        # make root dim:
        brandLabel.config(bg=co0,fg="blue")
        homeLabel.config(bg=co2)
        topFrame.config(bg=co2)

        #created animated Navbar opening :
        for x in range(-300, 0):
            navRoot.place(x=x,y=0)
            topFrame.update()

            #turning button ON:
            btnState = True

#top Navigation bar:
topFrame = tk.Frame(root, bg=co2)
topFrame.pack(side="top", fill=tk.X)

# Header label text:
homeLabel = tk.Label(topFrame,text=username,font="Bahnschrift 15",bg=co2,fg=co1,height=2,padx=65)
homeLabel.pack(side="right")

#main label text:

brandLabel = tk.Label(root,text="",font="system 30",bg=co0,fg="blue")
brandLabel.place(x=501,y=350)

#========clock=======
# lbl_clock=tk.Label(root,text="Welcome to UserDashboard\t\t  Date:DD-MM-YYYY\t\t Time:HH:MM:SS",font=("times new roman",15),bg=co5,fg="blue")
# lbl_clock.place(x=0,y=50,relwidth=1,height=30)

#=========graph design======
# graph_lbl = tk.Label(root,image=graphIcon,bg=co0,activebackground=co0,bd=0,)   
# graph_lbl.place(x=2,y=80,height=380,width=450)
# graph_lbl1 = tk.Label(root,image=graphIcon1,bg=co0,activebackground=co0,bd=0,)   
# graph_lbl1.place(x=640,y=80,height=380,width=450)



#=======content======
# lbl_complaintInbox=tk.Button(root,text="Complaint \n Inbox",bd=5,relief="ridge",bg=co3,activebackground=co3,activeforeground="Blue",fg="blue",font=("goudy old style",25,"bold"))
# lbl_complaintInbox.place(x=50,y=420,height=200,width=350)

# lbl_complaintTracker=tk.Button(root,text="Complaint \n Tracker",bd=5,relief="ridge",bg=co3,activebackground=co3,activeforeground="Blue",fg="blue",font=("goudy old style",25,"bold"))
# lbl_complaintTracker.place(x=420,y=420,height=200,width=350)

# lbl_counsellor=tk.Button(root,text="Counsellor \n Appointment",bd=5,relief="ridge",bg=co3,activebackground=co3,activeforeground="Blue",fg="blue",font=("goudy old style",25,"bold"))
# lbl_counsellor.place(x=790,y=420,height=200,width=350)
#======footer========
lbl_footer=tk.Label(root,text="Stop Bully\n Report it fully",font=("times new roman",12),bg=co5,fg="white").pack(side="bottom", fill=tk.X)

# Navbar Button
navbarBtn = tk.Button(topFrame,image=navIcon,bg=co2,activebackground= co2 ,cursor='hand2', bd=0, padx=40,command=switch)
navbarBtn.place(x=10,y=6)
# Profile Button
profileBtn = tk.Button(topFrame,image=profileIcon,cursor='hand2',bg=co2,activebackground=co2 ,bd=0,padx=20,command=p)
profileBtn.place(x=1125,y=3)

# setting navbar Frame
navRoot = tk.Frame(root, bg=co0,height=1000,width=300)
navRoot.place(x=-300,y=0)
tk.Label(navRoot, font="Bahnschrift 15",bg=co4,fg=co0,height=2,width=300,padx=30).place(x=0,y=0)

# set y-coordinate of navbar widgets
y = 100
# options in the navbar:
#------------command-----------
def d():
    root.destroy()
    import a_dashboard
def ci():
    root.destroy()
    import a_inbox
def cs():
    def disp():
        l1.config(text='')
        def submit():
            if var.get() == 1:
                s = 'Received'
            elif var.get() == 2:
                s = 'Assigned'
            elif var.get() == 3:
                s = 'Under Investigation' 
            elif var.get() == 4:
                s = 'Resolved'
            elif var.get() == 5:
                s = 'Rejected'           
            con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
            my_cursor = con.cursor()
            my_cursor.execute('Update cstatus set status = %s , comment = %s where c_id = %s',(s,t1.get(1.0, "end-1c"),cid,))
            i = 'Your complaint is '+s+'\n'+t1.get(1.0, "end-1c")
            sub = 'Complaint Status'
            my_cursor.execute('Insert into inbox(to_1,from_1,subject,details) values(%s,%s,%s,%s)',(username,'HOD',sub,i))
            con.commit()
            con.close()
            messagebox.showinfo("Success","Status has been updated")
            b1.destroy()   
            f1.destroy()
        def gets(event=''):
            global cid
            cid = sel.get()
            con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
            my_cursor = con.cursor()    
            my_cursor.execute('Select * from cstatus where c_id = %s',(cid,))
            info = my_cursor.fetchall()
            for row in info:
                c = row[2]
                if row[1] == 'Received':
                    var.set(value=1)
                elif row[1] == 'Assigned':
                    var.set(value=2)
                elif row[1] == 'Under Investigation':
                    var.set(value=3)
                elif row[1] == 'Resolved':
                    var.set(value=4) 
                elif row[1] == 'Rejected':
                    var.set(value=5)
            t1.insert(END,c)
            my_cursor.execute('Select * from inbox where c_id = %s',(cid,))
            in_fo = my_cursor.fetchall()
            for row in in_fo:
                global username
                username = row[1]
            con.commit()
            con.close()       
        f1 = Frame(root1,bg='white',height=450,width=500)
        f1.place(x=0,y=120)
        Label(f1,text='Status',font=('Times New Roman',15,'bold'),bg='white',fg='black').place(x=70,y=10)
        var = IntVar()
        r1 = Radiobutton(f1,text='Received',variable=var,value=1,font=('Times New Roman',14),bg='white',fg='black')
        r1.place(x=180,y=10)
        r2 = Radiobutton(f1,text='Assigned',variable=var,value=2,font=('Times New Roman',14),bg='white',fg='black')
        r2.place(x=180,y=40)   
        r3 = Radiobutton(f1,text='Under Investigation',variable=var,value=3,font=('Times New Roman',14),bg='white',fg='black')
        r3.place(x=180,y=70)
        r4 = Radiobutton(f1,text='Resolved',variable=var,value=4,font=('Times New Roman',14),bg='white',fg='black')
        r4.place(x=180,y=100)
        r5 = Radiobutton(f1,text='Rejected',variable=var,value=5,font=('Times New Roman',14),bg='white',fg='black')
        r5.place(x=180,y=130)
        Label(f1,text='Comment',font=('Times New Roman',15,'bold'),bg='white',fg='black').place(x=50,y=180)
        t1 = Text(f1,font=('Canva Sans',11),fg='black',bg='white',bd=2,relief=GROOVE)
        t1.place(x=180,y=180,height=200,width=300)
        e = Entry(f1)
        e.place(x=50,y=520,height=10,width=10)
        e.focus()
        id.bind("<FocusOut>",gets)
        b1 =Button(root1,text='Update Status',font=('Times New Roman',13),bg='#E6E6FA',fg='black',relief='groove',activeforeground='black',activebackground='#E6E6FA',cursor='hand2',command=submit)
        b1.place(x=50,y=520)

    def upd(*args):
        my_list = []
        values =("%" + id.get() + "%",)
        con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
        my_cursor = con.cursor()
        my_cursor.execute('select c_id from inbox where c_id like %s',values)
        data = my_cursor.fetchall()
        for row in data:
            my_list.append(row[0])
        con.commit()
        con.close()
        id['values']=[]
        id['values']= my_list
        l1.config(text='Result:'+str(len(data)))

    root1 = Toplevel(root)
    root1.title("Bully Box")
    root1.geometry('500x570+0+0')
    root1.config(bg='white')
    root1.resizable()

    my_list=[]
    con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
    my_cursor = con.cursor()
    my_cursor.execute('select c_id from inbox where c_id is NOT NULL ')
    data = my_cursor.fetchall()
    for row in data:
        my_list.append(row[0])
    con.commit()
    con.close()

    frame = Frame(root1,bg='#C2E5D3',height=45,width=500)
    frame.place(x=0,y=0)
    Label(frame,text='Complaint Status',font=('Times New Roman',20,'bold'),bg='#C2E5D3',fg='black').place(x=140,y=4)

    id_label = Label(root1,text='Complaint Id',font=('Times New Roman',15,'bold'),bg='white',fg='black')
    id_label.place(x=50,y=70)
    sel = StringVar()
    id = ttk.Combobox(root1,values=my_list,width=25,height=30,textvariable=sel)
    id.place(x=180,y=72)
    sel.trace("w", upd)
    l1 = Label(root1,text='',font=('Times New Roman',13,'bold'),bg='white',fg='black')
    l1.place(x=390,y=70)

    b1 =Button(root1,text='Submit',font=('Times New Roman',13),bg='#E6E6FA',fg='black',relief='groove',activeforeground='black',activebackground='#E6E6FA',cursor='hand2',command=disp)
    b1.place(x=225,y=120)
    root1.mainloop()
def ur():
    def clear_data():
        userEntry.delete(0,END)
        NameEntry.delete(0,END)
        GmailEntry.delete(0,END)
        passwordEntry.delete(0,END)
    def reg():
        if userEntry=='' or NameEntry=='' or GmailEntry=='' or passwordEntry=='':
            messagebox.showerror('Error','All Fileds Are Required')
        else:
            try:
                con = mysql.connector.connect(host="localhost",username="root",password="Prakruti@18",database="bullybox")
                my_cursor = con.cursor()
                value = (userEntry.get(),)
                my_cursor.execute(('select * from students where username = %s'),value)
                row=my_cursor.fetchone()
                if row == 1:
                    messagebox.showerror('Error','This username exists')
                else:
                    my_cursor.execute('Insert into students(username,name,email_id,pwd) values(%s,%s,%s,%s)',(userEntry.get(),NameEntry.get(),GmailEntry.get(),passwordEntry.get()))
                con.commit()
                messagebox.showinfo("Success","Record has been submitted")
                clear_data()
                userEntry.focus()
                con.close()
            except Exception as es:
                con.rollback()
                messagebox.showerror('Error',f'Error Due to : {str(es)}')

    fpass=Toplevel(root)
    fpass.title('Bully Box')
    bgImage=ImageTk.PhotoImage(Image.open('image/background.jpg'))
    bgLabel=Label(fpass,image=bgImage)
    bgLabel.grid()

    frame=Frame(fpass,bg='white')
    frame.place(x=440,y=39,width=315,height=440)

    heading=Label(frame,text='Registration',font=('Comic Sans MS',20,'bold'),bg='white',fg='red')
    heading.grid(row=0,column=0,padx=10,pady=10)

    #Username craete
    userLabel=Label(frame,text='Username',font=('Microsoft YaHei UI Light',12,'bold'),fg='red',bg='white')
    userLabel.grid(row=1,column=0,sticky='w',padx=25,pady=(10,0))

    userEntry=Entry(frame,width=30,font=('Microsoft YaHei UI Light',10,'bold'),fg='red',bd=0,highlightbackground='red',highlightthickness=1)
    userEntry.grid(row=2,column=0,sticky='w',padx=25)

    # Frame(frame,width=225,height=2,bg='red').place(x=25,y=123)

    #gmail
    NameLabel=Label(frame,text='Student Name',font=('Microsoft YaHei UI Light',12,'bold'),fg='red',bg='white')
    NameLabel.grid(row=3,column=0,sticky='w',padx=25,pady=(10,0))
    
    NameEntry=Entry(frame,width=30,font=('Microsoft YaHei UI Light',10,'bold'),fg='red',bd=0,highlightbackground='red',highlightthickness=1)
    NameEntry.grid(row=4,column=0,sticky='w',padx=25)

    #password
    GmailLabel=Label(frame,text='Gmail',font=('Microsoft YaHei UI Light',12,'bold'),fg='red',bg='white')
    GmailLabel.grid(row=5,column=0,sticky='w',padx=25,pady=(10,0))
    
    GmailEntry=Entry(frame,width=30,font=('Microsoft YaHei UI Light',10,'bold'),fg='red',bd=0,highlightbackground='red',highlightthickness=1)
    GmailEntry.grid(row=6,column=0,sticky='w',padx=25)

    #confirm
    passwordLabel=Label(frame,text='Password',font=('Microsoft YaHei UI Light',12,'bold'),fg='red',bg='white')
    passwordLabel.grid(row=7,column=0,sticky='w',padx=25,pady=(10,0))
    
    passwordEntry=Entry(frame,width=30,font=('Microsoft YaHei UI Light',10,'bold'),fg='red',bd=0,highlightbackground='red',highlightthickness=1)
    passwordEntry.grid(row=8,column=0,sticky='w',padx=25)

    #signup button
    signupButton=Button(frame,text='Signup',font=('Microsoft Yahei UI Light',17,'bold'),bd=0,bg='firebrick1',fg='white',activebackground='white',cursor='hand2',activeforeground='firebrick1',command=reg)
    signupButton.place(x=50,y=350,width=200,height=50)

    fpass.mainloop()

def ud():
    root.destroy()
    
options = ["Dashboard","Inbox","Complaint Status","User Registeration","User Data"]
cmd = [d,ci,cs,ur,ud]
# navbar option Buttons:
for i in range(5):
    tk.Button(navRoot, text=options[i],font="BahnschriftLight 15",cursor='hand2' ,bg=co0,activebackground=co0,activeforeground="black",bd=0,command=cmd[i]).place(x=50,y=y)
    y += 60

# navbar Close button  
closeBtn = tk.Button(navRoot,image=closeIcon,bg=co4,activebackground=co4,cursor='hand2',bd=0,command=switch)   
closeBtn.place(x=250,y=2)

#dasghbord button ====
dashboardBtn = tk.Button(navRoot,image=dashboardIcon,bg=co0,cursor='hand2',activebackground=co0,bd=0,command=d)   
dashboardBtn.place(x=10,y=100)

complaintInboxBtn = tk.Button(navRoot,image=complainInboxIcon,bg=co0,cursor='hand2',activebackground=co0,bd=0,command=ci)   
complaintInboxBtn.place(x=10,y=160)

statusBtn = tk.Button(navRoot,image=trackingIcon,bg=co0,activebackground=co0,cursor='hand2',bd=0,command=cs)   
statusBtn.place(x=10,y=220)

userrBtn = tk.Button(navRoot,image=counsellorIcon ,bg=co0,activebackground=co0,cursor='hand2',bd=0,command=ur)   
userrBtn.place(x=10,y=280)

userdBtn = tk.Button(navRoot,image= udIcon,bg=co0,activebackground=co0,cursor='hand2',bd=0,command=ud)   
userdBtn.place(x=10,y=340)

# window in mainloop
root.mainloop()