from tkinter import*
import tkinter as tk
from tkinter import ttk
from PIL import ImageTk,Image
from tkinter import messagebox
import os

def About():
    Home.destroy()

def con():
    Home.destroy()

def studentpg():
    Home.destroy()
    import login1

def adminpg():
    Home.destroy()
    import Signadmin



def log():
 #login menu options
 login_menu_fm=tk.Frame(Home,bg='#251E37')
 Admin_btn=tk.Button(login_menu_fm,text='Admin',font=('Bold',11),bd=1,bg='#251E37',fg='white',
                        activebackground='#251E37',activeforeground='black',command=adminpg)
 Admin_btn.place(x=0,y=2)

 student_btn=tk.Button(login_menu_fm,text='Student',font=('Bold',11),bd=1,bg='#251E37',fg='white',
                        activebackground='#251E37',activeforeground='black',command=studentpg)
 student_btn.place(x=0,y=32)
 login_menu_fm.place(x=941,y=51,height=58,width=75)

def light():
    Home.destroy()
    import NEWH

def rec1():
    Home1=Toplevel(Home)
    Home1.geometry('478x660')
    Home1.resizable(0,0)
    bgImage=ImageTk.PhotoImage(Image.open('image/frame3.jpg'))
    bgLabel=Label(Home1,image=bgImage)
    bgLabel.place(x=0,y=0)
    Home1.mainloop()

def rec2():
    frame1=Toplevel(Home)
    frame1.geometry('478x660')
    frame1.resizable(0,0)
    bgImage=PhotoImage(file='image/Frame 4.png')
    bgLabel=Label(frame1,image=bgImage)
    bgLabel.place(x=0,y=0)
    frame1.mainloop()

def rec3():
    frame2=Toplevel(Home)
    frame2.geometry('478x660')
    frame2.resizable(0,0)
    bgImage=PhotoImage(file='image/Frame 5.png')
    bgLabel=Label(frame2,image=bgImage)
    bgLabel.place(x=0,y=0)
    frame2.mainloop()  

scriptDir = os.getcwd()

#window
Home=Tk()
Home.geometry("1183x603")
Home.title("Bully Box")
Home.resizable(False,False)
bgImage=ImageTk.PhotoImage(Image.open('image/Home2.jpg'))
bgLabel=Label(Home,image=bgImage)
bgLabel.place(x=0,y=0)

#Nav bar
Aboutus=PhotoImage(file="image/abt2.png")
Aboutusbutton=Button(Home,image=Aboutus,bd=0,background='#251E37',activebackground='#251E37',cursor='hand2',command=About).place(x=669,y=20)

contact=PhotoImage(file="image/con2.png")
contactbutton=Button(Home,image=contact,bd=0,background='#251E37',activebackground='#251E37',cursor='hand2',command=con).place(x=802,y=20)

login=PhotoImage(file="image/log2.png")
loginbutton=Button(Home,image=login,bd=0,background='#251E37',activebackground='#251E37',cursor='hand2',command=log).place(x=935,y=20)

sun=PhotoImage(file="image/sun.png")
sunbutton=Button(Home,image=sun,bd=0,background='#251E37',activebackground='#251E37',cursor='hand2',command=light).place(x=1116.96,y=15)

#rectangle button
rect1=PhotoImage(file="image/recta.png")
rect1button=Button(Home,image=rect1,bd=0,cursor='hand2',command=rec1).place(x=61,y=405,width=175,height=175)

rect2=PhotoImage(file="image/rectb.png")
rect2button=Button(Home,image=rect2,bd=0,cursor='hand2',command=rec2).place(x=401,y=407,width=175,height=175)

rect3=PhotoImage(file="image/rectc.png")
rect3button=Button(Home,image=rect3,bd=0,cursor='hand2',command=rec3).place(x=701,y=405,width=175,height=175)



Home.mainloop()