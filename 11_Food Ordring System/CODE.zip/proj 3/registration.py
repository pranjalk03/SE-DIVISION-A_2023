from tkinter import *

import mysql.connector

class registeration_C:
#CST_DATA_CHECK----------------------------------------------------------------------------------------------------------------------
    def data_check_cst(self):
        un = self.username_e.get()
        username = str(un)
        password = self.password_e.get()
        re_password = self.re_password_e.get()
        contact = self.contact_e.get()
        address = self.address_e.get()
        if (username == ''):
            def ok():
                alert.destroy()
            alert = Tk()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "Username field is empty " , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
            okbt.grid(row=0 , column=1)
            alert.mainloop()

        elif(len(username) > 21 ):
            def ok():
                alert.destroy()
                self.username_e.delete(0,END)
            alert = Tk()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "Username should be less than 20 characters " , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
            okbt.grid(row=0 , column=1)
            alert.mainloop()

            
            
        elif (password == ''):
            
            def ok():
                alert.destroy()
            alert = Tk()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "Password field is empty " , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
            okbt.grid(row=0 , column=1)
            alert.mainloop()
        
        elif (len(password) > 26):
            def ok():
                self.username_e.delete(0,END)
                alert.destroy()
            alert = Tk()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "password length must be less than 25 " , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
            okbt.grid(row=0 , column=1)
            alert.mainloop()
            
        elif (re_password =='' ):
            
            def ok():
                alert.destroy()
            alert = Tk()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "Re-Password field is empty " , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
            okbt.grid(row=0 , column=1)
            alert.mainloop()
        
        elif (contact == ''):
        
            def ok():
                alert.destroy()
            alert = Tk()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "Contact field is empty " , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
            okbt.grid(row=0 , column=1)
            alert.mainloop()

        elif(len(contact) < 10 ):
            def ok():
                self.contact_e.delete(0,END)
                alert.destroy()
            alert = Tk()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "Enter a valid contact number " , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
            okbt.grid(row=0 , column=1)
            alert.mainloop()
        
        elif(len(contact) > 11):
            def ok():
                self.contact_e.delete(0,END)
                alert.destroy()
            alert = Tk()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "Enter a valid contact number " , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
            okbt.grid(row=0 , column=1)
            alert.mainloop()

        elif (address == '' ):
            
            
                def ok():
                    alert.destroy()
                alert = Tk()
                alert.title("ALERT!!")
                lbl0 = Label(alert , text = "Address field is empty " , font = ('Arial',15))
                lbl0.grid(row=0 , column=0)
                okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
                okbt.grid(row=0 , column=1)
                alert.mainloop()
        
        elif(len(address)>200):
               
                def ok():
                    alert.destroy()
                
                alert = Tk()
                alert.title("ALERT!!")
                lbl0 = Label(alert , text = "Address field is only 200 letters  " , font = ('Arial',15))
                lbl0.grid(row=0 , column=0)
                okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
                okbt.grid(row=0 , column=1)
                alert.mainloop()
            
            
            
        else:
            pass

        if (password == re_password):
            def done():
                self.reg_frame_root.destroy()
                done_root.destroy()
                self.login_page()

            mydb = mysql.connector.connect(host='localhost',user='root',password='123456',database = 'Ziggy')
            cur = mydb.cursor()

            sql2 = "select * from Users where username = %s"
            sql22 = (username,)
            cur.execute(sql2,sql22)
            result2 = cur.fetchall()
            if(len(result2)==0):

                def done():
                    self.reg_frame_root.destroy()
                    done_root.destroy()
                    self.login_page()
                sql0 = "INSERT INTO Users (username,password,contact,user_type) VALUES (%s,%s,%s,%s)"
                sql00 = (username,password,contact,"cst")
                cur.execute(sql0,sql00)
                mydb.commit()
                cur.close()
                mydb.close()

                done_root = Tk()
                done_frame = Frame(done_root)
                test = Label(done_frame , text = 'User has been created  , pls login now ', font = ('Arial',15)).grid(row = 0 , column=0)
                okbt = Button(done_frame , text = 'OK' , command= done).grid(row =1 ,column=0)
                done_frame.pack()

                done_root.mainloop()
            else:
                def done():
                    self.username_e.delete(0,END)
                    done_root.destroy()
                    
                
                done_root = Tk()
                done_frame = Frame(done_root)
                test = Label(done_frame , text = 'Username already exists, pls login now ', font = ('Arial',15)).grid(row = 0 , column=0)
                okbt = Button(done_frame , text = 'OK' , command= done).grid(row =1 ,column=0)
                done_frame.pack()

                done_root.mainloop()

        else:
            
            alert = Tk()
            def pwder():
                self.password_e.delete(0,END)
                self.re_password_e.delete(0,END)
                alert.destroy()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "passwords don't match" , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= pwder)
            okbt.grid(row=0 , column=1)
            alert.mainloop()

       

#RST_INFO_CHECK------------------------------------------------------------------------------------------------       

    def data_check_rst(self):
        username = self.username_e.get()
        password = self.password_e.get()
        re_password = self.re_password_e.get()
        contact = self.contact_e.get()
        address = self.address_e.get()
        if (username == ''):
            def ok():
                alert.destroy()
            alert = Tk()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "Username field is empty " , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
            okbt.grid(row=0 , column=1)
            alert.mainloop()

        elif(len(username) > 21 ):
            def ok():
                alert.destroy()
                self.username_e.delete(0,END)
            alert = Tk()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "Username should be less than 20 characters " , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
            okbt.grid(row=0 , column=1)
            alert.mainloop()

            
            
        elif (password == ''):
            
            def ok():
                alert.destroy()
            alert = Tk()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "Password field is empty " , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
            okbt.grid(row=0 , column=1)
            alert.mainloop()
        
        elif (len(password) > 26):
            def ok():
                self.username_e.delete(0,END)
                alert.destroy()
            alert = Tk()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "password length must be less than 25 " , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
            okbt.grid(row=0 , column=1)
            alert.mainloop()
            
        elif (re_password =='' ):
            
            def ok():
                alert.destroy()
            alert = Tk()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "Re-Password field is empty " , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
            okbt.grid(row=0 , column=1)
            alert.mainloop()
        
        elif (contact == ''):
        
            def ok():
                alert.destroy()
            alert = Tk()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "Contact field is empty " , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
            okbt.grid(row=0 , column=1)
            alert.mainloop()

        elif(len(contact) < 10):
            def ok():
                self.contact_e.delete(0,END)
                alert.destroy()
            alert = Tk()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "Enter a valid contact number " , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
            okbt.grid(row=0 , column=1)
            alert.mainloop()

        elif(len(contact) > 11):
            def ok():
                self.contact_e.delete(0,END)
                alert.destroy()
            alert = Tk()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "Enter a valid contact number " , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
            okbt.grid(row=0 , column=1)
            alert.mainloop()
        

        elif (address == '' ):
            
            
                def ok():
                    alert.destroy()
                alert = Tk()
                alert.title("ALERT!!")
                lbl0 = Label(alert , text = "Address field is empty " , font = ('Arial',15))
                lbl0.grid(row=0 , column=0)
                okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
                okbt.grid(row=0 , column=1)
                alert.mainloop()
        
        elif(len(address)>200):
               
                def ok():
                    alert.destroy()
                
                alert = Tk()
                alert.title("ALERT!!")
                lbl0 = Label(alert , text = "Address field is only 200 letters  " , font = ('Arial',15))
                lbl0.grid(row=0 , column=0)
                okbt = Button(alert, text = 'OK' , font=('Arial',15), command= ok)
                okbt.grid(row=0 , column=1)
                alert.mainloop()


            
            
            
        else:
            pass

        if (password == re_password):
            def done():
                self.reg_frame_root.destroy()
                done_root.destroy()
                self.login_page()

            mydb = mysql.connector.connect(host='localhost',user='root',password='123456',database = 'Ziggy')
            cur = mydb.cursor()
            sql1 = "INSERT INTO Users (username,password,contact,user_type) VALUES (%s,%s,%s,%s)"
            sql11 = (username,password,contact,"rst")

            cur.execute(sql1,sql11)
            mydb.commit()
            cur.close()
            mydb.close()

            done_root = Tk()
            done_frame = Frame(done_root)
            test = Label(done_frame , text = 'User has been created  , pls login now ', font = ('Arial',15)).grid(row = 0 , column=0)
            okbt = Button(done_frame , text = 'OK' , command= done).grid(row =1 ,column=0)
            done_frame.pack()

            done_root.mainloop()
        else:
            alert = Tk()
            def pwder():
                self.password_e.delete(0,END)
                self.re_password_e.delete(0,END)
                alert.destroy()
            alert.title("ALERT!!")
            lbl0 = Label(alert , text = "passwords don't match" , font = ('Arial',15))
            lbl0.grid(row=0 , column=0)
            okbt = Button(alert, text = 'OK' , font=('Arial',15), command= pwder)
            okbt.grid(row=0 , column=1)
            alert.mainloop()
        


    def __init__(self):
        self.reg_frame_root = Tk()
        self.reg_frame_root.title('Registration')
        self.reg_frame = Frame(self.reg_frame_root , height=600 , width=800 , bg = '#20262E')
        self.reg_label0 = Label (self.reg_frame , text = 'Register to ' , font = ('Arial',25) , fg = '#F9F5E7',bg = '#20262E')
        self.reg_label1 = Label (self.reg_frame , text = 'Ziggy !' , font = ('Arial',25) , fg = '#FF8B13',bg = '#20262E')
        self.username_lbl = Label(self.reg_frame , text='Username :',font = ('Arial',20) , fg = '#F9F5E7',bg = '#20262E')
        self.password_lbl = Label(self.reg_frame , text='Password :',font = ('Arial',20) , fg = '#F9F5E7',bg = '#20262E')
        self.re_password_lbl = Label(self.reg_frame, text='Re Enter :',font = ('Arial',20) , fg = '#F9F5E7',bg = '#20262E')
        self.contact_lbl = Label(self.reg_frame , text='Phone Number :',font = ('Arial',20) , fg = '#F9F5E7',bg = '#20262E')
        self.address_lbl = Label(self.reg_frame , text = 'Address :',font = ('Arial',20) , fg = '#F9F5E7',bg = '#20262E')
        self.username_e = Entry (self.reg_frame , width=15 ,font = ('Arial',20),fg = '#F9F5E7' , bg= '#20262E')
        self.password_e = Entry(self.reg_frame , width=15 ,font = ('Arial',20),fg = '#F9F5E7' , bg= '#20262E',show='*')
        self.re_password_e = Entry(self.reg_frame , width=15,font = ('Arial',20),fg = '#F9F5E7' , bg= '#20262E',show='*')
        self.contact_e = Entry(self.reg_frame , width=15 ,font = ('Arial',20),fg = '#F9F5E7' , bg= '#20262E')
        self.address_e = Entry(self.reg_frame , width=15 ,font = ('Arial',20),fg = '#F9F5E7' , bg= '#20262E')
        cst_image = PhotoImage(file="customer.png")
        self.cst_reg_bt = Button(self.reg_frame ,height=25,image= cst_image, fg ='#F9F5E7',bg ='#20262E',activeforeground='#FF8B13',activebackground='#F9F5E7', command= self.data_check_cst)
        self.reg_label2 = Label(self.reg_frame , text='Register as' , fg = '#FF8B13',bg = '#20262E',font = ('Arial',20))
        rst_icon = PhotoImage(file='restaurant.png')
        self.rst_reg_bt = Button(self.reg_frame ,height=25, image= rst_icon, fg ='#F9F5E7',bg ='#20262E',activeforeground='#FF8B13',activebackground='#F9F5E7',command= self.data_check_rst)



        self.reg_label1.place(x =375 , y = 5)
        self.reg_label0.place(x=205,y=5)
        self.username_lbl.place(x = 10 , y = 60)
        self.password_lbl.place(x=10 , y = 100)
        self.re_password_lbl.place ( x=10 , y = 140)
        self.contact_lbl.place(x=10,y=180)
        self.address_lbl.place(x=10 , y= 220)
        self.username_e.place(x = 220 , y  = 60)
        self.password_e.place(x = 220 , y = 100)
        self.re_password_e.place(x=220 , y = 140)
        self.contact_e.place(x = 220 , y = 180)
        self.address_e.place(x = 220, y  = 220)
        self.cst_reg_bt.place(x = 150 , y = 300 )
        self.reg_label2.place ( x = 250 , y = 300)
        self.rst_reg_bt.place(x = 400 , y =300 )
        self.reg_frame.pack()
        self.reg_frame_root.mainloop()
       


