from numpy import * 

users = [['Soham','Dalvi','cst'] , ['Rabta','apsit','rst']]