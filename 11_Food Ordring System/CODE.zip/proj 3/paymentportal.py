from tkinter import *
from tkinter import PhotoImage
from PIL import Image,ImageTk

import mysql.connector
import subprocess



class payment_portal:
        def onclose(self,un,rstn,dn,pri,paytp):
                mydb = mysql.connector.connect(host = 'localhost' , user = 'root',password ='123456',database = 'Ziggy')
                cur = mydb.cursor()
                sql0 = "SELECT * FROM   Users WHERE username = %s"    
                sql00 = (un,)      
                cur.execute(sql0,sql00)
                result0 = cur.fetchall()
                contact = result0[0][5]
                address = result0[0][4]
                sql1 = "INSERT INTO Orders (username,dish_name,rst_name,price,address,contact,pay_type) VALUES (%s,%s,%s,%s,%s,%s,%s)"
                sql11 = (un,dn,rstn,pri,address,contact,paytp)
                print('payment done by '+un)
                cur.execute(sql1,sql11)
                mydb.commit()
                
        def cod(self,username,rstname,dishname,price):
              pay_type = 'cod'
              self.onclose(username,rstname,dishname,price,pay_type)


        def gpay_pay(self,username,rstname,dishname,price,cupon):
            
            gpayroot = Tk()
            
            gpay_frame = Frame(gpayroot,height=500, width=500 , bg='#F0F0F0')
            if(len(cupon)==0):
                  total_price = price
                  bool_val = 0
            else:
                mydb = mysql.connector.connect(host = 'localhost' , user = 'root',password ='123456',database = 'Ziggy')
                cur= mydb.cursor()
                sql1 = "SELECT * FROM Cupon WHERE rstname = %s AND code = %s"
                sql11 = (rstname,cupon)
                cur.execute(sql1,sql11)
                cupon_rs = cur.fetchone()
                discount = int(cupon_rs[2])
                total_price = str(price - (price*(discount/100)))
                bool_val = 1
            mydb = mysql.connector.connect(host = 'localhost' , user = 'root',password ='123456',database = 'Ziggy')
            cur= mydb.cursor()
            sql0 = "SELECT * FROM Users where username = %s"
            sql00 = (rstname,)
            cur.execute(sql0,sql00)
            result0 = cur.fetchall()
            conatct = Label(gpay_frame , font = ('Eras Light ITC',15),fg = '#3C486B',text = "contact number of "+str(result0[0][0])+' '+str(result0[0][2])  ).place(x = 5 , y = 5)
            upi_id = Label(gpay_frame , font = ('Eras Light ITC',15),fg = '#3C486B',text = "UPI ID number of "+ str(result0[0][0]) + ' ' + str(result0[0][6])   ).place (x=5,y=30)         
            dish_name_bill = Label(gpay_frame , font = ('Eras Light ITC',15),fg = '#3C486B',text =dishname).place(x =20 , y= 55)
            rstname_bill = Label(gpay_frame , font = ('Eras Light ITC',15),fg = '#3C486B',text =rstname).place(x =20 , y= 80)
            if(bool_val==1):
                  price_lbl = Label(gpay_frame , font = ('Eras Light ITC',15),fg = '#3C486B',text =price).place(x =20 , y= 105)
                  discount_lbl = Label(gpay_frame , font = ('Eras Light ITC',15),fg = '#3C486B',text ='After discount: '+total_price).place(x =20 , y= 130)
            elif(bool_val==0):
                  price_lbl = Label(gpay_frame , font = ('Eras Light ITC',15),fg = '#3C486B',text =price).place(x =20 , y= 105)
                  error_lbl = Label(gpay_frame , font = ('Eras Light ITC',15),fg = '#3C486B',text ="cupon was not applied ").place(x =20 , y= 130)
           # done = Button(gpay_frame,text = 'DONE', width = 4 , fg ='#212A3E',bg='#F0F0F0',font=('Eras Light ITC',15),command=lambda username = username , rstname=rstname , dishname = dishname , price = price,paytype='gpay' :self.onclose(username,rstname,dishname , price,paytype ) )
            paytype = 'gpay'
            #done.place(x = 20 , y = 90)
            cur.close()
            mydb.close()
            gpay_frame.pack()
            gpayroot.protocol("WM_DELETE_WINDOW",self.onclose(username,rstname,dishname,price,paytype))
            gpayroot.mainloop()
            

        def paytm_pay(self):
            
            paytmroot = Tk()



            paytmroot.mainloop()
            

        def __init__(self,username,rstname,dishname,price):
                mydb = mysql.connector.connect(host = 'localhost' , user = 'root',password ='123456',database = 'Ziggy')
                cur = mydb.cursor()
                self.payment_root = Tk()
                self.payment_root.title('Payment portal')
                frame = Frame(self.payment_root , width=600 , height=400,bg='#20262E')
                label1 = Label(frame , text = "Payment Portal" , font= ('Eras Light ITC',15),fg = '#F7D060',bg='#20262E').place(x=5, y = 5)
                label2 = Label(frame,text = 'Select your payment method : ',font=('Eras Light ITC',15),fg = '#F7D060',bg='#20262E').place(x=10 , y = 30)
                self.coupon_e = Entry(frame , width=8, font=('Kristen ITC',10),fg='#F7D060',bg='#20262E')
                self.coupon_e.place(x = 250 ,y =380)
                self.cupon = self.coupon_e.get()
                gpay = Button(frame ,text='GPAY',fg='#05BFDB',activeforeground='#05BFDB' , activebackground= '#20262E',bg = '#20262E',command=lambda cupon_code=self.cupon,un = username,rstname =rstname ,dishname = dishname , price =price :self.gpay_pay(un,rstname,dishname , price,cupon_code))
                gpay.place(x = 20 , y = 60)

                paytm = Button(frame ,text='PAYTM',fg='#088395',activeforeground='#088395', activebackground= '#20262E',bg = '#20262E',command=self.paytm_pay)
                paytm.place(x = 70 , y = 60 )
                cod = Button(frame ,text='CASH ON DELIVERY',fg='#088395',activeforeground='#088395', activebackground= '#20262E',bg = '#20262E',command=lambda un = username,cupon_code=self.cupon,rstname =rstname ,dishname = dishname , price =price :self.cod(un,rstname,dishname , price,cupon_code))
                cod.place(x = 120 , y = 60 )
                coupon_lbl = Label(frame, text = 'Enter Cupon code :', font = ('Kristen ITC',10) , fg='#F7D060',bg='#20262E').place(x = 5 , y = 380)
                
                
                frame.pack()

                self.payment_root.mainloop()

