from tkinter import *
from registration import registeration_C
from cstpage import *
from cstpage import cstpage_c
from rstpage import *
import mysql.connector



class login_page:
   
   

   
    def login_val(self):
        
        username = self.username_e.get()
        password = self.password_e.get()
        mydb = mysql.connector.connect(host='localhost',user='root',password='123456',database = 'Ziggy')
        cur = mydb.cursor()
        sql0 = "SELECT * FROM Users WHERE username = %s && password =%s"
        sql00 = (username,password)
        cur.execute(sql0,sql00)
        result0 = cur.fetchall()
        
        user_type = result0[0][4]
        if result0:
            if (user_type=='cst'):
                self.loginpage_root.destroy()
                print(username+' logged in ')
                cstpage_c(username)
            elif (user_type=='rst'):
                self.loginpage_root.destroy()
                print(username+' logged in ')
                rstpage(username)
                
            else:
                    def ok():
                        self.username_e.delete(0,END)
                        self.password_e.delete(0,END)
                        alert_root.destroy()

                    alert_root = Tk()
                    alret_frame = Frame(alert_root )
                    lbl0 = Label(alret_frame , text = 'NO DATA FOUND !' ).grid(row = 0 , column=0)
                    okbt = Button(alret_frame , text = 'OK' , command=ok).grid(row = 1 , column=0)

                    alret_frame.pack()
                    alert_root.mainloop()
        
            cur.close()
            mydb.close()

        


    def register_bt_fun(self):
        self.loginpage_root.destroy()
        registeration_C()        

   
   
   
   




    def __init__(self):
        self.loginpage_root = Tk()
        self.loginpage_root.title("Ziggy Login")
        
        self.mainframe = Frame(self.loginpage_root ,height=600 , width = 800 ,bg = '#20262E')
        self.wlcm_lbl = Label(self.mainframe ,text = "WELCOME TO ZIGGY" , bg = '#20262E' ,fg='#FF8B13', font=('Arial',20))
        self.username_lbl = Label(self.mainframe,text = "Username : " , bg = '#20262E' ,fg='#FF8B13', font=('Arial',15))
        self.username_e = Entry(self.mainframe , width = 20 , fg = '#FF8B13' , bg = '#20262E' , font=('Arial',10) )
        self.password_lbl = Label(self.mainframe , text = 'Password  : ', bg = '#20262E' ,fg='#FF8B13', font=('Arial',15))
        self.password_e = Entry(self.mainframe , width = 20 , fg = '#FF8B13' , bg = '#20262E' , font=('Arial',10) ,show ='*')
        self.login_bt = Button(self.mainframe , width= 10 ,  font =('Arial',10) , fg = '#FF8B13',bg='#20262E',activebackground='#205E61',text = "Login",command = self.login_val )
        self.register_bt = Button(self.mainframe , width= 10 ,  font =('Arial',10) , fg = '#FF8B13',bg='#20262E',activebackground='#205E61' ,text = 'Register' ,command = self.register_bt_fun)
         
        self.wlcm_lbl.place(x =300 , y =10 )
        self.username_lbl.place(x=10 , y = 80)
        self.username_e.place (x = 150 , y = 80)
        self.password_lbl.place(x = 10 , y = 110)
        self.password_e.place(x =150 , y = 110)
        self.login_bt.place(x = 150 , y = 200)
        self.register_bt.place(x = 250 , y = 200)
        self.mainframe.pack()
        self.loginpage_root.mainloop()
        







login_page()

