from tkinter import * 
class aodk:
    def __init__(self) :
        
        def submit():
            print (self.ans.get())
        root = Tk()
        frame = Frame(root , height = 400 , width= 500)
        self.ans = StringVar()
        s1 = Spinbox(frame , values=('Hydrabad','Delhi','Kolata','Mulund'),textvariable= self.ans , width=15 , fg = 'black' , bg = 'white')
        s1.place (x = 5 , y = 5)
        b = Button(frame , width= 4 , text = 'aidj' , command= submit)
        b.place(x = 50 , y = 50)

        frame.pack()
        root.mainloop()
aodk()