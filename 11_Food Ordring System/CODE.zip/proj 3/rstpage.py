from tkinter import * 
import mysql.connector

class rstpage:

    def home_back(self):
      try:
         self.orderstatus.pack_forget()
      except:
         pass
      self.profframe.pack_forget()
      self.rstframe1.pack_forget()
      self.ordersframe.pack_forget()
      self.ordersframe1.pack_forget()
      self.menu_edit.pack_forget()
      self.rstframe.pack()  
      self.rstframe1.pack()          

    def orders_call(self):
       
      self.menu_edit.pack_forget()    
      self.rstframe.pack_forget()
      self.profframe.pack_forget()
      self.rstframe1.pack_forget()
      try:
         self.orderstatus.pack_forget()
      except:
         pass
      self.ordersframe.pack()
      self.ordersframe1.pack()     

    def rstmyprof(self):
      try:
         self.orderstatus.pack_forget()
      except:
         pass
      self.rstframe.pack_forget()
      self.rstframe1.pack_forget()

      self.ordersframe.pack_forget()
      self.ordersframe1.pack_forget()
      self.menu_edit.pack_forget()
      self.profframe.pack()

    def menu_back(self):
      try:
         self.orderstatus.pack_forget()
      except:
         pass
      self.rstframe.pack_forget()
      self.rstframe1.pack_forget()

      self.ordersframe.pack_forget()
      self.ordersframe1.pack_forget()
     
      self.profframe.pack_forget()
      self.menu_edit.pack()




    def add_menu_func (self,un):
       dishname= self.dishname_e.get()
       temp = self.dishprice_e.get()
       dishprice = int(temp)
       dishtype = self.dishtype_e.get()
       index = self.dishtype_e2.curselection()
       if index :
          selected = self.dishtype_e2.get(index[0])
       mydb = mysql.connector.connect(host='localhost',user='root',password='123456',database='Ziggy')
       cur = mydb.cursor()
       sql2 = "SELECT * FROM Menu WHERE name = %s AND dish_name = %s "
       sql02 = (un,dishname)
       cur.execute(sql2,sql02)
       result2 = cur.fetchall()
       if len(result2)>0 :
          def ook_():
             self.dishname_e.delete(0,END)
             self.dishprice_e.delete(0,END)
             self.dishtype_e.delete(0,END)
          done = Tk()
          created = Label(done,text = 'Dish already is there in your menu').grid(row=0,column=0)
          okbt = Button(done,text='OK',command = ook_).grid(row=1,column=0)
          done.mainloop()
       else:
          sql3 = "INSERT INTO Menu (name,dish_name,dish_price,dish_type,dish_type2) VALUES (%s,%s,%s,%s,%s)"
          sql03= (un,dishname,dishprice,dishtype,selected)
          cur.execute(sql3,sql03)
          print(un+"'s dish has been added")
          mydb.commit()
          cur.close()
          mydb.close()
          def ook_():
             self.dishname_e.delete(0,END)
             self.dishprice_e.delete(0,END)
             self.dishtype_e.delete(0,END)
          done = Tk()
          created = Label(done,text = 'Dish has been added to your menu').grid(row=0,column=0)
          okbt = Button(done,text='OK',command = ook_).grid(row=1,column=0)
          done.mainloop()

       cur.close()
       mydb.close()


    def delete_menu_func(self,un):
       dishname= self.dishname_e.get()
       temp = self.dishprice_e.get()
       dishprice = int(temp)
       dishtype = self.dishtype_e.get()
       mydb = mysql.connector.connect(host='localhost',user='root',password='123456',database='Ziggy')
       cur = mydb.cursor()
       sql0 = "SELECT * FROM Menu WHERE name = %s AND dish_name = %s AND dish_type = %s"
       sql00 = (un,dishname,dishtype)
       cur.execute(sql0,sql00)
       result0 = cur.fetchall()
       if len(result0) > 0:
          sql1 = "DELETE FROM Menu WHERE name = %s AND dish_name = %s AND dish_type = %s" 
          sql01= (un,dishname,dishtype)
          cur.execute(sql1,sql01)
          mydb.commit()
          print('a dish has been removed from '+un+"'s Menu")
       else:
          def done():
            self.dishname_e.delete(0,END)
            self.dishprice_e.delete(0,END)
            self.dishtype_e.delete(0,END)
            done_root.destroy()
                    
                
          done_root = Tk()
          done_frame = Frame(done_root)
          test = Label(done_frame , text = 'No Such dish exists in your menu !', font = ('Arial',15)).grid(row = 0 , column=0)
          okbt = Button(done_frame , text = 'OK' , command= done).grid(row =1 ,column=0)
          done_frame.pack()

          done_root.mainloop()

       
    def refresh_menu(self,un):
       self.rstframe1.pack_forget()
       self.rstframe.pack_forget()
       self.rstframe.pack()
       self.rstframe1 = Frame (self.rst_root , height = 550 , bg='#20262E',width=800)
       mydb = mysql.connector.connect(host='localhost',user='root',password='123456',database='Ziggy')
       cur = mydb.cursor()
       sql0 = "SELECT dish_name,dish_price,dish_type FROM Menu WHERE name = %s"
       sql00 =(un,)
       cur.execute(sql0,sql00)
       result0 = cur.fetchall()
       for i,row in enumerate(result0) :
          for j,value in enumerate(row) :
             self.menu_list = Label(self.rstframe1,bg ='#20262E',font =('Lucida Handwriting',15),fg='#B2A4FF',text=value)
             self.menu_list.grid(row=i+1,column=j)
       cur.close()
       mydb.close()
       
       self.rstframe1.pack()
       
    def refresh_orders_fun(self,un):
      
      self.ordersframe1.pack_forget()
      self.orders1frame1.pack_forget()
      self.orders1frame1 = Frame(self.rst_root, width =  800 , height= 520,bg = '#20262E')
      mydb = mysql.connector.connect(host = 'localhost' , user = 'root',password = '123456' , database = 'Ziggy')
      cur = mydb.cursor()
      sql1 = "SELECT * FROM Orders WHERE rst_name = %s"
      sql11 = (un,)
      cur.execute(sql1,sql11)
      result1 = cur.fetchall()
      for i,row in enumerate(result1):
         for j , column in enumerate(row):
            order_result = Label(self.orders1frame1 , text = result1[i][j] , font = ('Arial',15) ,fg ='#F0F0F0' , bg = '#20262E' )
            order_result.place(x = j*150 , y =i*50 )

      self.orders1frame1.pack()

       
    def orders_status_fun(self,un):
      def enter_status(un):
         def okfunc():
            status_update_root.destroy()



         mydb = mysql.connector.connect(host='localhost',user='root',password = '123456' , database = 'Ziggy')
         username_status = self.username_status_e.get()
         
         dishname_status = self.dishname_status_e.get()
         address_status = self.address_status_e.get()
         main_status0 = self.main_status_sb.get()
         sql0 = "UPDATE Orders SET status = %s WHERE username = %s AND dish_name = %s AND address = %s AND rst_name = %s"
         sql00 =  (main_status0,username_status , dishname_status , address_status,un)
         mydb.commit()
         status_update_root = Tk()
         label2 = Label(status_update_root ,text = 'Status updated' , font =('Arial',15)  ).grid(row=0,column=0)
         okbutton = Button(status_update_root , text = 'ok' , width = 3 , height = 2,command = okfunc)
         okbutton.grid(row=1,column = 0)


         status_update_root.mainloop()


      self.ordersframe1.pack_forget()

      try:
         self.orderstatus.pack_forget()
      except:
         pass
      self.orderstatus =  Frame(self.rst_root, width =  800 , height= 520,bg = '#20262E')
      
      label1 = Label(self.orderstatus , text = "Enter the status of the order here :", font = ('Bradley Hand ITC',15), fg ='#87CBB9' , bg ='#20262E').place(x=5 , y =5)
      username_lbl = Label(self.orderstatus , text = "Customer Name: ", font = ('Bradley Hand ITC',15), fg ='#87CBB9' , bg ='#20262E').place(x=5 , y =20)
      dishname_lbl = Label(self.orderstatus , text = "Dish Name: ", font = ('Bradley Hand ITC',15), fg ='#87CBB9' , bg ='#20262E').place(x=5 , y =50)
      address_lbl = Label(self.orderstatus , text = "Address : ", font = ('Bradley Hand ITC',15), fg ='#87CBB9' , bg ='#20262E').place(x=5 , y =80)
      status_lbl = Label(self.orderstatus , text = "Status : ", font = ('Bradley Hand ITC',15), fg ='#87CBB9' , bg ='#20262E').place(x=5 , y =110)
      
      self.username_status_e = Entry (self.orderstatus , width = 20 , font = ('Bradley Hand ITC',15), fg = '#C9F4AA' , bg = '#20262E')
      self.dishname_status_e = Entry (self.orderstatus , width = 20 , font = ('Bradley Hand ITC',15), fg = '#C9F4AA' , bg = '#20262E')
      self.address_status_e = Entry (self.orderstatus , width = 20 , font = ('Bradley Hand ITC',15), fg = '#C9F4AA' , bg = '#20262E')
      self.main_status_sb = Entry(self.orderstatus ,  width = 20 , fg = '#C9F4AA',bg = '#20262E',font = ('Bradley Hand ITC',15))
      self.username_status_e.place(x =200 , y = 20 )
      self.dishname_status_e.place(x = 200 , y = 50)
      self.address_status_e.place(x = 200 , y = 80)
      self.main_status_sb.place(x =200 , y = 110 )
      
      submit_icon = PhotoImage(file='submitstatus.png')
      submit_status_bt = Button (self.orderstatus , image= submit_icon , height = 25 , width = 25 , bg= '#20262E', activebackground='#20262E',command = lambda:enter_status(un))
      submit_status_bt.place(x = 20 , y =160 )
      self.orderstatus.pack()
      self.rst_root.mainloop()
       



    def logout(self,un):
      print(un+' has logged out')
      self.rst_root.destroy()     
    
    def __init__ (self,un):
      self.rst_root = Tk()
      self.rst_root.title ('My Restaurent')

# ADD/DEL DISH TO MENU _------------------------------------------------------------------------------------------------------------------
      self.menu_edit =Frame(self.rst_root,width=800 ,height = 600,bg = '#20262E')
      self.lbl1 = Label(self.menu_edit , text = 'Add or remove dishes from your menu',font =('Bradley Hand ITC',15),fg='#FFEAEA',bg='#20262E').place(x=5,y=5)
      self.dishname_lbl = Label(self.menu_edit , text = 'Dish name : ',font =('Bradley Hand ITC',15),fg='#FFEAEA',bg='#20262E' ).place(x=10 , y = 30 )
      self.dishprice_lbl = Label(self.menu_edit,text = 'Dish price : ',font= ('Bradley Hand ITC',15),fg='#FFEAEA',bg='#20262E').place(x=10 , y =70 )
      self.dishtype_lbl = Label(self.menu_edit,text = 'Dish type : ',font= ('Bradley Hand ITC',15),fg='#FFEAEA',bg='#20262E').place(x=10 , y =110 )
      self.dishtype2_lbl = Label(self.menu_edit,text = 'Quick Search : ',font= ('Bradley Hand ITC',15),fg='#FFEAEA',bg='#20262E').place(x=10 , y =150 )

      self.dishname_e =  Entry(self.menu_edit , width=15 , font =('Bradley Hand ITC',15),bg = '#20262E', fg = '#FFEAEA' )
      self.dishprice_e = Entry(self.menu_edit , width=15 , font =('Bradley Hand ITC',15),bg = '#20262E', fg = '#FFEAEA' )
      self.dishtype_e = Entry(self.menu_edit , width=15 , font = ('Bradley Hand ITC',15),bg = '#20262E', fg = '#FFEAEA')
      self.dishtype_e2 = Listbox(self.menu_edit , width=15 , font = ('Bradley Hand ITC',15),bg = '#20262E', fg = '#FFEAEA',selectmode = SINGLE)
      items = ['cake','icecreame','indian dessert','waffle' , 'pancake','salad','bread','chinese','thali','biriyani','pizza']
      for i in items:
         self.dishtype_e2.insert(END,i)
      
      additem_icon = PhotoImage(file='add-file.png')
      self.additem_bt = Button(self.menu_edit , width = 25,height=25 , image= additem_icon , bg = '#20262E',activebackground='#20262E',command=lambda: self.add_menu_func(un))
      deleteitem_icon = PhotoImage(file='delete-file.png')
      self.deleteitem_bt = Button(self.menu_edit , width = 25 ,height=25 , image= deleteitem_icon , bg = '#20262E',activebackground='#20262E',command=lambda: self.delete_menu_func(un))
      self.dishtype_e2.place(x =150,y=150 )
      self.dishname_e.place(x = 150, y = 30 )
      self.dishprice_e.place(x = 150, y = 70 )
      self.dishtype_e.place(x = 150, y = 110 )

      self.additem_bt.place(x = 20 , y = 200 )
      self.deleteitem_bt.place (x = 100 ,y = 200)

      self.menu_edit.pack_forget()
      




  #RST PROFILE ------------------------------------------------------------------------------------------------------------------
      
      #EDIT PROFILE DATA------------------------------------------------------------------------------------------------------------       
      def submit_data ():
        username = self.username_sh_e.get()
        password = self.password_sh_e.get()
        contact = self.contact_e.get()
        address = self.address_e.get()
        email = self.email_e.get()
        upi = self.upi_e.get()
        if len(username) == 0 and len(username)>20 :
            def ok_():
              self.username_sh_e.delete(0,END)
              ok.destroy()
            ok = Tk()
            lbl = Label(ok,text="Username limit is from 1 to 20").grid(row=0,column = 0)
            ok_bt = Button(ok , text = "ok",command=ok_).grid(row=1,column=0)

            ok.mainloop()

        elif len(password) == 0 and len(password) >20 :
          def ok_():
             self.password_sh_e.delete(0,END)
             ok.destroy()
          ok = Tk()
          lbl=    Label(ok,text="Password limit is from 1 to 20").grid(row=0,column = 0)       
          ok_bt = Button(ok , text="OK",command=ok_).grid(row=1,column=0)
          ok.mainloop()

        elif len(contact)< 10 and len(contact)>11:
          def ok_():
             self.contact_sh_e.delete(0,END)
             ok.destroy()
          ok=Tk()
          lbl = Label(ok,text="Contact limit is from 10 to 11").grid(row=0,column = 0)
          ok_bt = Button(ok , text="OK",command=ok_).grid(row=1,column=0)
          ok.mainloop()
        elif len(address) == 0 and len(address) >200 :
          def ok_():
              self.address_e.delete(0,END)
              ok.destroy()
          ok = Tk()
          lbl = Label(ok,text="Address limit is 200 letters").grid(row=0,column = 0) 
          ok_bt = Button(ok , text="OK",command=ok_).grid(row=1,column=0)
          ok.mainloop()
        elif len(email) == 0 :
          def ok_():
              self.email_e.delete(0,END)
              ok.destroy()
          ok = Tk()
          lbl = Label(ok,text="Enter your email id").grid(row=0,column = 0) 
          ok_bt = Button(ok , text="OK",command=ok_).grid(row=1,column=0)
          ok.mainloop()
        elif len(upi) < 10:
          def ok_():
              self.upi_e.delete(0,END)
              ok.destroy()
          ok = Tk()
          lbl = Label(ok,text="Enter valid upi id ").grid(row=0,column = 0) 
          ok_bt = Button(ok , text="OK",command=ok_).grid(row=1,column=0)
          ok.mainloop() 


        else:
          mydb = mysql.connector.connect(host='localhost',user='root',password='123456',database='Ziggy')
          cur = mydb.cursor()
          sql1 = "UPDATE Users SET username = %s , password = %s , contact = %s , email = %s , address = %s WHERE username = %s"
          sql01 = (username,password,contact,email,address,un)
          cur.execute(sql1,sql01)
          mydb.commit()
          sql2 = "UPDATE Menu SET name = %s WHERE name = %s"
          sql02=(username,un)
          cur.execute(sql2,sql02)
          mydb.commit()
          print(un+"'s profile has been updated !")
          cur.close()
          mydb.close()


      self.profframe = Frame(self.rst_root,width=800 ,height = 600,bg = '#20262E')
      self.username_sh = Label (self.profframe , text = "Username :",font=('Arial',20) , fg = '#FF8B13',bg = '#20262E')
      self.username_sh_e = Entry(self.profframe , width = 10,font = ('Arial',20),fg = '#F9F5E7' , bg= '#20262E')
      self.username_lbl = Label(self.profframe , text = "Rabta's Profile", font=('Arial',20) , fg = '#FF8B13',bg = '#20262E')
      
      self.password_sh =Label(self.profframe , text='Password :' ,font=('Arial',20) , fg = '#FF8B13',bg = '#20262E' ) 
      self.password_sh_e = Entry(self.profframe , width = 10,font = ('Arial',20),fg = '#F9F5E7' , bg= '#20262E',show='*')
      self.contact_sh = Label(self.profframe , text='Contact :' ,font=('Arial',20) , fg = '#FF8B13',bg = '#20262E' ).place(x = 10 , y=120)
      self.contact_e = Entry(self.profframe , width = 10,font = ('Arial',20),fg = '#F9F5E7' , bg= '#20262E')
      self.address_lbl = Label(self.profframe , text = 'Address :' , font =('Arial',20) , fg = '#FF8B13' , bg= '#20262E')
      self.email_lbl = Label(self.profframe , text = "Email :" , font = ("Airal",20) , fg = '#FF8B13' , bg= '#20262E')
      self.address_e = Entry (self.profframe , width = 10 , font = ('Arial',20),fg = '#F9F5E7' , bg= '#20262E')
      self.email_e = Entry (self.profframe , width = 10 , font = ('Arial',20),fg = '#F9F5E7' , bg= '#20262E')
      self.edit_bt = Button (self.profframe , width =16 ,text= 'Submit Changes ?', font = ('Century',15) ,fg='#FFEBB7',bg='#20262E',activebackground='#2C74B3', activeforeground='#FFEBB7',command=submit_data )
      self.upi = Label(self.profframe , text = 'UPI ID :', font = ("Airal",20) , fg = '#FF8B13' , bg= '#20262E')
      self.upi_e = Entry (self.profframe , width = 10 , font = ('Arial',20),fg = '#F9F5E7' , bg= '#20262E')

      self.upi_e.place(x = 200 ,y = 250)
      self.upi.place(x = 20  ,y= 250 )
      self.contact_e.place(x = 200 , y = 120)
      self.edit_bt.place(x = 50 , y = 300)
      self.email_e.place(x = 200 ,y = 200)
      self.address_e.place(x = 200 ,y =160)
      self.email_lbl.place(x = 10 , y = 200)
      self.address_lbl.place(x = 10 , y =160)
      
      self.password_sh.place(x=10 , y  = 80)
      self.password_sh_e.place(x= 200 ,y = 80 )
      self.username_sh_e.place(x=200 , y = 40)
      self.username_lbl.place(x = 5 , y =5)
      self.username_sh.place(x = 10 , y = 40)
      self.profframe.pack_forget()
      

  #RST ORDERS ---------------------------------------------------------------------------------------------------connectivity not done 

      self.ordersframe = Frame(self.rst_root , width=800 ,height =80,bg = '#20262E')
      self.placedorders = Label (self.ordersframe , text = 'Placed orders' , font=('Arial',20) , fg = '#FF8B13',bg = '#20262E' )
      refres_icon_ = PhotoImage(file='refresh.png')
      self.refresh_orders = Button (self.ordersframe , image=refres_icon_ , bg='#20262E' , foreground='#20262E',command = lambda :self.refresh_orders_fun(un))
      orders_placed = PhotoImage(file='orderplaced.png')
      self.placed_orders_bt = Button(self.ordersframe , image= orders_placed , bg= '#20262E',foreground='#20262E',command = lambda:self.orders_status_fun(un))
      self.refresh_orders.place(x = 600 , y = 5)
      self.placed_orders_bt.place(x = 700 , y = 5)
      self.placedorders.place(x = 5 , y = 5)
      self.ordersframe.pack()
      self.ordersframe1 = Frame(self.rst_root , width =  800 , height= 520,bg = '#20262E')
      mydb = mysql.connector.connect(host = 'localhost' , user = 'root',password = '123456' , database = 'Ziggy')
      cur = mydb.cursor()
      sql1 = "SELECT * FROM Orders WHERE rst_name = %s"
      sql11 = (un,)
      cur.execute(sql1,sql11)
      result1 = cur.fetchall()
      for i,row in enumerate(result1):
         for j , column in enumerate(row):
            order_result = Label(self.ordersframe1 , text = column , font = ('Arial',15) ,fg ='#F0F0F0' , bg = '#20262E' )
            order_result.place(x = j*100, y =i*50 )

      self.ordersframe.pack_forget()
      self.ordersframe1.pack_forget()
  # RST HOME PAGE -------------------------------------------------------------------------------------
      #MENUBAR---------------------------------------------------------------------------------------------------------------------------------
      self.rstframe = Frame(self.rst_root , width=800 , height = 600,bg = '#20262E' )
      self.menubar = Menu(self.rst_root)
      self.rst_root.config(menu = self.menubar)
      self.myprofmenu = Menu(self.rst_root,tearoff=0)
      self.myprofmenu.add_command(label='Edit Profile',command=self.rstmyprof)
      self.myprofmenu.add_command(label='Home' , command= self.home_back)
      self.myprofmenu.add_command(label='Menu' , command= self.menu_back)
      self.myprofmenu.add_command(label = 'Log Out',command = lambda: self.logout(un))
      self.menubar.add_cascade(label='MY PROFILE',menu = self.myprofmenu)
      self.ordersmenu = Menu(self.rst_root,tearoff=0)
      self.ordersmenu.add_command(label = 'Orders' ,command= self.orders_call)
      self.menubar.add_cascade(label='ORDERS', menu = self.ordersmenu)
        
      self.rstframe = Frame(self.rst_root,width=800 ,height = 50,bg = '#20262E')
        
      menu_lbl = Label(self.rstframe , text = un+"'s Menu",font=('Comic Sans MS',20),bg='#20262E',fg='#FDF7C3').place(x=5 , y =5)
      refres_icon = PhotoImage(file='refresh.png')
      refresh_bt = Button(self.rstframe,image = refres_icon , bg= '#20262E',activebackground= '#2F0F5D',height=25 , width=25,command=lambda:self.refresh_menu(un) )
      refresh_bt.place(x = 700 , y = 5)

      self.rstframe.pack()
      self.rstframe1 = Frame (self.rst_root , height = 550 , bg='#20262E',width=800)
      mydb = mysql.connector.connect(host='localhost',user='root',password='123456',database='Ziggy')
      cur = mydb.cursor()
      sql0 = "SELECT dish_name,dish_price,dish_type FROM Menu WHERE name = %s"
      sql00 =(un,)
      cur.execute(sql0,sql00)
      result0 = cur.fetchall()
      for i,row in enumerate(result0) :
         for j,value in enumerate(row) :
            self.menu_list = Label(self.rstframe1,bg ='#20262E',font =('Lucida Handwriting',15),fg='#B2A4FF',text=value)
            self.menu_list.grid(row=i+1,column=j)
      cur.close()
      mydb.close()
      
      self.rstframe1.pack()
      self.rst_root.mainloop()


