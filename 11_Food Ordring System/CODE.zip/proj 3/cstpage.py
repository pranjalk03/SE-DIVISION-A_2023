from tkinter import *
from tkinter import ttk
from customtkinter import * 
from paymentportal import *
import threading
import mysql.connector

class cstpage_c:
    def payment_portal_function(self,username,rstname,dishname,price):
        def launch_payment_portal():
            self.cstroot.withdraw()
            payment_portal(username, rstname,dishname , price  )
            self.cstroot.deiconify()
        payment_thread = threading.Thread(target=launch_payment_portal)
        payment_thread.start()
      
    def cstprof(self):
        self.cstframe.pack_forget()
        self.searchframe.pack_forget()
        self.serch1frame1.pack_forget()
        self.ordersframe.pack_forget()
        self.serch1frame.pack_forget()
        self.cstprof_frame.pack()
    def csthome(self):
        self.cstprof_frame.pack_forget()
        self.serch1frame1.pack_forget()
        self.ordersframe.pack_forget()

        self.searchframe.pack_forget()
        self.serch1frame.pack_forget()
        self.cstframe.pack()
    def logout(self,un):
        self.cstroot.destroy()
        print(un+' logged out')
        self.login_page()

    def search(self):
        self.cstframe.pack_forget()
        self.cstprof_frame.pack_forget()
        self.serch1frame1.pack_forget()
        self.ordersframe.pack_forget()
        self.searchframe.pack()
        self.serch1frame.pack()

    def orders(self):
        self.cstframe.pack_forget()
        self.cstprof_frame.pack_forget()
        self.serch1frame.pack_forget()
        self.serch1frame1.pack_forget()
        self.searchframe.pack_forget()
        self.ordersframe.pack()

    def searchbyfood(self):
        self.serch1frame.pack_forget()
        self.serch1frame1.pack()

    def searchbyrst(self):
        self.serch1frame.pack_forget()
        self.serch1frame1.pack()

    


    

    def quick_search(self,parameter,un):
        def back_func():
            self.quick_search_fr.pack_forget()
            self.quick_search_scroll_frame.pack_forget()
            self.cstframe.pack()
        self.cstframe.pack_forget()
        self.quick_search_fr = Frame(self.cstroot , height=50 , width=800,bg='#20262E')
        lbl0 = Label(self.quick_search_fr , text='Available '+parameter , font =('Ink Free',20),bg='#20262E',fg ='#A6D0DD').place(x = 5 , y = 5)
        back_icon = PhotoImage(file='back.png')
        back_bt = Button(self.quick_search_fr ,image = back_icon , bg = '#20262E',activebackground="#20262E",command = back_func )
        back_bt.place (x = 600 , y = 5)
        self.quick_search_scroll_frame = Frame(self.cstroot , bg = '#20262E',height = 575 , width= 800)
        mydb = mysql.connector.connect(host ='localhost', user = 'root' , password = '123456', database = 'Ziggy')
        cur = mydb.cursor()
        sql0 = "SELECT * FROM Menu WHERE dish_type2 = %s"
        cur.execute(sql0,(self.parameter,))
        result0 = cur.fetchall()
        for i,row in enumerate(result0):

            lables_1 = Label(self.quick_search_scroll_frame,fg = '#A6D0DD',bg = '#20262E',text = result0[i][0] ,font = ('Ink Free',15)).place(x = 0,y = i*50)
            lables_2 = Label(self.quick_search_scroll_frame,fg = '#A6D0DD',bg = '#20262E',text = result0[i][1] ,font = ('Ink Free',15)).place(x = 200,y = i*50)
            lables_3 = Label(self.quick_search_scroll_frame,fg = '#A6D0DD',bg = '#20262E',text = result0[i][2] ,font = ('Ink Free',15)).place(x = 400,y = i*50)
            self.order_icon = PhotoImage(file='order.png')
            order_place_bt = Button(self.quick_search_scroll_frame,bg='#20262E',activebackground='#20262E',image=self.order_icon,command = lambda username=un , rstname = result0[i][0],dishname = result0[i][1],price=result0[i][2]:payment_portal(self,username,rstname,dishname,price) )
            order_place_bt.place(x = 600 , y = i*50)

            
        self.quick_search_fr.pack()
        self.quick_search_scroll_frame.pack()
        
        

    # MENUBAR --------------------------------------------------------------------------------------------------------------------------------------

    def __init__(self,un):

        self.cstroot= Tk()
        self.cstroot.title("Customer Profile")
        self.menubar = Menu(self.cstroot)
        self.cstroot.config(menu = self.menubar)
        self.myprofmenu = Menu(self.cstroot,tearoff=0)
        self.myprofmenu.add_command(label='Edit Profile',command=self.cstprof)
        self.myprofmenu.add_command(label='Home' ,command=self.csthome)
        self.myprofmenu.add_command(label = 'Log Out',command= lambda: self.logout(un))
        self.menubar.add_cascade(label='MY PROFILE',menu = self.myprofmenu)
        self.ordersmenu = Menu(self.cstroot,tearoff=0)
        self.ordersmenu.add_command(label = 'Orders',command=self.orders )
        self.ordersmenu.add_command(label='Search' ,command= self.search)

        self.menubar.add_cascade(label='ORDERS', menu = self.ordersmenu)

#QUICK SEARCH---------------------------------------------------------------------------------------------------------------------------------------------
        def quick_search(parameter,un):
            self.cstframe.pack_forget()
            def back_func():
                self.quick_search_fr.pack_forget()
                self.quick_search_scroll_frame.pack_forget()
                self.cstframe.pack()
           
            
            self.quick_search_fr = Frame(self.cstroot , height=50 , width=800,bg='#20262E')
            lbl0 = Label(self.quick_search_fr , text='Available '+parameter , font =('Ink Free',20),bg='#20262E',fg ='#A6D0DD').place(x = 5 , y = 5)
            back_icon = PhotoImage(file='back.png')
            back_bt = Button(self.quick_search_fr ,image = back_icon , bg = '#20262E',activebackground="#20262E",command = back_func )
            back_bt.place (x = 600 , y = 5)

            self.quick_search_scroll_frame = Frame(self.cstroot , bg = '#20262E',height = 575 , width= 800)


            mydb = mysql.connector.connect(host ='localhost', user = 'root' , password = '123456', database = 'Ziggy')
            cur = mydb.cursor()
            sql0 = "SELECT * FROM Menu WHERE dish_type2 = %s"
            cur.execute(sql0,(parameter,))
            result0 = cur.fetchall()

            for i,row in enumerate(result0):

               lables_1 = Label(self.quick_search_scroll_frame,fg = '#A6D0DD',bg = '#20262E',text = result0[i][0] ,font = ('Ink Free',15)).place(x = 0,y = i*50)
               lables_2 = Label(self.quick_search_scroll_frame,fg = '#A6D0DD',bg = '#20262E',text = result0[i][1] ,font = ('Ink Free',15)).place(x = 200,y = i*50)
               lables_3 = Label(self.quick_search_scroll_frame,fg = '#A6D0DD',bg = '#20262E',text = result0[i][2] ,font = ('Ink Free',15)).place(x = 400,y = i*50)
               order_icon = PhotoImage(file='order.png')
               order_place_bt = Button(self.quick_search_scroll_frame,bg='#20262E',activebackground='#20262E',image=order_icon,command = lambda username=un , rstname = result0[i][0],dishname = result0[i][1],price=result0[i][2]:self.payment_portal_function(username,rstname,dishname,price) )
               order_place_bt.place(x = 600 , y = i*50)

            self.quick_search_fr.pack()
            self.quick_search_scroll_frame.pack()
            self.cstroot.mainloop()


        

        
        






        #ORDERS-------------------------------------------------------------------------------------------------------------------
        self.ordersframe = Frame(self.cstroot , height= 600 , width= 800 , bg = '#20262E')
        orderslbl1 = Label(self.ordersframe , text = 'Your orders' ,font=('Arial',20), fg = '#EEEEEE', bg = '#20262E')
        mydb = mysql.connector.connect(host='localhost' , user = 'root', password = '123456' , database = 'Ziggy')
        cur = mydb.cursor()
        sql0 = "SELECT * FROM Orders WHERE username = %s"
        sql00 = (un,)
        cur.execute(sql0,sql00)
        result0 = cur.fetchall()
        for i,row in enumerate (result0):
            for j, column in enumerate (row):
                orders_list1 = Label(self.ordersframe , text = result0[i][1] ,fg='#F1F6F9',bg ='#20262E',font=('Comic Sans MS',15) ).place(x = 10 ,y=(i+1)*50)
                orders_list2 = Label(self.ordersframe , text = result0[i][2] ,fg='#F1F6F9',bg ='#20262E',font=('Comic Sans MS',15) ).place(x = 160 ,y=(i+1)*50)
                orders_list3 = Label(self.ordersframe , text = result0[i][3] ,fg='#F1F6F9',bg ='#20262E',font=('Comic Sans MS',15) ).place(x = 310 ,y=(i+1)*50)
                


        orderslbl1.place(x= 5 , y = 5)
        self.ordersframe.pack_forget()

        #SEARCH-------------------------------------------------------------------------------------------------------------------
        def order_item(dn,rn,pri,un):
            mydb = mysql.connector.connect(host ='localhost', user ='root',password = '123456' ,database ='Ziggy' )
            cur  = mydb.cursor()
            sql20 = "SELECT * FROM Users WHERE username = %s"
            sql202 = (un,)
            cur.execute(sql20,sql202)
            results = cur.fetchone()
            contact_no = results[2]
            address = results[5]

            sql10 = "INSERT INTO Orders (username,dish_name,rst_name,price,address,contact ) VALUES(%s,%s,%s,%s,%s,%s)" 
            sql101 = (un,dn,rn,pri,address,contact_no)
            cur.execute(sql10,sql101)
            mydb.commit()
            alert = Tk()
            def ok():
                alert.destroy()
                self.csthome()
                
            label0 = Label(alert , text = 'Order has been placed !!' , font = ('Roman',20) ).grid(row=0 , column=0)
            ok_bt = Button(alert , text = 'OK' , width = 3 , height=2 , command= ok)
            ok_bt.grid(row = 0 , column= 1)
            alert.mainloop()
            
        def serch_by_rst(un):
            
            search_rst = self.search_bar.get()
            mydb = mysql.connector.connect(host = 'localhost', user='root',password = '123456',database ='Ziggy')
            cur = mydb.cursor()
            sql1 = "SELECT * FROM Menu WHERE name = %s"
            sql11 = (search_rst,)
            cur.execute(sql1,sql11)
            menu = Tk()
            menu_canvas = Canvas(menu ,height=600 ,width=800)
            menu_frame = Frame(menu_canvas,height=600 ,width=800,bg='#20262E')
            rst_menu_rseult = cur.fetchall()
            for i,row in enumerate(rst_menu_rseult):
                for j , column in enumerate(row):
                    lbl_name = Label(menu_frame , text = row [1],font=('Ink Free',15) ,bg='#20262E' , fg ='#E5E0FF' ).place(x = 5 ,y = (i+1)*25)
                    lbl_price = Label(menu_frame , text = row [2],font=('Ink Free',15) ,bg='#20262E' , fg ='#E5E0FF' ).place(x = 100 ,y = (i+1)*25)
                    lbl_type = Label(menu_frame , text = row [3],font=('Ink Free',15) ,bg='#20262E' , fg ='#E5E0FF' ).place(x = 205 ,y = (i+1)*25)

            menu_frame.pack(side=LEFT,fill=BOTH,expand=True)
            menu_canvas.pack(side=LEFT , fill=BOTH,expand=True)
            menu.mainloop()


        def serch_by_food (un):
            self.serch1frame1.pack_forget()
            search_q = self.search_bar.get() 
            mydb = mysql.connector.connect(host='localhost',user='root',password ='123456',database='Ziggy')
            cur = mydb.cursor()
            sql0 = "select * from Menu where dish_name = %s"
            sql00 = (search_q,)
            cur.execute(sql0,sql00)
            self.searchframe.pack()
            self.serch1frame.pack_forget()
            self.serch1frame1 = Frame(self.cstroot , height=430, width=800 , bg='#20262E')
            results_lbl = Label(self.serch1frame1 , text ="Results :" , fg = '#F3DEBA',bg='#20262E' , font=('arial',10))
            result0 = cur.fetchall()
            orders_vars = []
            for i,row in enumerate(result0):
                '''for j,column in enumerate(row):
                    orders_vars.append((row[1],row[0],row[2]))
                    search_result = Label(self.serch1frame1 , font=('Segoe Script', 15), text=row[0], fg='#97DEFF', bg='#20262E')
                    temp_j = 0
                    temp_i = i*50
                    search_result.place(x=temp_j,y=temp_i)
                    dish_name = row[1]
                    restaurant_name = row[0]
                    dish_price = row[2]
                    order_ic = PhotoImage(file='order.png')
                    order_bt = Button(self.serch1frame1 , image= order_ic , bg = '#20262E',activebackground='#20262E',command = lambda idx = i : order_item(*orders_vars[idx],un))
                    order_bt.place(x=600 , y = temp_i)'''


                for j,value in enumerate(row):
                    if(j<3):
                        search_result = Label(self.serch1frame1,font=('Segoe Script',15),text=result0[i][j] , fg='#97DEFF',bg='#20262E')
                        temp_j = j*150
                        temp_i = i*50
                        search_result.place(x = temp_j,y =temp_i)
                        dish_name = row[1]
                        restaurant_name = row[0]
                        dish_price = row[2]
                        order_icon  = PhotoImage(file ='order.png')
                        order_bt = Button(self.serch1frame1, image=order_icon, bg='#20262E', activebackground='#20262E',command=lambda dish_name=row[1], restaurant_name=row[0],price = row[2]: order_item(dish_name, restaurant_name,price,un))
                        order_bt.place(x =600,y = i*50 )
                        results_lbl.place(x = 2 ,y=2)
                        
                    else:
                        pass
                    
                    
                
                
            results_lbl.place(x = 2 ,y=2)
            self.serch1frame1.pack()
            self.cstroot.mainloop()

        def filter_fun(un):
            self.serch1frame.pack_forget()
            self.filtersframe = Frame(self.cstroot , height = 410 , width = 800 , bg='#20262E')
            search_query = self.search_bar.get()
            filter_rst = self.filter_e.get()
            sql1 = "SELECT * FROM Menu WHERE name = %s AND dish_name = %s "
            sql11 = (filter_rst , search_query)
            cur.execute(sql1,sql11)
            result1 = cur.fetchall()
            for i,row in enumerate (result1):
                rstname = result1[0]
                dishname = result1[1]
                price = result1[2]
                filter_result_lbl0 = Label(self.filtersframe , text = result1[0] , font = ('Lucida Handwriting',15),fg='#F0EEED',bg='#26202E').place(x = 5 , y = i*25)
                filter_result_lbl1= Label(self.filtersframe , text = result1[1] , font = ('Lucida Handwriting',15),fg='#F0EEED',bg='#26202E').place(x = 120 , y = i*25)
                filter_result_lbl2= Label(self.filtersframe , text = result1[2] , font = ('Lucida Handwriting',15),fg='#F0EEED',bg='#26202E').place(x = 240 , y = i*25)
                self.order_bt = Button(self.filtersframe , text= 'Order' , image=self.order_icon ,bg='#20262E',activebackground='#20262E',command = lambda :self.payment_portal_function(un,rstname , dishname, price)  )
                self.order_bt.place (x = 360 , y =i*25 )

            self.filtersframe.pack()

        self.searchframe = Frame(self.cstroot , height=190 , width=800 , bg = '#20262E')
        self.seacrhintrolbl = Label(self.searchframe , text = 'Here you can search by your food or hotel.' , fg='#EDF1D6',bg = '#20262E')
        self.search_bar = Entry(self.searchframe, width= 35 , font =('Arial',15),fg='#F0EEED',bg='#26202E')
        self.searby_lbl = Label(self.searchframe ,text = 'Search by ?' , fg='#EDF1D6',bg = '#20262E' )
        food_icon = PhotoImage(file='food.png')
        food = Label(self.searchframe ,text = 'Food' , fg='#EDF1D6',bg = '#20262E' ).place(x = 100 , y = 70)
        restaurent = Label(self.searchframe ,text = 'Restaurent' , fg='#EDF1D6',bg = '#20262E' ).place(x = 180 , y = 70)
        self.searchby_food = Button(self.searchframe , height = 50 , width = 50 ,command= lambda :serch_by_food(un), image = food_icon , bg = '#20262E' , activebackground='#20262E')
        restaurent_icon = PhotoImage(file='restaurant.png')
        self.searchby_restaurent = Button(self.searchframe , height=50 , width=50 ,image=restaurent_icon, bg='#20262E' , activebackground='#20262E',command=lambda :serch_by_rst(un))
        filters0 = Label(self.searchframe,text = "Filter (rst name) :", fg='#EDF1D6',bg = '#20262E').place(x = 450 , y =5)
        self.filter_e = Entry(self.searchframe,width=20 ,  font =('Arial',15),fg='#F0EEED',bg='#26202E')
        self.filters = Button(self.searchframe , text='Apply',fg='#F1F6F9',bg='#20262E' , activebackground='#20262E',activeforeground='#A6D0DD',command=lambda :filter_fun(un))
        self.searchby_restaurent.place(x = 180 , y = 100)
        self.searchby_food.place(x = 100 , y = 100)
        self.searby_lbl.place(x = 20 , y = 100)
        self.search_bar.place(x = 10 , y = 40)
        self.filter_e.place(x =450 , y = 5 )
        self.seacrhintrolbl.place(x = 5 , y =5)
        self.filters.place( x= 450 , y = 100)
        self.searchframe.pack_forget()

        self.serch1frame = Frame(self.cstroot , height=430, width=800 , bg='#20262E')
        
        self.serch1frame.pack_forget()

        self.serch1frame1 = Frame(self.cstroot , height=430, width=800 , bg='#20262E')
        results_lbl = Label(self.serch1frame1 , text ="Results :" , fg = '#F3DEBA',bg='#20262E' , font=('arial',15))
        

        results_lbl.place(x=5 , y = 5)
        self.serch1frame1.pack_forget()

        #CSTPROF-------------------------------------------------------------------------------

        def data_submit():
            n_username = self.username_e.get()
            n_password = self.password_e.get()
            n_repassword = self.re_password_e.get()
            temp = self.contact_e.get()
            n_contact = str(temp)
            n_email = self.email_e.get()
            n_address = self.address_e.get()
            if len(n_username) == 0 and len(n_username) >20 :
                def ok_():
                    self.username_e.delete(0,END)
                    self.ok.destroy()
                ok = Tk()
                lbl = Label(ok,text="Username limit is from 1 to 20").grind(row=0,column = 0)
                ok_bt = Button(ok , text = "ok",command=ok_)

                ok.mainloop()

            elif (n_password != n_repassword):
                def ok_():
                    self.password_e.delete(0,END)
                    self.re_password_e.delete(0,END)
                    self.ok.destroy()
                ok = Tk()
                lbl = Label(ok,text="Passwords don't match").grid(row=0,column = 0)
                ok_bt = Button(ok , text = "ok",command=ok_).grid(row = 1,column =0)

                ok.mainloop()
            elif len(n_contact)<10 and len(n_contact)>11:
                def ok_():
                    self.contact_e.delete(0,END)
                    self.ok.destroy()
                ok = Tk()
                lbl = Label(ok,text="Enter a valid contact number").grid(row=0,column = 0)
                ok_bt = Button(ok , text = "ok",command=ok_).grid(row = 1,column =0)
            elif len(n_address)<0 and len(n_address):
                def ok_():
                    self.address_e.delete(0,END)
                    self.ok.destroy()
                ok = Tk()
                lbl = Label(ok,text="Maximum address length is 200").grid(row=0,column = 0)
                ok_bt = Button(ok , text = "ok",command=ok_).grid(row = 1,column =0)

            else:
                mydb = mysql.connector.connect(host='localhost',user='root',password='123456',database='Ziggy')
                cur = mydb.cursor()
                sql1 = "UPDATE Users SET username = %s , password = %s, contact = %s,email = %s,address =%s WHERE username = %s"
                sql01 = (n_username,n_password,n_contact,n_email,n_address,un)
                cur.execute(sql1,sql01)
                mydb.commit()
                cur.close()
                mydb.close()
                print("UPDATED "+un+"'s data")
                def okbt_ ():
                    self.username_e.delete(0,END)
                    self.password_e.delete(0,END)
                    self.re_password_e.delete(0,END)
                    self.contact_e.delete(0,END)
                    self.address_e.delete(0,END)
                    self.email_e.delete(0,END)
                    done.destroy()
                    self.cstroot.destory()
                    cstpage_c()
                done = Tk()
                created = Label(done,text = 'Changes are made').grid(row=0,column=0)
                okbt = Button(done,text='OK',command = okbt_).grid(row=1,column=0)


                done.mainloop()


            




        
        
        self.cstprof_frame = Frame(self.cstroot , height=600 , width=800 , bg = '#20262E')
        introlabel = Label(self.cstprof_frame , text = 'Here you can edit your profile detials as per your needs .' , font =('Arial', 15), fg='#EDE9D5' , bg = '#20262E')
        username_lbl  = Label(self.cstprof_frame , text = "Username :" , font =('Arial', 15), fg='#FFD966' , bg = '#20262E')
        self.username_e = Entry(self.cstprof_frame , width=20 , bg='#20262E' , fg='#FFD966',font=('Roman',15))
        password_lbl = Label(self.cstprof_frame , text = "Password :" , font =('Arial', 15), fg='#FFD966' , bg = '#20262E')
        re_password_lbl = Label(self.cstprof_frame , text = "Re-Password :" , font =('Arial', 15), fg='#FFD966' , bg = '#20262E')
        contact = Label(self.cstprof_frame , text = "Contact :" , font =('Arial', 15), fg='#FFD966' , bg = '#20262E' )
        email = Label(self.cstprof_frame , text = "Email :" , font =('Arial', 15), fg='#FFD966' , bg = '#20262E' )
        address = Label(self.cstprof_frame , text = "Address :" , font =('Arial', 15), fg='#FFD966' , bg = '#20262E' )
        self.password_e = Entry(self.cstprof_frame , width=20 , font = ('Arial',15) , fg = '#FFD966' , bg = '#20262E' ,show ='*')
        self.re_password_e = Entry(self.cstprof_frame , width=20 , font = ('Arial',15) , fg = '#FFD966' , bg = '#20262E' ,show ='*')
        self.contact_e =  Entry(self.cstprof_frame , width=20 , font = ('Arial',15) , fg = '#FFD966' , bg = '#20262E' )
        self.email_e = Entry(self.cstprof_frame , width=20 , font = ('Arial',15) , fg = '#FFD966' , bg = '#20262E' )
        self.address_e = Entry (self.cstprof_frame , width=20 , font = ('Arial',15) , fg ='#FFD966' , bg = '#20262E'  )
        submit_icon = PhotoImage(file='submit.png')
        self.submit_bt = Button (self.cstprof_frame ,image= submit_icon , activebackground='#20262E',fg = '#20262E', command = data_submit)

        self.submit_bt.place(x=50,y= 250)
        self.address_e.place(x = 200 , y = 200)
        self.email_e.place(x =200 , y = 170)
        self.contact_e.place(x = 200 ,y  = 140)
        self.re_password_e.place(x = 200 , y=110)
        self.password_e.place(x = 200 , y =80)
        address.place(x =10 , y = 200)
        email.place(x = 10 , y = 170)
        contact.place(x = 10 , y = 140)
        re_password_lbl.place(x = 10 , y = 110)
        password_lbl.place(x=10 , y=80)
        self.username_e.place(x = 200 , y = 50)
        introlabel.place(x = 5 , y = 5)
        username_lbl.place(x = 10 , y = 50)
        self.cstprof_frame.pack_forget()


        #CST HOME PAGE -------------------------------------------------------------------------------------------------------------------------

        




        self.cstframe = Frame(self.cstroot , height = 600 , width = 800, bg ='#20262E')
        self.welcome_lbl = Label(self.cstframe , text = "Welcome "+un+"!!" , fg = '#FF8B13' , bg = '#20262E',font = ('Arial',20))
        self.suggestions_lbl = Label(self.cstframe , text = "Suggestions" , bg = '#20262E' , fg="#EEEEEE", font=('Arial',20))
        self.desserts_lbl = Label(self.cstframe , text = "Desserts" , fg = "#FFBF9B" , bg = '#20262E',font = ('Roman',15))
        icecreame_icon = PhotoImage(file='ice-cream.png')
        self.icecream = Button(self.cstframe ,height=20,width=50, bg = '#20262E',image = icecreame_icon, activebackground='#20262E',command=lambda parameter='icecream':quick_search(parameter,un) )
        cake_icon = PhotoImage(file='cake-slice.png')
        self.cake = Button(self.cstframe ,height=20,width=50, bg = '#20262E',image = cake_icon, activebackground='#20262E',command=lambda parameter='cake':quick_search(parameter,un))
        indian_icon = PhotoImage(file='gulab-jamun.png')
        self.indian_dessert = Button(self.cstframe ,height=20,width=50, bg = '#20262E',image = indian_icon, activebackground='#20262E',command=lambda parameter='gulabjamun':quick_search(parameter,un))
        waffles_icon = PhotoImage(file='waffles.png')
        self.waffles = Button(self.cstframe ,height=20,width=50, bg = '#20262E',image = waffles_icon, activebackground='#20262E',command=lambda parameter='waffles':quick_search(parameter,un))
        pancakes_icon = PhotoImage(file='pancakes.png')
        self.pancakes = Button(self.cstframe ,height=20,width=50, bg = '#20262E',image = pancakes_icon, activebackground='#20262E',command=lambda parameter='pancakes':quick_search(parameter,un))
        self.appetisers_lbl =Label(self.cstframe , text = "Appetisers" ,  fg = "#ABC270" , bg = '#20262E',font = ('Roman',15))
        salad_icon = PhotoImage(file='salad.png')
        self.salad = Button(self.cstframe ,height=27,width=50, bg = '#20262E',image = salad_icon, activebackground='#20262E',command=lambda parameter='salad':quick_search(parameter,un))
        bread_icon = PhotoImage(file='bread.png')
        self.bread = Button(self.cstframe ,height=27,width=50, bg = '#20262E',image = bread_icon, activebackground='#20262E',command=lambda parameter='bread':quick_search(parameter,un))
        chinese_icon = PhotoImage(file='chinese.png')
        self.chinese = Button(self.cstframe ,height=27,width=50, bg = '#20262E',image = chinese_icon, activebackground='#20262E',command=lambda parameter='chinese':quick_search(parameter,un))
        papad_icon = PhotoImage(file='papad.png')
        self.indian_appetisers = Button(self.cstframe ,height=27,width=50, bg = '#20262E',image = papad_icon, activebackground='#20262E',command=lambda parameter='gulab-jamun':quick_search(parameter,un))
        self.maincourse_lbl = Label (self.cstframe , text = 'Main Course' , font=('Roman',15),fg = '#0E8388' , bg='#20262E')
        thali_icon =  PhotoImage(file = 'thali.png' )
        self.thali_bt = Button(self.cstframe ,height=50,width=50, bg = '#20262E',image = thali_icon, activebackground='#20262E' ,command=lambda parameter='thali':quick_search(parameter,un))
        biryani_icon  = PhotoImage(file = 'biryani.png')
        self.biryani_bt = Button(self.cstframe , height = 50 , width = 50 , bg = '#20262E',image = biryani_icon, activebackground='#20262E',command=lambda parameter='biriyani':quick_search(parameter,un))
        pizza_icon = PhotoImage(file = 'pizza.png')
        self.pizza_bt = Button(self.cstframe ,height=50,width=50, bg = '#20262E',image = pizza_icon, activebackground='#20262E',command=lambda parameter='pizza':quick_search(parameter,un) )
        icecream = Label(self.cstframe , text = 'Icecream' ,  bg = '#20262E',fg='#FFD3B0' , font = ('Arial',10)).place (x=15 ,y=150) 
        cake = Label(self.cstframe , text = 'Cake' ,  bg = '#20262E',fg='#FFD3B0' , font = ('Arial',10)).place(x=90,y = 150)
        indian_dessert = Label(self.cstframe , text = 'Indian Dessert' ,  bg = '#20262E',fg='#FFD3B0' , font = ('Arial',10)).place(x=115,y = 150)
        waffles = Label(self.cstframe , text = 'Waffles' ,  bg = '#20262E',fg='#FFD3B0' , font = ('Arial',10)).place(x=220,y = 150)
        pancakes = Label(self.cstframe , text = 'Pancakes' ,  bg = '#20262E',fg='#FFD3B0' , font = ('Arial',10)).place(x=285,y = 150)
        salad = Label(self.cstframe , text='Salad',  bg = '#20262E',fg='#FFD3B0' , font = ('Arial',10)).place(x = 25,y = 260)
        Bread = Label(self.cstframe , text='Bread',  bg = '#20262E',fg='#FFD3B0' , font = ('Arial',10)).place(x = 105,y = 260)
        Chinese = Label(self.cstframe , text='Chinese',  bg = '#20262E',fg='#FFD3B0' , font = ('Arial',10)).place(x = 185,y = 260)
        Indian = Label(self.cstframe , text='Indian',  bg = '#20262E',fg='#FFD3B0' , font = ('Arial',10)).place(x = 265,y = 260)
        Thali = Label(self.cstframe , text='Thali',  bg = '#20262E',fg='#FFD3B0' , font = ('Arial',10)).place(x = 25,y = 370)
        Biriyani = Label(self.cstframe , text='Biriyani',  bg = '#20262E',fg='#FFD3B0' , font = ('Arial',10)).place(x = 90,y = 370)
        Pizza = Label(self.cstframe , text='Pizza',  bg = '#20262E',fg='#FFD3B0' , font = ('Arial',10)).place(x = 130,y = 370)



        self.pizza_bt.place(x = 155,y=320)
        self.biryani_bt.place(x = 90 , y = 320)
        self.thali_bt.place(x = 25 , y  = 320)
        self.maincourse_lbl.place(x = 15,y = 280 )
        self.indian_appetisers.place(x = 265, y =220)
        self.chinese.place(x = 185,y = 220)
        self.bread.place(x = 105 , y = 220)
        self.salad.place(x = 25 , y =220 )
        self.appetisers_lbl.place(x = 15 , y = 180)
        self.pancakes.place (x = 285 , y= 120)
        self.waffles.place(x = 220 , y = 120)
        self.indian_dessert.place(x=155 , y =120)
        self.cake.place(x = 90 , y = 120)
        self.icecream.place(x = 25 , y = 120)
        self.desserts_lbl.place(x = 15 , y = 90)
        self.suggestions_lbl.place(x = 10 , y = 40)
        self.welcome_lbl.place(x=5 , y = 5)
        
        self.cstframe.pack()

        self.cstroot.mainloop()

