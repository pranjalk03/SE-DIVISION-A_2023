import tkinter as tk
from tkinter import *
from tkinter import ttk
import customtkinter
import tkinter
#from customtkinter import CTk, CFrame, CCheckbutton, CButton, BooleanVar
import random

customtkinter.set_appearance_mode("system")  # Modes: system (default), light, dark
customtkinter.set_default_color_theme("blue")  # Themes: blue (default), dark-blue, green

class Register(ttk.Frame):
    def __init__(self, root):
        ttk.Frame.__init__(self)
        self.root=root
        self.widgets_frame = ttk.Frame(self.root)
        self.root.geometry("1300x700+0+0")
        self.root.title("Tauqir - Momin")
        self.root.resizable(False,False)

        def toggle_checkbutton():
            # Enable or disable the checkbutton based on the checkbox state
            if check_box_var.get():
                button1.configure(state="normal")
            else:
                button1.configure(state="disabled")
        
        #creating whole custom
        frame1=customtkinter.CTkFrame(self, width=1300, height=710,fg_color="#F4EEE0")
        frame1.place(relx=0.5, rely=0.5, anchor=CENTER)


        #creating custom frame
        frame2=customtkinter.CTkFrame(self, width=500, height=500, corner_radius=15)
        frame2.place(relx=0.5, rely=0.5, anchor=CENTER)

        l1=customtkinter.CTkLabel(master=frame2, text="Billing Managment App",font=("SF Pro Display",30,"bold"))
        l1.place(x=85, y=74)

        l2=customtkinter.CTkLabel(master=frame2, text="Employee Registeration",font=("SF Pro Display",20,"bold"))
        l2.place(x=140, y=119)

        entry1=customtkinter.CTkEntry(master=frame2, width=300,height=30, placeholder_text='Name')
        entry1.place(x=93, y=165)

        entry2=customtkinter.CTkEntry(master=frame2, width=300,height=30, placeholder_text='Username')
        entry2.place(x=93, y=208)

        entry3=customtkinter.CTkEntry(master=frame2, width=300,height=30, placeholder_text='Email')
        entry3.place(x=93, y=251)

        entry4=customtkinter.CTkEntry(master=frame2, width=300,height=30, placeholder_text='Password', show="*")
        entry4.place(x=93, y=294)
        
        #check button
        check_box_var = BooleanVar()
        check_box = customtkinter.CTkCheckBox(master=frame2, text="I agree to the terms and conditions", variable= check_box_var, command=toggle_checkbutton)
        check_box.place(x=93, y=333)
        
        #Create custom button
        button1 = customtkinter.CTkButton(master=frame2, width=210, text="Register",  state="disabled",corner_radius=6)
        button1.place(x=140, y=365)

         

        

        




        




















        

if __name__ == "__main__":
    root = tk.Tk()

    # Create and pack Login frame
    app = Register(root)
    app.pack(fill="both", expand=True)

    # Set a minsize for the window, and place it in the middle
    root.update()
    root.minsize(root.winfo_width(), root.winfo_height())
    x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
    y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
    root.geometry("+{}+{}".format(x_cordinate, y_cordinate))

    root.mainloop()