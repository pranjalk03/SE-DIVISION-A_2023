
import tkinter as tk
from tkinter import *
from tkinter import ttk
import random

class App(ttk.Frame):
    def __init__(self, root):
        ttk.Frame.__init__(self)
        self.root=root
         # Create the widgets frame
        self.widgets_frame = ttk.Frame(self.root)
                  
    
        self.root.geometry("1300x700+0+0")
        self.root.title("Tauqir - Momin")
        
        # System Settings
        #customtkinter.set_appearance_mode("System")
        #customtkinter.set_default_color_theme("blue")

        # Variables
        self.cus_name = StringVar()
        self.c_phone = StringVar()

        # For Generating Random Bill Numbers
        x = random.randint(1000,9999)
        self.c_bill_no = StringVar()

        # Seting Value to variable
        self.c_bill_no.set(str(x))
        self.bath_soap = IntVar()
        self.face_cream = IntVar()
        self.face_wash = IntVar()
        self.hair_spray = IntVar()
        self.body_lotion = IntVar()
        self.rice = IntVar()
        self.daal = IntVar()
        self.food_oil = IntVar()
        self.wheat = IntVar()
        self.sugar = IntVar()
        self.maza = IntVar()
        self.coke = IntVar()
        self.frooti = IntVar()
        self.nimko = IntVar()
        self.biscuits = IntVar()
        self.total_cosmetics = StringVar()
        self.total_grocery = StringVar()
        self.total_other = StringVar()
        self.gst_all = StringVar()
        self.bath_color = StringVar()
        menu = StringVar()
        soap_list = StringVar()
        facecream_list = StringVar()
        facewash_list = StringVar()
        spray_list = StringVar()
        bodylotion_list = StringVar()
        rice_list = StringVar()
        foodoil_list = StringVar()
        daal_list = StringVar()
        wheat_list = StringVar()
        sugar_list = StringVar()
        #style = ttk.Style()
        #style.configure('TEntry', background='#D3D3D3')

        #self.tax_groc = StringVar()
        #self.tax_other = StringVar()
        
        

        #===================================
        bg_color = "#2d0b00"
        fg_color = "black"
        lbl_color = 'white'

        #Title of App
        title =Label(self,text = "Billing Software",justify="center", font=("SF Pro Display",30,"bold"),pady = 3)
        title.pack(fill = X)

        # Customers Frame
        F1 = ttk.LabelFrame(text = "Customer Details")
        F1.place(x = 0,y = 80,relwidth = 1)

        # Customer Name
        cname_lbl = Label(F1,text="Customer Name",fg = fg_color,font=("SF Pro Display",15,"bold")).grid(row = 0,column = 0,padx = 10,pady = 5)
        cname_en = ttk.Entry(F1,textvariable = self.cus_name)
        cname_en.grid(row = 0,column = 1,ipady = 4,ipadx = 30,pady = 5)

        # Customer Phone
        cphon_lbl = Label(F1,text = "Phone No",fg = fg_color,font = ("SF Pro Display",15,"bold")).grid(row = 0,column = 2,padx = 20)        
        cphon_en = ttk.Entry(F1,textvariable = self.c_phone)
        cphon_en.grid(row = 0,column = 3,ipady = 4,ipadx = 30,pady = 5)

        # Customer Bill No
        cbill_lbl = Label(F1,text = "Bill No.",fg = fg_color,font = ("SF Pro Display",15,"bold"))
        cbill_lbl.grid(row = 0,column = 4,padx = 20)
        cbill_en = ttk.Entry(F1,textvariable = self.c_bill_no)
        cbill_en.grid(row = 0,column = 5,ipadx = 30,ipady = 4,pady = 5)

        # Bill Search Button
        self.accentbutton = ttk.Button(F1, text="Enter", style="Accent.TButton")
        self.accentbutton.grid(row=0, column=6, ipady=5, padx=60, ipadx=19, pady=1)
        self.accentbutton.configure(style="BlueAccent.TButton")


        # Cosmetics Frame
        F2 = ttk.LabelFrame(self,text = 'Cosmetics')
        F2.place(x = 5,y = 180,width = 325,height = 380)

        # Frame Content--- Bathing Soap
        bath_lbl = Label(F2,font = ("SF Pro Display",15),fg = fg_color,text = "Bath-Soap")
        bath_lbl.grid(row = 0,column = 0,padx = 10,pady = 20)
        mycombobox = ttk.Combobox(F2, values=soap_list)
        mycombobox['values'] = ['SELECT',"LUX","NO.1","DETOL","LIFEBOY","DOVE","MEDIMIX","MOTI","SANTOOR","Cinthol"]
        mycombobox.grid(row=0, column=1, ipady=5, ipadx=5)
        mycombobox.current()

        # Face Cream
        face_lbl = Label(F2,font = ("SF Pro Display",15),fg = fg_color,text = "Hand Wash")
        face_lbl.grid(row = 1,column = 0,padx = 10,pady = 20)
        mycombo = ttk.Combobox(F2, textvariable=facecream_list)
        mycombo['values'] = ['SELECT', "HIMALAYA", "MAMAEARTH", "WOW","SEVELON","Nivea Cream","Olay Cream","Neutrogena Oil-Free Moisture","L'Oreal Paris Cream"]
        mycombo.grid(row=1, column=1,ipady=5,ipadx=5)
        mycombo.current(0)

        # Face Wash
        wash_lbl = Label(F2,font = ("SF Pro Display",15),fg = fg_color,text = "Face Wash")
        wash_lbl.grid(row = 2,column = 0,padx = 10,pady = 20)
        mycombo = ttk.Combobox(F2, textvariable=facewash_list)
        mycombo['values'] = ['SELECT', "HIMALAYA", "MAMAEARTH", "WOW","Nivea","Prolixr","Man-Matters","Garnier Face wash",]
        mycombo.grid(row = 2, column = 1,ipady = 5,ipadx = 5)
        mycombo.current(0)
    
    
        # Hand wash
        hair_lbl = Label(F2,font = ("SF Pro Display",15),fg = fg_color,text = "Hand Wash")
        hair_lbl.grid(row = 3,column = 0,padx = 10,pady = 20)
        mycombo = ttk.Combobox(F2, textvariable=spray_list,background="#000")
        mycombo['values'] = ['SELECT', "Detole", "Dove", "Fem","Godrej","Nutriglow","palm oliv"]
        mycombo.grid(row = 3, column = 1,ipady = 5,ipadx = 5)
        mycombo.current(0)

        #============Body lotion
        lot_lbl = Label(F2,font = ("SF Pro Display",15),fg = fg_color,text = "Body Lotion")
        lot_lbl.grid(row = 4,column = 0,padx = 10,pady = 20)
        mycombo = ttk.Combobox(F2, textvariable=bodylotion_list,background="#000")
        mycombo['values'] = ['SELECT', "Clinique", "Albabotanic", "Serave","Origins","Aveda","cetaphil"]
        mycombo.grid(row = 4, column = 1,ipady = 5,ipadx = 5)
        mycombo.current(0)

        

         #==================Grocery Frame=====================#
        F2 = ttk.LabelFrame(self,text = 'Grocery')
        F2.place(x = 330,y = 180,width = 325,height = 380)

        #===========Frame Content
        rice_lbl = Label(F2,font = ("SF Pro Display",15),text = "Rice")
        rice_lbl.grid(row = 0,column = 0,padx = 10,pady = 20)
        mycombo = ttk.Combobox(F2, textvariable=rice_list,background="#000")
        mycombo['values'] = ['SELECT', "Basmati", "Arborio", "Jasmine","Brown","Black","Sushi","India Gate Basmati Rice","Daawat Basmati Rice"]
        mycombo.grid(row = 0, column = 1,ipady = 5,ipadx = 5)
        mycombo.current(0)

         #=======
        oil_lbl = Label(F2,font = ("SF Pro Display",15),text = "Food Oil")
        oil_lbl.grid(row = 1,column = 0,padx = 10,pady = 20)
        mycombo = ttk.Combobox(F2, textvariable=foodoil_list,background="#000")
        mycombo['values'] = ['SELECT', "Fortune Oil", "Saffola Oil", "Sundrop Oil","Dhara Oil","Emami Healthy & Tasty Oil","Patanjali Oil","Gemini Oil","Nutrela Oil"]
        mycombo.grid(row = 1, column = 1,ipady = 5,ipadx = 5)
        mycombo.current(0)

         #=======
        daal_lbl = Label(F2,font = ("SF Pro Display",15),text = "Daal")
        daal_lbl.grid(row = 2,column = 0,padx = 10,pady = 20)
        mycombo = ttk.Combobox(F2, textvariable=daal_list,background="#000")
        mycombo['values'] = ['SELECT', "Toor daal (Mother's Recipe)", "Chana daal (Rajdhani)", "Moong daal (Patanjali)","Urad daal","Masoor daal","Kabuli chana","Green moong daal","Masoor whole"]
        mycombo.grid(row = 2, column = 1,ipady = 5,ipadx = 5)
        mycombo.current(0)

        #========
        wheat_lbl = Label(F2,font = ("SF Pro Display",15),text = "Wheat")
        wheat_lbl.grid(row = 3,column = 0,padx = 10,pady = 20)
        mycombo = ttk.Combobox(F2, textvariable=wheat_list,background="#000")
        mycombo['values'] = ['SELECT', "Sharbati wheat", "Durum wheat", "Whole wheat flour","Multigrain atta","Spelt wheat","Pearl millet flour","Sorghum flour"]
        mycombo.grid(row = 3, column = 1,ipady = 5,ipadx = 5)
        mycombo.current(0)

        #============
        sugar_lbl = Label(F2,font = ("SF Pro Display",15),text = "Groceries")
        sugar_lbl.grid(row = 4,column = 0,padx = 10,pady = 20)
        mycombo = ttk.Combobox(F2, textvariable=sugar_list,background="#000")
        mycombo['values'] = ['SELECT', "Bread","Milk","Eggs","Cheese","Butter","Yogurt","Fresh","vegetables" ]
        mycombo.grid(row = 4, column = 1,ipady = 5,ipadx = 5)
        mycombo.current(0)

        #---other stuff
        F2 = ttk.LabelFrame(self,text = 'Others')
        F2.place(x = 655,y = 180,width = 325,height = 380)

        #===========Frame Content
        maza_lbl = Label(F2,font = ("SF Pro Display",15),text = "Coldrinks")
        maza_lbl.grid(row = 0,column = 0,padx = 10,pady = 20)
        mycombo = ttk.Combobox(F2, textvariable=sugar_list,background="#000")
        mycombo['values'] = ['SELECT', "Coca-Cola","Pepsi","Sprite","Fanta","Mountain Dew","7-Up","Dr. Pepper","Ginger Ale","Schweppes Tonic Water","Red Bull","Monster Energy","Gatorade","Powerade","Vitaminwater","Rockstar Energy","Arizona Iced Tea","Snapple","Minute Maid","Welch's Grape Soda"]
        mycombo.grid(row = 0, column = 1,ipady = 5,ipadx = 5)
        mycombo.current(0)

         #=======
        cock_lbl = Label(F2,font = ("SF Pro Display",15),text = "Coke")
        cock_lbl.grid(row = 1,column = 0,padx = 10,pady = 20)
        mycombo = ttk.Combobox(F2, textvariable=sugar_list,background="#000")
        mycombo['values'] = ['SELECT', "Ols", "BAA", "OIU"]
        mycombo.grid(row = 1, column = 1,ipady = 5,ipadx = 5)
        mycombo.current(0)

         #=======
        frooti_lbl = Label(F2,font = ("SF Pro Display",15),text = "Frooti")
        frooti_lbl.grid(row = 2,column = 0,padx = 10,pady = 20)
        mycombo = ttk.Combobox(F2, textvariable=sugar_list,background="#000")
        mycombo['values'] = ['SELECT', "Ols", "BAA", "OIU"]
        mycombo.grid(row = 2, column = 1,ipady = 5,ipadx = 5)
        mycombo.current(0)

        #========
        cold_lbl = Label(F2,font = ("SF Pro Display",15),text = "Nimkos")
        cold_lbl.grid(row = 3,column = 0,padx = 10,pady = 20)
        mycombo = ttk.Combobox(F2, textvariable=sugar_list,background="#000")
        mycombo['values'] = ['SELECT', "Ols", "BAA", "OIU"]
        mycombo.grid(row = 3, column = 1,ipady = 5,ipadx = 5)
        mycombo.current(0)

        #============
        bis_lbl = ttk.Label(F2,font = ("SF Pro Display",15),text = "Biscuits")
        bis_lbl.grid(row = 4,column = 0,padx = 10,pady = 20)
        mycombo = ttk.Combobox(F2, textvariable=sugar_list,background="#000")
        mycombo['values'] = ['SELECT', "Ols", "BAA", "OIU"]
        mycombo.grid(row = 4, column = 1,ipady = 5,ipadx = 5)
        mycombo.current(0)

        #===================Bill Aera================#
        F3 = ttk.Label(self.root)
        F3.place(x = 960,y = 180,width = 325,height = 380)
        #===========
        bill_title = ttk.Label(F3,text = "Bill Area",font = ("Lucida",13,"bold"))
        bill_title.pack(fill = X)

        #---------------------
        scroll_y = Scrollbar(F3,orient = VERTICAL)
        self.txt = Text(F3,yscrollcommand = scroll_y.set)
        scroll_y.pack(side = RIGHT,fill = Y)
        scroll_y.config(command = self.txt.yview)
        self.txt.pack(fill = BOTH,expand = 1)

         #===========Buttons Frame=============#
        F4 = ttk.LabelFrame(self,text = 'Bill Menu')
        F4.place(x = 0,y = 560,relwidth = 1,height = 145)

        #===================
        cosm_lbl = ttk.Label(F4,font = ("SF Pro Display",15),text = "Total Cosmetics")
        cosm_lbl.grid(row = 0,column = 0,padx = 10,pady = 0)
        cosm_en = ttk.Entry(F4,textvariable = self.total_cosmetics)
        cosm_en.grid(row = 0,column = 1,ipady = 2,ipadx = 5)

        #===================
        gro_lbl = ttk.Label(F4,font = ("SF Pro Display",15),text = "Total Grocery")
        gro_lbl.grid(row = 1,column = 0,padx = 10,pady = 5)
        gro_en = ttk.Entry(F4,textvariable = self.total_grocery)
        gro_en.grid(row = 1,column = 1,ipady = 2,ipadx = 5)

        #================
        oth_lbl = ttk.Label(F4,font = ("SF Pro Display",15),text = "Others Total")
        oth_lbl.grid(row = 2,column = 0,padx = 10,pady = 5)
        oth_en = ttk.Entry(F4,textvariable = self.total_other)
        oth_en.grid(row = 2,column = 1,ipady = 2,ipadx = 5)

        #================
        cosmt_lbl = ttk.Label(F4,font = ("SF Pro Display",15),text = "GST")
        cosmt_lbl.grid(row = 0,column = 2,padx = 30,pady = 0)
        cosmt_en = ttk.Entry(F4,textvariable = self.gst_all)
        cosmt_en.grid(row = 0,column = 3,ipady = 2,ipadx = 5)

         #====================
        total_btn = ttk.Button(F4,text="Total", command=self.total, style="ACcent.TButton")
        total_btn.grid(row = 1,column = 4,ipadx = 20,padx = 30,ipady=3)

        #========================
        genbill_btn = ttk.Button(F4,text = "Generate Bill",command = self.bill_area, style="Accent.TButton")
        genbill_btn.grid(row = 1,column = 5,ipadx = 20,ipady=3)

        #====================
        clear_btn = ttk.Button(F4,text = "Clear",command = self.clear, style="Accent.TButton")
        clear_btn.grid(row = 1,column = 6,ipadx = 20,padx = 30,ipady=3)

        self.accentbutton = ttk.Button(
        self.widgets_frame, text="Exit", command=self.exit, style="Accent.TButton"
        )
        self.accentbutton.grid(row=1, column=7, ipadx=20, ipady=3)

         
    
    #Function to get total prices
    def total(self):
    #==============Total Cosmetics Prices
        self.total_cosmetics_prices = (
        (self.bath_soap.get() == "Lux") * 40 +
        (self.face_cream.get()  == "HIMALAYA") * 140 +
        (self.face_wash.get()  == "WOW") * 240 +
        (self.hair_spray.get()  == "Fem") * 340 +
        (self.body_lotion.get()  == "Aveda") * 260
        )
        self.total_cosmetics.set("Rs. "+str(self.total_cosmetics_prices))
        #====================Total Grocery Prices
        self.total_grocery_prices = (
            (self.wheat.get()*100)+
            (self.food_oil.get() * 180)+
            (self.daal.get() * 80)+
            (self.rice.get() *80)+
            (self.sugar.get() * 170)
        )
        self.total_grocery.set("Rs. "+str(self.total_grocery_prices))
        #======================Total Other Prices
        self.total_other_prices = (
            (self.maza.get() * 20)+
            (self.frooti.get() * 50)+
            (self.coke.get() * 60)+
            (self.nimko.get() * 20)+
            (self.biscuits.get() * 20)
        )
        self.total_other.set("Rs. "+str(self.total_other_prices))
        self.gst_all.set("Rs. "+str(round(self.total_cosmetics_prices+self.total_grocery_prices+self.total_other_prices*18)/100))

        # create a function to calculate total price
        
    
    #Function For Text Area
    def welcome_soft(self):
        self.txt.delete('1.0',END)
        self.txt.insert(END,"       Welcome To TM's Retail\n")
        self.txt.insert(END,f"\nBill No. : {str(self.c_bill_no.get())}")
        self.txt.insert(END,f"\nCustomer Name : {str(self.cus_name.get())}")
        self.txt.insert(END,f"\nPhone No. : {str(self.c_phone.get())}")
        self.txt.insert(END,"\n======================================")
        self.txt.insert(END,"\nProduct          Qty         Price")
        self.txt.insert(END,"\n======================================")
        
    #Function to clear the bill area
    def clear(self):
        self.txt.delete('1.0',END)

    #Add Product name , qty and price to bill area
    def bill_area(self):
        self.welcome_soft()
        if self.bath_soap.get() != 0:
            self.txt.insert(END,f"\nBath Soap         {self.bath_soap.get()}           {self.bath_soap.get() * 40}")
        if self.face_cream.get() != 0:
            self.txt.insert(END,f"\nFace Cream        {self.face_cream.get()}           {self.face_cream.get() * 140}")
        if self.face_wash.get() != 0:
            self.txt.insert(END,f"\nFace Wash         {self.face_wash.get()}           {self.face_wash.get() * 240}")
        if self.hair_spray.get() != 0:
            self.txt.insert(END,f"\nHair Spray        {self.hair_spray.get()}           {self.hair_spray.get() * 340}")
        if self.body_lotion.get() != 0 :
            self.txt.insert(END,f"\nBody Lotion       {self.body_lotion.get()}           {self.body_lotion.get() * 260}")
        if self.wheat.get() != 0:
            self.txt.insert(END,f"\nWheat             {self.wheat.get()}           {self.wheat.get() * 100}")
        if self.food_oil.get() != 0:
            self.txt.insert(END,f"\nFood Oil          {self.food_oil.get()}           {self.food_oil.get() * 180}")
        if self.daal.get() != 0:
            self.txt.insert(END,f"\nDaal              {self.daal.get()}           {self.daal.get() * 80}")
        if self.rice.get() != 0:
            self.txt.insert(END,f"\nRice              {self.rice.get()}           {self.rice.get() * 80}")
        if self.sugar.get() != 0:
            self.txt.insert(END,f"\nSugar             {self.sugar.get()}           {self.sugar.get() * 170}")
        if self.maza.get() != 0:
            self.txt.insert(END,f"\nMaza              {self.maza.get()}           {self.maza.get() * 20}")
        if self.frooti.get() != 0:
            self.txt.insert(END,f"\nFrooti            {self.frooti.get()}           {self.frooti.get() * 50}")
        if self.coke.get() != 0:
            self.txt.insert(END,f"\nCoke              {self.coke.get()}           {self.coke.get() * 60}")
        if self.nimko.get() != 0:
            self.txt.insert(END,f"\nNimko             {self.nimko.get()}           {self.nimko.get() * 20}")
        if self.biscuits.get() != 0:
            self.txt.insert(END,f"\nBiscuits          {self.biscuits.get()}           {self.biscuits.get() * 20}")
        self.txt.insert(END,"\n======================================")
        #self.txt.insert(END,f"\n                      Total : {self.total_cosmetics_prices+self.total_grocery_prices+(self.total_other_prices*18)/100}")
        total_cost = self.total_cosmetics_prices + self.total_grocery_prices + self.total_other_prices
        gst = (total_cost * 18) / 100
        total_with_gst = total_cost + gst
        self.txt.insert(END,f"\n                    Total : {total_cost}")
        self.txt.insert(END,f"\n                    GST : {gst}")
        self.txt.insert(END,"\n===================================")
        self.txt.insert(END,f"\n                    Total : {total_with_gst}")

#Function to exit
    def exit(self):
        self.root.destroy()
   
    
    
if __name__ == "__main__":
    root = tk.Tk()
    root.title("")

    


    app = App(root)
    app.pack(fill="both", expand=True)

    # Set a minsize for the selfdow, and place it in the middle
    root.update()
    root.minsize(root.winfo_width(), root.winfo_height())
    x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
    y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
    root.geometry("+{}+{}".format(x_cordinate, y_cordinate-20))

    
    root.mainloop()



     #Creater a Frame for the Radiobuttons
    #self.radio_frame = ttk.LabelFrame(self, text="Radiobuttons", padding=(20, 10))
    #self.radio_frame.grid(row=0, column=1, padx=(20, 10), pady=10, sticky="nsew")