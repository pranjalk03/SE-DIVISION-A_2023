import tkinter as tk
from tkinter import ttk

class LoginWindow:
    def __init__(self, master):
        self.master = master
        self.master.title("Login")
        self.master.configure(background="white")

        # create login label
        self.login_label = ttk.Label(
            self.master,
            text="Login",
            font=("Helvetica", 18),
            background="white",
            padding=20
        )
        self.login_label.grid(column=0, row=0, columnspan=2)

        # create username label and entry
        self.username_label = ttk.Label(
            self.master,
            text="Username",
            font=("Helvetica", 12),
            background="white",
            padding=10
        )
        self.username_label.grid(column=0, row=1, padx=10, pady=10)
        self.username_entry = ttk.Entry(self.master)
        self.username_entry.grid(column=1, row=1, padx=10, pady=10)

        # create password label and entry
        self.password_label = ttk.Label(
            self.master,
            text="Password",
            font=("Helvetica", 12),
            background="white",
            padding=10
        )
        self.password_label.grid(column=0, row=2, padx=10, pady=10)
        self.password_entry = ttk.Entry(self.master, show="*")
        self.password_entry.grid(column=1, row=2, padx=10, pady=10)

        # create login button
        self.login_button = ttk.Button(
            self.master,
            text="Login",
            style="Accent.TButton"
        )
        self.login_button.grid(column=0, row=3, columnspan=2, padx=10, pady=10)

# create root window and start program
root = tk.Tk()
root.geometry("600x400+0+0")
root.configure(background="white")
login_window = LoginWindow(root)
root.mainloop()
