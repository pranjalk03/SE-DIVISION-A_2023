import tkinter as tk
from tkinter import *
from tkinter import ttk
import customtkinter
import random

customtkinter.set_appearance_mode("system")  # Modes: system (default), light, dark
customtkinter.set_default_color_theme("blue")  # Themes: blue (default), dark-blue, green

class ALogin(ttk.Frame):
    def __init__(self, root):
        ttk.Frame.__init__(self)
        self.root=root
        self.widgets_frame = ttk.Frame(self.root)
        self.root.geometry("1300x700+0+0")
        self.root.title("Tauqir - Momin")
        self.root.resizable(False,False)
        self.tk.call('tk', 'scaling', 2.0)
        

        #variables
        self.namevalue = StringVar()
        self.phonevalue = StringVar()

        #Title of Login page
        #title = ttk.Label(self, text="Billing Managment App",font=("SF Pro Display",30,"bold"))
        #title.pack(pady=50)
        #creating custom frame
        frame1=customtkinter.CTkFrame(self, width=1300, height=710, corner_radius=15,fg_color="#F4EEE0")
        frame1.place(relx=0.5, rely=0.5, anchor=CENTER)

        #creating custom frame
        frame2=customtkinter.CTkFrame(self, width=500, height=500, corner_radius=15)
        frame2.place(relx=0.5, rely=0.5, anchor=CENTER)

        l1=customtkinter.CTkLabel(master=frame2, text="Billing Management App", font=("SE Pro Display",30,"bold"))
        l1.place(x=80,y=74)

        l2=customtkinter.CTkLabel(master=frame2, text="Admin Login",font=("SF Pro Display",20,"bold"))
        l2.place(x=195, y=119)

        #l3=customtkinter.CTkLabel(master=frame, text="Admin",font=("SF Pro Display",20))
        #l3.place(x=218, y=160)

        entry1=customtkinter.CTkEntry(master=frame2, width=300,height=30, placeholder_text='Username')
        entry1.place(x=91, y=165)

        entry2=customtkinter.CTkEntry(master=frame2, width=300,height=30, placeholder_text='Password', show="*")
        entry2.place(x=91, y=208)

        l3=customtkinter.CTkLabel(master=frame2, text="Forget password?",font=("SF Pro Display",12))
        l3.place(x=95,y=238)


        #Create custom button
        button1 = customtkinter.CTkButton(master=frame2, width=210, text="Login", corner_radius=6)
        button1.place(x=140, y=280)
        
       
        


if __name__ == "__main__":
    root = tk.Tk()

    # Create and pack Login frame
    app = ALogin(root)
    app.pack(fill="both", expand=True)

    # Set a minsize for the window, and place it in the middle
    root.update()
    root.minsize(root.winfo_width(), root.winfo_height())
    x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
    y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
    root.geometry("+{}+{}".format(x_cordinate, y_cordinate))

    root.mainloop()
