import tkinter as tk
from tkinter import *
from tkinter import ttk
import os
import customtkinter
import random

customtkinter.set_appearance_mode("dark")  # Modes: system (default), light, dark
customtkinter.set_default_color_theme("blue")  # Themes: blue (default), dark-blue, green

main = Tk()
main.geometry("1366x768")
main.title("Big Bazaar")
main.resizable(0, 0)

def APage():
    main.withdraw()
    os.system("python admin.py")
    main.deiconify()

def emp():
    main.withdraw()
    os.system("python employee_login.py")
    main.deiconify()

class APage(ttk.Frame):
    def __init__(self, root):
        ttk.Frame.__init__(self)
        self.root=root
        self.widgets_frame = ttk.Frame(self.root)
        self.root.geometry("1300x700+0+0")
        self.root.title("Tauqir - Momin")
        self.root.resizable(False,False)
        self.tk.call('tk', 'scaling', 2.0)
        #root.configure(background="black")


        
        
        

        #creating custom frame
        frame1=customtkinter.CTkFrame(main, width=1300, height=710,fg_color="#F4EEE0")
        frame1.place(relx=0.5, rely=0.5, anchor=CENTER)

        #creating custom frame
        #frame2=customtkinter.CTkFrame(self, width=1100, height=500,corner_radius=20,fg_color="#454545")
        #frame2.place(relx=0.5, rely=0.5, anchor=CENTER)
        
        #creating custom frame
        frame3=customtkinter.CTkFrame(main, width=1053, height=450,corner_radius=20,bg_color="#fff")
        frame3.place(relx=0.5, rely=0.5, anchor=CENTER)

        l1=customtkinter.CTkLabel(master=frame3, text="Billing Managment App",font=("SF Pro Display",30,"bold"))
        l1.place(x=260, y=40)

        l2=customtkinter.CTkLabel(master=frame3, text="(Admin Page)",font=("SF Pro Display",25,"bold"))
        l2.place(x=600, y=43)

        #Create custom button
        button1 = customtkinter.CTkButton(master=frame3, width=210,height=50, text="Grocery Data Base", corner_radius=20)
        button1.place(x=50, y=190)

        #Create custom button
        button2 = customtkinter.CTkButton(master=frame3, width=210,height=50, text="Employee Data Base", corner_radius=20)
        button2.place(x=300, y=190)

        #Create custom button
        button3 = customtkinter.CTkButton(master=frame3, width=210,height=50, text="Bill Data Base", corner_radius=20)
        button3.place(x=550, y=190)

        #Create custom button
        button4 = customtkinter.CTkButton(master=frame3, width=210,height=50, text="About", corner_radius=20)
        button4.place(x=800, y=190)
        

        





    

class ELogin(ttk.Frame):
    
        #creating whole custom
        frame1=customtkinter.CTkFrame(main, width=1300, height=710,fg_color="#F4EEE0")
        frame1.place(relx=0.5, rely=0.5, anchor=CENTER)

        #creating custom frame
        frame2=customtkinter.CTkFrame(main, width=500, height=500, corner_radius=15)
        frame2.place(relx=0.5, rely=0.5, anchor=CENTER)

        l1=customtkinter.CTkLabel(master=frame2, text="Billing Managment App",font=("SF Pro Display",30,"bold"))
        l1.place(x=82, y=74)

        l2=customtkinter.CTkLabel(master=frame2, text="Employee Login",font=("SF Pro Display",20,"bold"))
        l2.place(x=183, y=119)

        entry1=customtkinter.CTkEntry(master=frame2, width=300,height=30, placeholder_text='Username')
        entry1.place(x=91, y=165)

        entry2=customtkinter.CTkEntry(master=frame2, width=300,height=30, placeholder_text='Password', show="*")
        entry2.place(x=91, y=208)

        l3=customtkinter.CTkLabel(master=frame2, text="Forget password?",font=("SF Pro Display",12,"bold"))
        l3.place(x=94,y=238)

        l4=customtkinter.CTkLabel(master=frame2, text="Didn't have account? Resgister!",font=("SF Pro Display",12,"bold"), cursor="hand2")
        l4.place(x=94,y=258)
        #l4.bind("<Button-1>", open_file)

        #Create custom button
        button1 = customtkinter.CTkButton(master=frame2, width=210, text="Login", corner_radius=6)
        button1.place(x=140, y=300)
        
        













if __name__ == "__main__":
    root = tk.Tk()

    # Create and pack Login frame
    app = ELogin(root)
    app.pack(fill="both", expand=True)

    # Set a minsize for the window, and place it in the middle
    root.update()
    root.minsize(root.winfo_width(), root.winfo_height())
    x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
    y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
    root.geometry("+{}+{}".format(x_cordinate, y_cordinate))
    root.mainloop()
    



