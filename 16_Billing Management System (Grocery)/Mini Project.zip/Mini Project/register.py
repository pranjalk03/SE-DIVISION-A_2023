import tkinter as tk
from tkinter import *
from tkinter import ttk
import customtkinter
import random

class Login(ttk.Frame):
    def __init__(self, root):
        ttk.Frame.__init__(self)
        self.root=root
        self.widgets_frame = ttk.Frame(self.root)
        self.root.geometry("600x740")
        self.root.title("Tauqir - Momin")
        self.root.resizable(False,False)

        def register():
            nname_lb_info = self.namevalue.get()
            pname_lb_info = self.phonevalue.get()
            gname_lb_info = self.gendervalue.get()
            ename_lb_info = self.emailvalue.get()

            file = open(nname_lb_info + ".txt","w")
            file.write(nname_lb_info + "\n")
            file.write(pname_lb_info + "\n")
            file.write(gname_lb_info + "\n")
            file.write(ename_lb_info + "\n")
            file.close()

            nname_en.delete(0,END)
            pname_en.delete(0,END)
            gname_en.delete(0,END)
            ename_en.delete(0,END)
            
            Label(text="Register success",fg="green",font=("SF Pro Display",11)).place(x=500,y=415)
            

        #variables
        #nname_lb = StringVar()
        #pname_lb = StringVar()
        #gname_lb = StringVar()
        #ename_lb = StringVar()
        self.namevalue = StringVar()
        self.phonevalue = StringVar()
        self.gendervalue = StringVar()
        self.emailvalue = StringVar()

        #Title of Login page
        title = ttk.Label(self, text="Billing Managment App",font=("SF Pro Display",30,"bold"))
        title.pack(pady=50)


        #Name and its input
        nname_lb = ttk.Label(self, text="Name",font=("SF Pro Display",25)).place(x=350,y=150)
        nname_en = ttk.Entry(self, textvariable= self.namevalue , width=30,font=("SF Pro Display",20)).place(x=500,y=150)

        #Phone and its input
        pname_lb = ttk.Label(self, text="Phone",font=("SF Pro Display",25)).place(x=350,y=200)
        pname_en = ttk.Entry(self, textvariable= self.phonevalue , width=30,font=("SF Pro Display",20)).place(x=500,y=200)

        #Gender and its input
        gname_lb = ttk.Label(self, text="Gender",font=("SF Pro Display",25)).place(x=350,y=250)
        gname_en = ttk.Entry(self, textvariable= self.gendervalue , width=30,font=("SF Pro Display",20)).place(x=500,y=250)

        #Email and its input
        ename_lb = ttk.Label(self, text="Email",font=("SF Pro Display",25)).place(x=350,y=300)
        ename_en = ttk.Entry(self, textvariable= self.emailvalue , width=30,font=("SF Pro Display",20)).place(x=500,y=300)

        #check button
        checkvalue = IntVar()
        checkbtn = ttk.Checkbutton(self,text="remember me",variable=checkvalue)
        checkbtn.place(x=500,y=350)

        #button
        check_btn = ttk.Button(self,text="Register", padding=(20,5),command=register)
        check_btn.place(x=500,y=380)
        

        # Create the widgets frame
        self.widgets_frame = ttk.Frame(self.root)
        self.root.geometry("1300x700+0+0")
        self.root.title("Tauqir - Momin")

        





















if __name__ == "__main__":
    root = tk.Tk()
    root.title("")

    


    app = Login(root)
    app.pack(fill="both", expand=True)

    # Set a minsize for the selfdow, and place it in the middle
    root.update()
    root.minsize(root.winfo_width(), root.winfo_height())
    x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
    y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
    root.geometry("+{}+{}".format(x_cordinate, y_cordinate-20))

    
    root.mainloop()